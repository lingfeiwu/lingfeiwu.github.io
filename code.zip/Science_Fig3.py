
# coding: utf-8

# In[2]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
from scipy import stats

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

def log2linearBin(x,y):
    x=np.log2(x)
    a=[]
    q=sorted(zip(map(int,x),y))
    tag = ''
    d=[]
    for i in q:
        x1,y1 = i
        if x1 == tag: 
            d.append(y1)
        else:   
            if tag:   
                a.append([tag,np.mean(d)])
            tag = x1
            d = []
    a.append([tag,np.mean(d)])
    nx,ny = np.array(a).T
    return 2**nx,ny


# In[3]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0:
            W1[int(Id)]=[int(subject),int(year),int(teamsize),float(timegap),float(meanimp),float(impact),float(disruptive)]


# In[6]:

Z1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperNovelty1901_2014.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,novelty = line.strip().split('\t')
        Z1[int(paper)]=float(novelty)
        
S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[6]:

drs=[i[-1] for i in W1.values()]
drss=random.sample(drs,100000)


# In[7]:




# ### by year

# In[164]:

DepYear=defaultdict(lambda:defaultdict(lambda:[]))
VisYear=defaultdict(lambda:defaultdict(lambda:[]))
DisYear=defaultdict(lambda:defaultdict(lambda:[]))
ImpYear=defaultdict(lambda:defaultdict(lambda:[]))
years=[1995,2002,2005]
#years=[1980,1990,2000]
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if 1<=teamsize<=10:
        #if year in [1983,1984,1985,1986,1987]:
        #    year=1985
        #if year in [1989,1990,1991]:
        #    year=1990
        #if year in [1999,2000,2001]:
        #    year=2000
        if year in years:
            DepYear[year][teamsize].append(timegap)
            VisYear[year][teamsize].append(meanimp)
            DisYear[year][teamsize].append(disruptive)
            ImpYear[year][teamsize].append(impact)


# In[230]:

depYear={}
visYear={}
disYear={}
impYear={}
for year in years:
    depYear[year]=zip(*sorted([(k,np.mean(v)) for k,v in DepYear[year].items()]))
    visYear[year]=zip(*sorted([(k,np.median(v)) for k,v in VisYear[year].items()]))
    impYear[year]=zip(*sorted([(k,np.median(v)) for k,v in ImpYear[year].items()]))
    #drs=[]
    #for ts in range(1,11):
    #    drs+=DisYear[year][ts]
    #drss= random.sample(drs,10000)
    disYear[year]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                    for k,v in DisYear[year].items()]))


# In[361]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for year in years:
    x,y=depYear[year]
    n+=.4
    host.plot(x,y,marker='',color='#AA4466',alpha=n/1.2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(7,11)
host.set_yticks([7,9,11])
host.set_yticklabels(('','',''))
n=0
for year in years:
    x,y=visYear[year]
    n+=.4
    par1.plot(x,y,marker='',color='RoyalBlue',alpha=n/1.2,linewidth=n)
par1.set_xlim(1,10)
par1.set_ylim(50,250)
par1.set_yticks([50,150,250])
par1.set_yticklabels(('','',''))
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
#
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.1.pdf',            bbox_inches='tight')


# In[362]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for year in years:
    x,y=disYear[year]
    n+=.4
    host.plot(x,y,marker='',color='#AA4466',alpha=n/1.2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(20,100)
#host.set_yticks([])
host.set_yticks([20,60,100])
host.set_yticklabels(('','',''))

n=0
for year in years:
    x,y=impYear[year]
    n+=.4
    par1.plot(x,y,marker='',color='RoyalBlue',alpha=n/1.2,linewidth=n)
par1.set_xlim(1,10)
par1.set_ylim(1,25)
par1.set_yticks([1,12.5,25])
par1.set_yticklabels(('','',''))
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')

'''
n=0.6;ny=0.001
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'1985',ha="center", va="bottom",fontsize=10)
n=1.2;ny=0.0018
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'1995',ha="center", va="bottom",fontsize=10)
n=1.8;ny=0.0026
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'2005',ha="center", va="bottom",fontsize=10)
'''

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.2.pdf',            bbox_inches='tight')


# ### by Impact

# In[246]:

DepImpact=defaultdict(lambda:defaultdict(lambda:[]))
VisImpact=defaultdict(lambda:defaultdict(lambda:[]))
DisImpact=defaultdict(lambda:defaultdict(lambda:[]))
ImpImpact=defaultdict(lambda:[])
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if 1<=teamsize<=10 and impact>0:
        if 1<=impact<3:
            ilevel=1
        if 3<=impact<=10:
            ilevel=2
        if impact>10:
            ilevel=3        
        DepImpact[ilevel][teamsize].append(timegap)
        VisImpact[ilevel][teamsize].append(meanimp)
        DisImpact[ilevel][teamsize].append(disruptive)
        ImpImpact[teamsize].append(impact)


# In[242]:

depImpact={}
visImpact={}
disImpact={}
for ilevel in [1,2,3]:
    depImpact[ilevel]=zip(*sorted([(k,np.mean(v)) for k,v in DepImpact[ilevel].items()]))
    visImpact[ilevel]=zip(*sorted([(k,np.median(v)) for k,v in VisImpact[ilevel].items()]))
    #disImpact[ilevel]=zip(*sorted([(k,np.mean(v)) for k,v in DisImpact[ilevel].items()]))
    #
    #drs=[]
    #for ts in range(1,11):
    #    drs+=DisImpact[ilevel][ts]
    #drss= random.sample(drs,10000)
    disImpact[ilevel]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                    for k,v in DisImpact[ilevel].items()]))


# In[250]:

ximpImpact,yimpImpact=zip(*sorted([(k,np.mean(v)) for k,v in ImpImpact.items()]))


# In[363]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for ilevel in [1,2,3]:
    x,y=depImpact[ilevel]
    n+=.4
    host.plot(x,y,marker='',color='#AA4466',alpha=n/1.2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(7,11)
host.set_yticks([7,9,11])
host.set_yticklabels(('','',''))

n=0
for ilevel in [1,2,3]:
    x,y=visImpact[ilevel]
    n+=.4
    par1.plot(x,y,marker='',color='RoyalBlue',alpha=n/1.2,linewidth=n)
par1.set_xlim(1,10)
par1.set_ylim(50,250)
par1.set_yticks([50,150,250])
par1.set_yticklabels(('','',''))
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()

'''
n=0.6;ny=10
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'1 - 3',ha="center", va="bottom",fontsize=10)
n=1.2;ny=10.3
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'3 - 10',ha="center", va="bottom",fontsize=10)
n=1.8;ny=10.6
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'> 10',ha="center", va="bottom",fontsize=10)
'''
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.3.pdf',            bbox_inches='tight')


# In[375]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for ilevel in [1,2,3]:
    x,y=disImpact[ilevel]
    n+=.4
    host.plot(x,y,marker='',color='#AA4466',alpha=n/1.2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(20,100)
host.set_yticks([20,60,100])
host.set_yticklabels(('','',''))
#par1.plot(ximpImpact,yimpImpact,color='RoyalBlue',alpha=1)
#par1.set_ylim(22,30)
par1.set_yticks([])
#par1.set_yticklabels(('','',''))
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.4.pdf',            bbox_inches='tight')


# In[ ]:




# ### by field

# In[4]:

VisField=defaultdict(lambda:defaultdict(lambda:[]))
DisField=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if subject not in [7,8,9]:
        if 1<=teamsize<=10:
            VisField[subject][teamsize].append(meanimp)
            DisField[subject][teamsize].append(disruptive)


# In[8]:

visField={}
disField={}
disField1={}
for subject in VisField.keys():
    visField[subject]=zip(*sorted([(k,np.median(v)) for k,v in VisField[subject].items()]))
    disField1[subject]=zip(*sorted([(k,np.mean(v)) for k,v in DisField[subject].items()]))
    disField[subject]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                for k,v in DisField[subject].items()]))


# In[9]:

fm={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}


# In[ ]:




# In[10]:

sortedFields=zip(*sorted([(sum(map(len,DisField[i].values())),i) for i in VisField.keys()]))[1]


# In[368]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
cmapSubject = cm.get_cmap('rainbow',12)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for subject in sortedFields:
    x,y=visField[subject]
    par1.plot(x,y,marker='',color=cmapSubject(n),alpha=1,              linewidth=n/6.0+0.1,label=fm[subject])
    n+=1
host.set_xlim(1,10)
#host.legend(loc=2,fontsize=8)
#host.set_ylim(-0.02,0.01)
par1.set_ylim(50,250)
par1.set_yticks([50,150,250])
par1.set_yticklabels(('','',''))
host.set_yticks([])

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.5.pdf',            bbox_inches='tight')


# In[376]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
cmapSubject = cm.get_cmap('rainbow',12)
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for subject in sortedFields:
    x,y=disField[subject]
    host.plot(x,y,marker='',color=cmapSubject(n),alpha=1,              linewidth=n/6.0+0.1,label=fm[subject])
    n+=1
host.set_xlim(1,10)
host.set_ylim(20,90)
host.set_yticks([20,60,100])
par1.set_yticks([])
host.set_yticklabels(('','',''))

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.6.pdf',            bbox_inches='tight')


# In[ ]:




# In[15]:

fig = plt.figure(figsize=(4,4),facecolor='white')
cmapSubject = cm.get_cmap('rainbow',12)
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
#par1 = host.twinx()
offset = 60
n=0
for subject in sortedFields:
    x,y=disField1[subject]
    host.plot(x,y,marker='',color=cmapSubject(n),alpha=1,              linewidth=n/4.0+0.1,label=fm[subject])
    n+=1
host.set_xlim(1,10)
host.legend(loc=1,fontsize=8,ncol=1)
host.set_ylim(-0.005,0.02)
host.set_yticks([-0.005,0,0.02])

host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.5Alternative.pdf')


# ### patent

# In[312]:

#patents
W2={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W2[Id]=[int(date[:4]),int(teamsize),int(impact),float(disruptiveness)]


# In[313]:

DepPatent=defaultdict(lambda:[])
VisPatent=defaultdict(lambda:[])

n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentNetworkApplicant.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in W2:
            teamsize=W2[p][1]
            year2=W2[p][0]
            if 1<=teamsize<=10 and year2 ==2009:
                gs=[year2-W2[j][0] for j in line[1:] if j in W2 and W2[j][0]<=year2]
                degrees=[W2[j][2] for j in line[1:] if j in W2]
                if gs:
                    DepPatent[teamsize].append(np.mean(gs))
                    VisPatent[teamsize].append(np.mean(degrees))


# In[330]:

Patent={}
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStatTwoNetworks.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        i, year, ts,ie,dise,ia,disa=line
        Patent[i]=[int(year),int(ts),int(ie),float(dise),int(ia),float(disa)]


# In[316]:

xdepPatent,ydepPatent=zip(*sorted([(k,np.mean(v)) for k,v in DepPatent.items()]))
xvisPatent,yvisPatent=zip(*sorted([(k,np.median(v)) for k,v in VisPatent.items()]))


# In[370]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdepPatent,ydepPatent,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(10,12)
host.set_yticks([10,11,12])
host.set_yticklabels(('','',''))

par1.plot(xvisPatent,yvisPatent,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(30,50)
par1.set_yticks([30,40,50])
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
par1.set_yticklabels(('','',''))

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()


plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.7.pdf',            bbox_inches='tight')

#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.5Alternative.pdf')


# In[336]:

drssPatent=[i[-1] for i in Patent.values()]


# In[338]:

DisPatent=defaultdict(lambda:[])
ImpPatent=defaultdict(lambda:[])
for i in Patent:
    year, ts, ie,dise,ia,disa=Patent[i]
    if 1<=ts<=10:
        DisPatent[ts].append(disa)
        ImpPatent[ts].append(ia)
xdisPatent1,ydisPatent1=zip(*sorted([(k,np.mean(v)) for k,v in DisPatent.items()]))
ximpPatent,yimpPatent=zip(*sorted([(k,np.mean(v)) for k,v in ImpPatent.items()]))
xdisPatent,ydisPatent=zip(*sorted([(k,stats.percentileofscore(drssPatent, np.mean(v)))                            for k,v in DisPatent.items()]))


# In[371]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdisPatent,ydisPatent,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(65,75)
host.set_yticks([65,70,75])
host.set_yticklabels(('','',''))

par1.plot(ximpPatent,yimpPatent,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(7,15)
par1.set_yticks([7,11,15])
par1.set_yticklabels(('','',''))
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
plt.tight_layout()

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.8.pdf',            bbox_inches='tight')


# ### Github

# In[344]:

n=0
W3={}
W4={}
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubStats.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, year, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if disruptiveness!='NA':
            W3[int(Id)]=[int(year),int(teamsize),int(impact),float(disruptiveness)]
        W4[int(Id)]=[int(year),int(teamsize),int(impact),disruptiveness]


# In[345]:

len(W4)


# In[346]:

DepGithub=defaultdict(lambda:[])
VisGithub=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubCites.txt','r') as f:
    for line in f:
        line=map(int,line.strip().split('\t'))
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        p=line[0]
        cites=line[1:]
        if p in W4 and cites :
            teamsize=W4[p][1]
            if 1<=teamsize<=10:
                yeari=W4[p][0]
                yearjs=[W4[j][0] for j in cites if j in W4]
                degrees=[W4[j][2] for j in cites if j in W4]
                if yearjs:
                    DepGithub[teamsize].append(np.mean(yeari-np.array(yearjs)))
                if degrees:
                    VisGithub[teamsize].append(np.mean(degrees))


# In[347]:

drssGithub=[i[-1] for i in W3.values()]


# In[348]:

DisGithub=defaultdict(lambda:[])
ImpGithub=defaultdict(lambda:[])
for i in W3:
    year3,teamsize3,impact3,disruptive3=W3[i]
    if 1<=teamsize3<=10:
        DisGithub[teamsize3].append(disruptive3)
        ImpGithub[teamsize3].append(impact3)


# In[349]:

xdepGithub,ydepGithub=zip(*sorted([(k,np.mean(v)) for k,v in DepGithub.items()]))
xvisGithub,yvisGithub=zip(*sorted([(k,np.median(v)) for k,v in VisGithub.items()]))
xdisGithub1,ydisGithub1=zip(*sorted([(k,np.mean(v)) for k,v in DisGithub.items()]))
xdisGithub,ydisGithub=zip(*sorted([(k,stats.percentileofscore(drssGithub, np.mean(v)))                            for k,v in DisGithub.items()]))
ximpGithub,yimpGithub=zip(*sorted([(k,np.mean(v)) for k,v in ImpGithub.items()]))


# In[372]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdepGithub,ydepGithub,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(0.3,1)
host.set_yticks([0.3,0.65,1])
host.set_yticklabels(('','',''))

par1.plot(xvisGithub,yvisGithub,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(5,10)
par1.set_yticks([5,7.5,10])
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
par1.set_yticklabels(('','',''))

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()



plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.9.pdf',            bbox_inches='tight')


# In[373]:

fig = plt.figure(figsize=(3,1.5),facecolor='white')
host = fig.add_subplot(111)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdisGithub,ydisGithub,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(20,70)
host.set_yticks([20,45,70])
host.set_yticklabels(('','',''))

par1.plot(ximpGithub,yimpGithub,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(2,7)
par1.set_yticks([2,4.5,7])
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')
par1.set_yticklabels(('','',''))

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig3.10.pdf',            bbox_inches='tight')


# In[452]:

plt.rc('axes',edgecolor='k')


# In[ ]:




# In[476]:

fig = plt.figure(figsize=(10,12.5),facecolor='white')

#-------------------------------------521-------------------------------------------

host = fig.add_subplot(521)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for year in years:
    x,y=depYear[year]
    n+=.6
    host.plot(x,y,marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(6.5,10.5)
host.set_yticks([])

n=0
for year in years:
    x,y=visYear[year]
    n+=.6
    par1.plot(x,y,marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
par1.set_xlim(1,10)
par1.set_ylim(80,220)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off') 

plt.text(0.05, 0.05, '6.5',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '10.5',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '220',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '80',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')

plt.text(0.3, 0.05, 'A',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#
#-------------------------------------522-------------------------------------------

host = fig.add_subplot(522)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for year in years:
    x,y=disYear[year]
    n+=.6
    host.plot(x,y,marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(-0.004,0.003)
host.set_yticks([])

n=0
for year in years:
    x,y=impYear[year]
    n+=.6
    par1.plot(x,y,marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
par1.set_xlim(1,10)
par1.set_ylim(5,25)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')


n=0.6;ny=0.0015
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'1985',ha="center", va="bottom",fontsize=10)
n=1.2;ny=0.002
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'1995',ha="center", va="bottom",fontsize=10)
n=1.8;ny=0.0025
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'2005',ha="center", va="bottom",fontsize=10)


plt.text(0.05, 0.05, '-0.004',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '0.003',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '25',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '5',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')


plt.text(0.3, 0.05, 'B',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------523-------------------------------------------

host = fig.add_subplot(523)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for ilevel in [1,2,3]:
    x,y=depImpact[ilevel]
    n+=.6
    host.plot(x,y,marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(6,11)
host.set_yticks([])

n=0
for ilevel in [1,2,3]:
    x,y=visImpact[ilevel]
    n+=.6
    par1.plot(x,y,marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
par1.set_xlim(1,10)
par1.set_ylim(1,500)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')
plt.tight_layout()


n=0.6;ny=10
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'1 - 10',ha="center", va="bottom",fontsize=10)
n=1.2;ny=10.3
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'10 - 100',ha="center", va="bottom",fontsize=10)
n=1.8;ny=10.6
host.plot([3.5,4.5],[ny,ny],marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.plot([4.5,5.5],[ny,ny],marker='',color='RoyalBlue',alpha=n/2,linewidth=n)
host.text(4.5,ny,'> 100',ha="center", va="bottom",fontsize=10)


plt.text(0.05, 0.05, '6',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '11',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '500',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '1',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')


plt.text(0.3, 0.05, 'C',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------524-------------------------------------------


host = fig.add_subplot(524)
plt.subplots_adjust(right=0.75)
#par1 = host.twinx()
offset = 60
n=0
for ilevel in [1,2,3]:
    x,y=disImpact[ilevel]
    n+=.6
    host.plot(x,y,marker='',color='#AA4466',alpha=n/2,linewidth=n)
host.set_xlim(1,10)
host.set_ylim(-0.01,0.04)
host.set_yticks([])


plt.text(0.05, 0.05, '-0.01',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '0.04',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')

host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')


plt.text(0.3, 0.05, 'D',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------525-------------------------------------------

host = fig.add_subplot(525)
cmapSubject = cm.get_cmap('Accent_r',12)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
n=0
for subject in sortedFields:
    x,y=visField[subject]
    al=0.5+n/20.0
    par1.plot(x,y,marker='',color=cmapSubject(n),alpha=1,              linewidth=3*n/10.0+0.5,label=fm[subject])
    n+=1
host.set_xlim(1,10)
#host.legend(loc=2,fontsize=8)
#host.set_ylim(-0.02,0.01)
par1.set_ylim(50,250)
par1.set_yticks([])
host.set_yticks([])

plt.text(0.95, 0.95, '250',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '50',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')

host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')


plt.text(0.3, 0.05, 'E',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------526-------------------------------------------

host = fig.add_subplot(526)
cmapSubject = cm.get_cmap('Accent_r',12)
plt.subplots_adjust(right=0.75)
#par1 = host.twinx()
offset = 60
n=0
for subject in sortedFields:
    x,y=disField[subject]
    al=0.5+n/20.0
    host.plot(x,y,marker='',color=cmapSubject(n),alpha=1,              linewidth=3*n/10.0+0.5,label=fm[subject])
    n+=1
host.set_xlim(1,10)
host.legend(loc=1,fontsize=7,ncol=2)
host.set_ylim(-0.005,0.02)
host.set_yticks([])

plt.text(0.05, 0.05, '-0.005',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '0.02',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')

host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')

plt.text(0.3, 0.05, 'F',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------527-------------------------------------------

host = fig.add_subplot(527)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdepPatent,ydepPatent,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(10,12)
host.set_yticks([])

par1.plot(xvisPatent,yvisPatent,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(30,50)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')

plt.text(0.05, 0.05, '10',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '12',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '50',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '30',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')

plt.text(0.3, 0.05, 'G',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------528-------------------------------------------
host = fig.add_subplot(528)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdisPatent,ydisPatent,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(0.03,0.06)
host.set_yticks([])

par1.plot(ximpPatent,yimpPatent,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(7,15)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='off',top='off',labelbottom='off')

plt.text(0.05, 0.05, '0.03',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '0.06',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '15',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '7',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')


plt.text(0.3, 0.05, 'H',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------529-------------------------------------------

host = fig.add_subplot(529)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdepGithub,ydepGithub,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(0.3,1)
host.set_yticks([])

par1.plot(xvisGithub,yvisGithub,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(5,10)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')

plt.text(0.05, 0.05, '0.3',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '1',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '10',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '5',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')

plt.text(0.3, 0.05, 'I',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')

#-------------------------------------520-------------------------------------------

host = fig.add_subplot(5,2,10)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
offset = 60
host.plot(xdisGithub,ydisGithub,marker='',color='#AA4466',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(-0.2,1)
host.set_yticks([])

par1.plot(ximpGithub,yimpGithub,marker='',color='RoyalBlue',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(2,7)
par1.set_yticks([])
host.tick_params(axis='x', which='both',bottom='on',top='off',labelbottom='off')


plt.text(0.05, 0.05, '-0.2',
        verticalalignment='bottom', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.05, 0.95, '1',
        verticalalignment='top', horizontalalignment='left',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.95, '7',
        verticalalignment='top', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')
plt.text(0.95, 0.05, '2',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=10,color='gray')

plt.text(0.3, 0.05, 'J',
        verticalalignment='bottom', horizontalalignment='right',
        transform=host.transAxes,fontsize=12,color='gray')


plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.pdf')


# In[ ]:



