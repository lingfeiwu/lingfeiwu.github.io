
# coding: utf-8

# In[2]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    


# In[2]:

W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(teamsize),int(subject),float(disruptive),int(journal),int(year)]


# In[128]:

# senior scholar
n=0
nauthor=0
A={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        u=line[0]
        v=map(int,line[1:])
        if len(v)>=30 and random.random()<0.1:
            nauthor+=1
            A[nauthor]=v
            if nauthor>1000:
                break


# In[124]:

# diverse scholar: include small-team, disruptive-research scholars
n=0
nauthor=0
A={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        u=line[0]
        v=map(int,line[1:])
        v=[i for i in v if i in W]
        ys=[W[i][-1] for i in v]
        #if len(v)>=3 and max(ys)<=2000 and random.random()<0.5:
        #if len(v)>=3 and max(ys)<=1990:
        if random.random()<0.1:
            nauthor+=1
            A[nauthor]=v
            if nauthor>10000:
                break
len(A)


# In[130]:

'''
A_=defaultdict(lambda:[])
for i in A:
    for j in A[i]:
        A_[j].append(i)
A_=dict(A_)
len(A_)
'''


# In[37]:

'''
DS=[v[2] for v in W.values()]
DP=random.sample(DS,10000)
stats.percentileofscore(DP,0)
'''


# In[125]:

A_=defaultdict(lambda:[])
for i in A:
    for j in A[i]:
        A_[j].append(i)
A_=dict(A_)
len(A_)

D=[]
n=0
for i in A_:
    n+=1
    if n%1000==0:
        flushPrint(n/1000)
    if i in W and len(A_[i])==1:
        a=A_[i][0]
        m,sb,ds,j,y=W[i]
        y=int(y/10)*10
        dp=stats.percentileofscore(DP,ds)
        if 1<=m<=10:
            D.append([i,y,m,sb,a,dp])
len(D)


# In[85]:

'''
import statsmodels.api as sm
def OLSRegressFit(x,y):
   xx = sm.add_constant(x, prepend=True)
   res = sm.OLS(y,xx).fit()
   constant, beta = res.params
   r2 = res.rsquared
   p=res.pvalues[1]
   return [beta, p]
'''


# In[126]:

i,y,m,sb,a,dp=np.array(D).T
OLSRegressFit(m,dp)


# In[127]:

dd=defaultdict(lambda:[])
for i,j in zip(m,dp):
    dd[i].append(j)
x,y=np.array(sorted([(k,np.mean(v)) for k,v in dd.items()])).T
plt.plot(m,dp,'b.',alpha=0.1)
plt.plot(x,y,'r.-')


# In[ ]:




# In[128]:

len(D)


# In[138]:

'''
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption1000_30_2000.txt', "wb") as f:
    for v in D:
        f.write('\t'.join(map(str,v)) + '\n')
'''


# In[ ]:

# explore regression


# In[129]:

# papers
pd=set(zip(*D)[0])
T1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=int(line[0])
        if p in pd:
            T1[p]=line[1].lower()
# papers
A1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in pd:
                A1[p]=T1[p]+' '+line[1].lower()


# In[130]:

# fitting all papers in survey data
vectors={}
n=0
for v in D:
    i=v[0]
    n+=1
    if n%1000==0:
        flushPrint(n/1000)
    model.random.seed(0)
    vc=model.infer_vector(gensim.utils.simple_preprocess(A1[i]))
    vectors[i]=vc
np.array(vectors.values()).min(),np.array(vectors.values()).max()


# In[131]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption10000_1_doc2vec.txt', "wb") as f:
    for v in D:
        i=v[0]
        vc=vectors[i]
        f.write('\t'.join(map(str,v))+'\t' +'\t'.join(map(str,vc)) +'\n')


# In[ ]:




# # regression including doc2vec

# In[3]:

# sampleing papers across journals
J=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            J[int(journal)].append(int(Id))


# In[55]:

len(J)


# In[56]:

pSample=[]
N=100000
n=float(sum(map(len,J.values())))
for k,v in J.items():
    w=len(v)/n
    m=int(w*N)
    if m>=1:
        rv=random.sample(v,m)
        pSample+=rv
pSample=set(pSample)
len(pSample)


# In[57]:

# papers
T={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=int(line[0])
        if p in pSample:
            T[p]=line[1].lower()
# papers
A={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in pSample:
                A[p]=T[p]+' '+line[1].lower()


# In[58]:

len(T),len(A)


# In[59]:

train_corpus=[]
n=0
for i in pSample:
    if n%10000==0:
        flushPrint(n/10000)#9
    if i in A:
        ab=A[i]
        if len(ab)>10:
            new=gensim.models.doc2vec.TaggedDocument(gensim.utils.simple_preprocess(ab), [n])
            train_corpus.append(new)
            n+=1
n


# In[60]:

model = gensim.models.doc2vec.Doc2Vec(size=100, min_count=2, iter=20, workers=4)
model.build_vocab(train_corpus)
get_ipython().magic(u'time model.train(train_corpus, total_examples=model.corpus_count, epochs=model.iter)')


# In[63]:

len(model.wv.vocab)


# In[61]:

model.most_similar('biology',topn=10)


# In[65]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/abstractTitle1900_2015_embed100d.txt','wb') as f1:
    for word in model.wv.vocab:
        v=model[word]
        f1.write(str(word)+'\t'+'\t'.join(map(str,v))+'\n')


# In[72]:

F={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstractTitle1900_2015_embed100d.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        F[line[0]]=map(float,line[1:])


# In[ ]:

# read in papers tokens
Z={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstractTitle1900_2015_token_f2.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        line=line.strip().split('\t')
        p=int(line[0])#paper id
        e=defaultdict(int)
        try:
            for s in line[1:]:
                a,b=s.split('__')
                if a in F:
                    e[a]=int(b)
        except:
            pass
        if e:
            Z[p]=e
        


# In[69]:

# embed scholars
n=0
A={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        u=line[0]
        v=map(int,line[1:])
        A[nauthor]=v
        if nauthor>1000:
            break


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[216]:

'''
D=[]
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption1000_30_2000.txt', "rb") as f:
    for line in f:
        i,y,m,sb,a,dp=line.strip().split('\t')
        D.append([int(i),int(y),int(m),int(sb),int(a),float(dp)])
'''


# In[236]:

np.array(vectors.values()).min(),np.array(vectors.values()).max()


# In[232]:

'''
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption1000_30_2000_doc2vec.txt', "wb") as f:
    for v in D:
        i=v[0]
        vc=vectors[i]
        f.write('\t'.join(map(str,v))+'\t' +'\t'.join(map(str,vc)) +'\n')
'''


# In[ ]:




# # revision analysis

# In[1]:

D=[]
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption1000_30_2000.txt', "rb") as f:
    for line in f:
        i,y,m,sb,a,dp=line.strip().split('\t')
        D.append([int(i),int(y),int(m),int(sb),int(a),float(dp)])


# In[2]:

len(D)


# In[5]:

n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption10000_1_doc2vec.txt', "rb") as f:
    for line in f:
        n+=1
n


# In[ ]:



