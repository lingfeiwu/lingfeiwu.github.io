
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from scipy import stats
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    


# In[2]:

Patent={}
#Patent05=set([])
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStatTwoNetworks.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        i, year, ts,ie,dise,ia,disa=line
        if 2002<=int(year)<=2009:
            Patent[i]=[int(year),int(ts),int(ie),float(dise),int(ia),float(disa)]
            #if int(year)==2005:
            #    Patent05.add(i)


# In[3]:

len(Patent)


# In[4]:

drss=[v[-1] for v in Patent.values()]
drss=random.sample(drss,100000)
stats.percentileofscore(drss,0)


# In[5]:

C={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentClassification.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in Patent:
            for j in line[1:]:
                if j not in C:
                    C[j]=set([])
                C[j].add(p)


# In[6]:

As={}
with open('/Users/lingfeiw/Documents/research/teamscience/patent/AssigneeBig.txt', "rb") as f:
    for line in f:
        a,b=line.strip().split('\t')
        As[a]=b


# In[16]:

n=0
As1={}
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentAssignee.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#49
        line=line.strip().split('\t')
        p=line[0]
        org=line[1]
        if org and org!='None':
            As1[p]=org


# In[8]:

As.items()[:3]


# In[17]:

As1.items()[:3]


# In[ ]:




# In[11]:

len(Patent),len(As),len(C),len(As1)


# In[12]:

topCL=zip(*sorted([(k,len(v)) for k,v in C.items()],key=lambda x:-x[1])[:10])[0]
topCL


# In[13]:

topC=zip(*sorted(Counter(As.values()).items(),key=lambda x:-x[1])[:5])[0]
topC


# In[18]:

topC1=zip(*sorted(Counter(As1.values()).items(),key=lambda x:-x[1])[:5])[0]
topC1


# In[19]:

topCLM={'257':'Active solid-state devices', 
        '438':'Semiconductor device\nmanufacturing: process',
        '370':'Multiplex communications', 
        '709':'Electrical computers and digital processing\nsystems: multicomputer data transferring', 
        '455':'Telecommunications', 
        '707':'Data processing: database and file\nmanagement or data structures', 
        '348':'Television', 
        '340':'Communications: electrical',
        '428':'Stock material or miscellaneous articles', 
        '375':'Pulse or digital communications',
        'G9B':'information storage based on relative movement\nbetween record carrier and transducer'
       }


# In[20]:

disPatentCL=defaultdict(lambda:defaultdict(lambda:[]))
for i in topCL:
    for j in C[i]:
        year, ts,ie,dise,ia,disa=Patent[j]
        disPatentCL[i][ts].append(disa)
disPatentC=defaultdict(lambda:defaultdict(lambda:[]))
for i in Patent:
    year, ts,ie,dise,ia,disa=Patent[i]
    if i in As and As[i] in topC:
        disPatentC[As[i]][ts].append(disa)
disPatentC1=defaultdict(lambda:defaultdict(lambda:[]))
for i in Patent:
    year, ts,ie,dise,ia,disa=Patent[i]
    if i in As1 and As1[i] in topC1:
        disPatentC1[As1[i]][ts].append(disa)


# In[94]:

fig = plt.figure(figsize=(10, 5),facecolor='white')
ax = fig.add_subplot(121)
cmap = cm.get_cmap('rainbow_r',len(topCL))
n=0
for l in topCL:
    x,y=np.array(sorted([(k,np.mean(v)) for k,v in disPatentCL[l].items()])).T
    y=[stats.percentileofscore(drss,i) for i in y]
    plt.plot(x,y,color=cmap(n),label=topCLM[l])
    n+=1
plt.xlim(1,10)
plt.legend(loc=3,fontsize=10,frameon=False)
plt.ylim(0,90)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
#
cmap = cm.get_cmap('Accent',len(topC))
ax = fig.add_subplot(122)
n=0
for l in topC:
    x,y=np.array(sorted([(k,np.mean(v)) for k,v in disPatentC[l].items()])).T
    y=[stats.percentileofscore(drss,i) for i in y]
    plt.plot(x,y,color=cmap(n),label=l)
    n+=1
plt.xlim(1,10)
plt.legend(loc=3,fontsize=10,frameon=False)
plt.ylim(0,90)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/PatentControl.pdf')


# In[ ]:




# In[ ]:




# In[17]:

def DiffusionWeightAverage(threshold,data):#[value,samplesize] in data
    smoothData=[data[0]]
    for n,j in enumerate(data[1:]):
        value,sampleSize=j
        if sampleSize<threshold:
            lastValue,lastSampleSize=smoothData[n-1]
            value=np.average([lastValue,value], weights=[lastSampleSize, sampleSize])
        smoothData.append([value,sampleSize])
    return smoothData


# In[20]:

for i in names:
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.01
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)      


# In[24]:

ydisPatent=[73.630887773634385,
 73.683814600281565,
 73.362492343073299,
 73.430464359021215,
 71.945826571953617,
 71.985588857962668,
 71.928632069895642,
 73.678709982483099,
 68.22402286868774,
 69.805648393926049,
 70.70594177511741,
 69.563850708735885,
 70.838124509688029,
 66.821596294584808,
 66.666308447873789,
 54.297550858113119]


# In[ ]:




# In[28]:

fig = plt.figure(figsize=(10, 5),facecolor='white')
ax = fig.add_subplot(121)
cmap = cm.get_cmap('rainbow_r',7)
n=0
for l in topCL[:7]:
    x,y,z=np.array(sorted([(k,np.mean(v),1) for k,v in disPatentCL[l].items()])).T
    y=[stats.percentileofscore(drss,i) for i in y]
    threshold=sum(z)*0.1
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',color=cmap(n),alpha=0.7,label=topCLM[l])
    n+=1
plt.plot(range(1,17),ydisPatent,'k--',linewidth=2,label='Population average')
plt.xlim(1,16)
plt.legend(loc=3,fontsize=10,frameon=False)
plt.ylim(10,90)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
#
cmap = cm.get_cmap('Accent',len(topC))
ax = fig.add_subplot(122)
n=0
for l in topC:
    x,y,z=np.array(sorted([(k,np.mean(v),1) for k,v in disPatentC[l].items()])).T
    y=[stats.percentileofscore(drss,i) for i in y]
    threshold=sum(z)*0.1
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',color=cmap(n),alpha=0.7,label=l)
    n+=1
plt.plot(range(1,17),ydisPatent,'k--',linewidth=2,label='Population average')
plt.xlim(1,16)
plt.legend(loc=3,fontsize=10,frameon=False)
plt.ylim(10,90)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/PatentControl2002-2009.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:



