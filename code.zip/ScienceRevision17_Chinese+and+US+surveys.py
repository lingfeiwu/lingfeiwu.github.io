
# coding: utf-8

# In[4]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# In[2]:

W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        W[int(Id)]=[int(journal),int(subject),float(disruptive),int(year),int(teamsize),int(impact)]


# In[21]:

J=defaultdict(lambda:defaultdict(lambda:0))
n=0
for i in W:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    J[W[i][0]][W[i][3]]+=1


# In[25]:

JN={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','rb') as f:
    for line in f:
        idx,name,_=line.strip().split('\t')
        JN[int(idx)]=name.lower()


# In[38]:

#24, 'american journal of the medical sciences'
#57, 'british medical journal'
#432, 'science'
#22, 'nature'


# In[39]:

P={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperJournal.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        p,j=map(int,line.strip().split('\t'))
        if j in set([22,24,57,432]):
            P[p]=j


# In[40]:

len(P)


# In[5]:

Title={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=int(line[0])
        Title[p]=line[1].lower()


# In[42]:

# papers
Abstract={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in P:
                Abstract[p]=line[1].lower()


# In[43]:

len(P),len(Title),len(Abstract)


# In[50]:

f = open('/Users/lingfeiw/Documents/research/teamscience/team/100yearTextNatureScience.txt', "wb")
for i in sorted(P.keys()):
    f.write(str(Y[i])+'\t'+str(i)+'\t'+ str(P[i]) +'\t'+Title[i]+'\t'+ Abstract[i] +'\n')


# In[49]:

#1.year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[ ]:




# In[19]:

len(W)


# In[3]:

len(W)


# In[4]:

n=0
Title={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        t=line[1]
        Title[p]=t.lower()
#len(Title)#24174022


# In[6]:

T = {v: k for k, v in Title.iteritems()}


# In[642]:




# In[643]:

len(k)


# In[8]:

len(T)


# # Jingqing

# In[7]:

len(T)


# In[195]:

T['conservation of isotopic spin and isotopic gauge invariance'],W[1625098][2:]


# In[196]:

T['kinetics of approach to equilibrium'],W[2279482][2:]


# In[197]:

T['reciprocal relations in irreversible processes. i.'],W[572178][2:]


# In[ ]:

#self-organize and 1/f noise
#


# In[198]:

T['emergence of scaling in random networks'],W[23638776][2:]


# In[199]:

T['Five Rules for the Evolution of Cooperation'.lower()],W[31447795][2:]


# In[200]:

T['reciprocal relations in irreversible processes. ii.'],W[584825][2:]


# In[201]:

T['scaling behavior in the dynamics of an economic index'.lower()],W[19701716][2:]


# In[ ]:




# # liulu

# In[64]:

T['a mathematical theory of communication'],W[1139077][2:]# this is the right one


# In[76]:

T['information theory and statistical mechanics'],W[1885680]


# In[77]:

T['networks of scientific papers']#0.922279792746


# In[202]:

n=0
m=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        if 3001360 in set(line[1:]):
            m+=1


# In[208]:

m


# In[71]:

T['scaling behavior in the dynamics of an economic index'.lower()],W[19701716]


# In[73]:

T['latent dirichlet allocation'],W[27259529]


# In[ ]:




# In[79]:

T['mapping the backbone of science'],W[29774502]


# In[81]:

T['scaling of the distribution of fluctuations of financial market indices'],W[23679687]


# In[82]:

T['the nested chinese restaurant process and bayesian nonparametric inference of topic hierarchies']


# In[83]:

W[35783349]


# # Ming li

# In[203]:

T['a set of postulates for the foundation of logic.'],W[591648][2:]


# In[104]:

T['on computable numbers, with an application to the entscheidungsproblem']##D=0.22


# In[ ]:




# In[204]:

T['dissipative quantum church-turing theorem'],W[38416856][2:]


# In[205]:

T['a linear logical framework'],W[26677721][2:]


# In[171]:

T['polynomial-time algorithms for prime factorization and discrete logarithms on a quantum computer']


# In[206]:

W[23322527][2:]


# In[207]:

T['programmable and autonomous computing machine made of biomolecules'],W[25664849][2:]


# In[434]:




# In[435]:

[Title[i] for i in d if 'test' in Title[i] and 'parity' in Title[i]]


# In[384]:

cc=Counter([W[i][-3] for i in W if W[i][0]==6545])


# In[385]:

cc


# In[ ]:




# # linzhuo

# In[128]:

T['statistical-mechanics of cellular automata'],W[10919798][2:]


# In[129]:

T['on computable numbers, with an application to the entscheidungsproblem']##D=0.22


# In[187]:

n=0
m=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        if 749514 in set(line[1:]):
            m+=1


# In[188]:

m


# In[130]:

T['deterministic nonperiodic flow'],W[2694540][2:]


# In[ ]:




# In[189]:

T['quantifying long-term scientific impact'],W[41864029][2:]


# In[190]:

T['community structure in social and biological networks'],W[26287301][2:]


# In[191]:

T['statistical mechanics of complex networks'],W[25796095][2:]


# In[192]:

T['the structure and function of complex networks'],W[27306864][2:]


# In[193]:

T['error and attack tolerance of complex networks'],W[28638916][2:]


# In[194]:

T['complex networks: structure and dynamics'],W[30476908][2:]


# # lei dong

# In[ ]:

#Watson, J. D., & Crick, F. H. (1953). Molecular structure of nucleic acids. Nature, 171(4356), 737-738.


# In[215]:

T['regression shrinkage and selection via the lasso'],W[20085875]


# In[ ]:

#Yang, C. N., & Mills, R. L. (1954). Conservation of isotopic spin and isotopic gauge invariance. Physical review, 96(1), 191.


# In[247]:

T['the central role of the propensity score in observational studies for causal effects'],W[10732067][2:]


# In[ ]:




# In[ ]:

# developing
#(wrong)  Bettencourt, L. M., Lobo, J., Helbing, D., Kühnert, C., & West, G. B. (2007). Growth, innovation, scaling, and the pace of life in cities. Proceedings of the national academy of sciences, 104(17), 7301-7306.
#
#Popularity similarity


# # Pang zhang

# In[342]:

T['optimization by simulated annealing'],W[10801517]


# In[345]:

T['nonequilibrium equality for free energy differences'],W[21307712]


# In[348]:

T['Exchange Monte Carlo method and application to spin glass simulations'.lower()],W[20508348]


# In[350]:

T['efficient, multiple-range random walk algorithm to calculate the density of states'],W[25055445]


# In[ ]:




# # Xiong wang

# In[357]:

T['thermodynamics of spacetime - the einstein equation of state'],W[19760561]


# In[359]:

T['Entropy of Null Surfaces and Dynamics of Spacetime'.lower()],W[31847410]


# In[361]:

T['Dark energy and its implications for gravity'.lower()],W[35029520]


# In[363]:

T['On the Origin of Gravity and the Laws of Newton'.lower()],W[37786325]


# In[365]:

T['classical and quantum thermodynamics of horizons in spherically symmetric spacetimes'],W[26662196]


# In[369]:

T['Thermodynamical Aspects of Gravity: New insights'.lower()],W[36231696]


# In[371]:

T['Holography of gravitational action functionals'.lower()],W[31422254]


# In[ ]:




# In[375]:

T['notes on black-hole evaporation'],W[7038753]


# In[382]:

T['particle creation by black-holes'],W[6567540]


# In[392]:

T['cosmological event horizons, thermodynamics, and particle creation'],W[7414875]


# In[388]:

T['nonuniqueness of canonical field quantization in riemannian space-time'],W[5636301]


# In[390]:

T['Scalar particle production in Schwarzschild and Rindler metrics'.lower()],W[6372956]


# In[ ]:




# In[ ]:




# # Bill

# In[330]:

len(T)


# In[513]:

#116 AMERICAN JOURNAL OF PHYSICS	13
#22 nature
#77 pnas
# 505 Brain Research
#468 cell
#3210 Nature Biotechnology
#432 science
#355 Human Molecular Genetics
#4817 Journal of molecular evolution
#216 Biochemistry
#6545 American journal of sociology
#560 Annalen der physik
#1690 American Mathematical Monthly
#5600 British journal of experimental pathology
#71 REVIEWS OF MODERN PHYSICS
#7226 Publicationes Mathematicae
#950	PHYSICAL REVIEW
#2777	PHYSICA
#280	ANNALS OF MATHEMATICS
#840	PROCEEDINGS OF THE LONDON MATHEMATICAL SOCIETY
#9914	IEEE ANNALS OF THE HISTORY OF COMPUTING
#7587	IRE TRANSACTIONS ON INFORMATION THEORY
#1060	COMMUNICATIONS OF THE ACM
#1489	JOURNAL OF THE ROYAL STATISTICAL SOCIETY
#4373	JOURNAL OF EXPERIMENTAL PSYCHOLOGY-LEARNING MEMORY AND COGNITION
#4131	JOURNAL OF EDUCATIONAL PSYCHOLOGY
#3504	JOURNAL OF THE ACM
#280	ANNALS OF MATHEMATICS
#168	PHYSICAL REVIEW LETTERS
#5901	COMMUNICATIONS IN MATHEMATICAL PHYSICS
#4058	INTERNATIONAL JOURNAL OF THEORETICAL PHYSICS
#516	ADVANCES IN MATHEMATICS	9
#794	JOURNAL OF MATHEMATICAL PHYSICS
d=[i for i in W if W[i][0]==794 and W[i][-3]==1980]
len(d)


# In[514]:

[Title[i] for i in d if 'planar' in Title[i]]


# In[ ]:




# In[ ]:




# In[336]:

T['modular elliptic-curves and fermats last theorem'],W[19563428]


# In[340]:

T['bounded gaps between primes'],W[42794229]


# In[465]:

T['onp-adic representations for totally real fields']


# # Xian fang

# In[ ]:




# In[530]:

T['the euler characteristic of the moduli space of curves'],W[12780294][2:]


# In[531]:

T['differential operators on a semisimple lie algebra'],W[1951493][2:]


# In[532]:

T['planar approximation .2.'],W[8920192][2:]


# In[533]:

T['hopf algebra of the planar binary trees'],W[22746522][2:]


# In[534]:

T['uniform infinite planar triangulations'],W[27631131][2:]


# In[535]:

T['planar maps as labeled mobiles'],W[28718725][2:]


# In[536]:

T['hurwitz numbers and intersections on moduli spaces of curves'],W[25616193][2:]


# In[537]:

T['limit of normalized quadrangulations: the brownian map'],W[31343472][2:]


# In[538]:

T['holomorphic anomaly and matrix models'],W[32187127][2:]


# In[ ]:




# In[539]:

T['A direct bijection for the Harer-Zagier formula'.lower()],W[29776680][2:]


# In[540]:

T['a pattern for the asymptotic number of rooted maps on surfaces'],W[18277214][2:]


# In[ ]:




# In[ ]:




# # Lei Ma

# In[450]:

T['stochastic problems in physics and astronomy'],W[929385][2:]


# In[451]:

T['synthesis of the elements in stars'],W[1907700][2:]


# In[452]:

T['the theory of a general quantum system interacting with a linear dissipative system'],W[2684021][2:]


# In[453]:

T['Constraints on cosmological models from Hubble Space Telescope observations of high-z supernovae'.lower()],W[22070604][2:]


# In[454]:

T['neutrino oscillations and stellar collapse'],W[8777958][2:]


# In[462]:

T['a new model for the expanding universe'.lower()],W[1181874][2:]


# In[457]:

T['relativistic cosmology'],W[625611][2:]


# In[458]:

T['on the origin of great nebulae'],W[827323][2:]


# In[ ]:




# In[459]:

T['grand unified theories and proton decay'],W[9718229][2:]


# In[460]:

T['the cosmological constant and dark energy'],W[27148927][2:]


# In[461]:

T['quantum complexity theory'],W[21701261][2:]


# In[ ]:




# # Molly

# In[14]:

T['cumulative cultural evolution in the laboratory: an experimental approach to the origins of structure in human language'],W[33782802]


# In[308]:

T['statistical learning by 8-month-old infants'],W[20936061][2:]


# In[309]:

T['addition and subtraction by human infants'],W[17387906][2:]#Disruptive


# In[ ]:




# In[310]:

#developing
T['minimization of boolean complexity in human concept learning'],W[24606073][2:]


# In[311]:

T['innateness and culture in the evolution of language'],W[31896785][2:]


# In[312]:

T['infant rule learning: advantage language, or advantage speech?'],W[39796191][2:]


# In[ ]:




# # Xiaoda 

# In[8]:

A=set(['learning internal representations by error-propagation',
           'a fast learning algorithm for deep belief nets',
            'gradient-based learning applied to document recognition',
            'imagenet classification with deep convolutional neural networks',
            'long short-term memory',
            'mastering the game of Go with deep neural networks and tree search',
            'sequence to sequence learning with neural networks',
            'neural machine translation by jointly learning to align and translate',
            'generative adversarial nets',
            'a neural probabilistic language model'
           ])


# In[7]:

B=set(['deep residual learning for image recognition',
       'distributed representations of words and phrases and their compositionality',
       'human-level control through deep reinforcement learning',
       'dropout: a simple way to prevent neural networks from overfitting',
       'batch normalization: accelerating deep network training by reducing internal covariate shift',
       'convolutional sequence to sequence learning',
       'attention is all you need',
       'hybrid computing using a neural network with dynamic external memory',
       'mastering the game of go without human knowledge',
       'generating sequences with recurrent neural networks'
       ])


# In[583]:

sorted([(W[T[i]][2:],T[i],i) for i in A if i in T],reverse=True)


# In[585]:

[(T[i],i,W[T[i]][2:]) for i in B if i in T]


# In[ ]:




# # yangyang

# In[232]:

T['how long is coast of britain - statistical self-similarity and fractional dimension'],D[3489890]


# In[557]:

m=0
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        if 3489890 in set(line[1:]):
            m+=1


# In[ ]:

#D=0.82683982684


# In[210]:

T['deterministic nonperiodic flow'],W[2694540]


# In[211]:

T["collective dynamics of 'small-world' networks"],W[22399745]


# In[ ]:




# In[218]:

T['emergence of scaling in random networks'],W[23638776]


# In[214]:

T['controllability of complex networks'],W[37934765]


# In[215]:

T['catastrophic cascade of failures in interdependent networks'],W[36288091]


# # Qianyuan

# In[571]:

T['the origin and behavior of mutable loci in maize'],W[1335824][2:]


# In[574]:

T['fluctuation-dissipation theorem'],W[3337846][2:]


# In[570]:

T['principles that govern folding of protein chains'],W[5668301][2:]


# In[961]:

T['period 3 implies chaos'],W[6577389][2:]


# In[569]:

T['preponderance of synonymous changes as evidence for neutral theory of molecular evolution'],W[7366649][2:]


# In[572]:

T['dynamic scaling of growing interfaces'],W[12952730][2:]


# In[573]:

T['nonequilibrium equality for free energy differences'],W[21307712][2:]


# In[ ]:




# In[575]:

T['renormalization group and critical phenomena .1. renormalization group and kadanoff scaling picture'],W[4996042][2:]


# In[576]:

T['genetic-transformation of drosophila with transposable element vectors'],W[10423972][2:]


# In[578]:

T['spin-glasses and the statistical-mechanics of protein folding'],W[14028182][2:]


# In[577]:

T["green-function approach to linear response in solids"],W[13767305][2:]


# In[579]:

T['controlling chaos'],W[19540255][2:]


# In[580]:

T['entropy production fluctuation theorem and the nonequilibrium work relation for free energy differences'],W[23535744][2:]


# In[581]:

T['the molecular evolution of acquired resistance to targeted egfr blockade in colorectal cancers'],W[39691383][2:]


# # Pan Zhang

# In[307]:

T['solvable model of a spin-glass'],W[6587143]


# In[296]:

T['message-passing algorithms for compressed sensing'],W[35580450]


# In[305]:

T['efficient learning in boltzmann machines using linear response theory'],W[22439332]


# In[300]:

T['asymptotic analysis of the stochastic block model for modular networks and its algorithmic applications'],W[38768969]


# In[298]:

T['the dynamics of message passing on dense graphs, with applications to compressed sensing'],W[37500086]


# In[294]:

T['analytic and algorithmic solution of random satisfiability problems'],W[26421826]


# In[292]:

T['infinite number of order parameters for spin-glasses'],W[8733589]


# In[309]:

T['solution of solvable model of a spin glass'],W[7306369]


# In[311]:

T['statistical-physics-based reconstruction in compressed sensing'],W[39543907]


# In[ ]:




# In[315]:

T['instability of one-step replica-symmetry-broken phase in satisfiability problems'],W[28088238]


# In[317]:

T['gibbs states and the set of solutions of random constraint satisfaction problems'],W[32219605]


# In[322]:

T['the bethe lattice spin glass revisited'],W[25043534]


# In[313]:

T['the sherrington-kirkpatrick model: an overview'],W[40126657]


# In[327]:

T['ising model for neural data: model quality and approximate methods for extracting functional connectivity'],W[34883632]


# In[331]:

T['the bethe approximation for solving the inverse ising problem: a comparison with other inference methods'],W[39882170]


# # Jiang Zhang

# In[612]:

T['a general model for the origin of allometric scaling laws in biology'],W[21306675][2:]


# In[608]:

T["collective dynamics of 'small-world' networks"],W[22399745][2:]


# In[613]:

T['size and form in efficient transportation networks'],W[23287454][2:]


# In[674]:

T['a general model for the structure and allometry of plant vascular systems'],W[23485413][2:]


# In[615]:

T['the origin of allometric scaling laws in biology from genomes to ecosystems: towards a quantitative unifying theory of biological structure and organization'],W[29526858][2:]


# In[609]:

T['popularity versus similarity in growing networks'],W[40059452][2:]


# In[610]:

T['the hidden geometry of complex, network-driven contagion phenomena'],W[42137564][2:]


# In[ ]:




# In[616]:

T['emergence of scaling in random networks'],W[23638776][2:]


# In[617]:

T['universal scaling relations in food webs'],W[27251477][2:]


# In[618]:

T['the product space conditions the development of nations'],W[32316137][2:]


# In[619]:

T['growth, innovation, scaling, and the pace of life in cities'],W[32015156][2:]


# In[620]:

T['the origins of scaling in cities'],W[41361385][2:]


# In[ ]:




# # Yizhuang

# In[623]:

T['New Method for High-Accuracy Determination of the Fine-Structure Constant Based on Quantized Hall Resistance'.lower()],W[9117188][2:]


# In[626]:

T['inflationary universe - a possible solution to the horizon and flatness problems'],W[9418664][2:]


# In[627]:

T['experimental test of bell inequalities using time-varying analyzers'],W[10527603][2:]


# In[633]:

T['3-dimensional viscous confinement and cooling of atoms by resonance radiation pressure'],W[12270830][2:]


# In[629]:

T['superconductivity at 93-k in a new mixed-phase y-ba-cu-o compound system at ambient pressure'],W[13657056][2:]


# In[630]:

T['evidence for oscillation of atmospheric neutrinos'],W[22542352][2:]


# In[631]:

T['random graphs with arbitrary degree distributions and their applications'],W[25397340][2:]


# In[632]:

T['topological insulators with inversion symmetry'],W[32278080][2:]


# In[351]:

W[28512086],W[28512085]


# # Hiabo

# In[597]:

T['a mathematical theory of communication'],W[1139077][2:]# this is the right one


# In[598]:

T['deterministic nonperiodic flow'],W[2694540][2:]


# In[423]:

T['how long is coast of britain - statistical self-similarityand fractional dimension'],D[3489890]


# In[599]:

T['gaia as seen through atmosphere'],W[5288369][2:]


# In[600]:

T['statistical-mechanics of cellular automata'],W[10919798][2:]


# In[ ]:




# In[676]:

T['Non-Cooperative Games'.lower()],W[1382615]


# In[602]:

T['coevolution of neocortical size, group-size and language in humans'],W[18332946][2:]


# In[603]:

T['a general model for the origin of allometric scaling laws in biology'],W[21306675][2:]


# In[604]:

T["collective dynamics of 'small-world' networks"],W[22399745][2:]


# In[605]:

T['emergence of scaling in random networks'],W[23638776][2:]


# In[606]:

T['the origin of bursts and heavy tails in human dynamics'],W[29551986][2:]


# In[607]:

T['catastrophic cascade of failures in interdependent networks'],W[36288091][2:]


# # xunmo

# In[638]:

T['Inhomogeneous electron gas'.lower()],W[2715507][2:]


# In[679]:

T['Self-consistent equations including exchange and correlation effects'.lower()],W[3066775][2:]


# In[725]:

T['generalized gradient approximation made simple'],W[20807103]


# In[ ]:




# In[707]:

T['Efficient pseudopotentials for plane-wave calculations'.lower()],W[16317537]


# In[705]:

T['Self-interaction correction to density-functional approximations for many-electron systems'.lower()],W[9595742][2:]


# In[717]:

t='an efficient implementation of time-dependent density-functional theory for the calculation of excitation energies of large molecules'
T[t],W[22749396][2:]


# In[727]:

T['Scalable molecular dynamics with NAMD'.lower()],W[30109848]


# In[759]:

T['efficient pseudopotentials for plane-wave calculations'],W[16317537]


# In[ ]:




# # Qingqin liu

# In[789]:

W[1524833]#'a structure for deoxyribose nucleic acid'


# In[ ]:




# In[814]:

T['hippocampus as a spatial map - preliminary evidence from unit activity in freely-moving rat'],W[5008873]


# In[819]:

T['a novel multigene family may encode odorant receptors - a molecular-basis for odor recognition'],W[16470959]


# In[791]:

T['sheep cloned by nuclear transfer from a cultured cell line'],W[20309084]


# In[805]:

T['Fluorescent indicators for Ca2+ based on green fluorescent proteins and calmodulin'.lower()],W[21595245]


# In[803]:

T['single na+ channel currents observed in cultured rat muscle-cells'],W[9196956]


# In[793]:

T['millisecond-timescale, genetically targeted optical control of neural activity'],W[29847769]


# In[807]:

T['optogenetic stimulation of a hippocampal engram activates fear memory recall'],W[39432157]


# In[795]:

T['Multiplex Genome Engineering Using CRISPR/Cas Systems'.lower()],W[40818999]


# In[ ]:




# In[922]:

T['geometric determinants of the place fields of hippocampal neurons'],W[20471872][2:]


# In[923]:

T['a high signal-to-noise ca2+ probe composed of a single green fluorescent protein'],W[24945238][2:]


# In[924]:

T['microstructure of a spatial map in the entorhinal cortex'],W[29811599][2:]


# In[925]:

T['high-speed mapping of synaptic connectivity using photostimulation in channel rhodopsin-2 transgenic mice'],W[32097845][2:]


# In[926]:

T['multimodal fast optical interrogation of neural circuitry'],W[32000539][2:]


# In[927]:

T['creating a false memory in the hippocampus'],W[41481716][2:]


# In[928]:

T['optimized ratiometric calcium sensors for functional in vivo imaging of neurons and t lymphocytes'],W[42460290][2:]


# In[ ]:




# # Weiwei Chou

# In[907]:

1524833,W[1524833][2:]#'a structure for deoxyribose nucleic acid'


# In[908]:

T['central dogma of molecular biology'],W[4553191][2:]


# In[909]:

T['continuous cultures of fused cells secreting antibody of predefined specificity'],W[6428493][2:]


# In[910]:

T['mutations affecting segment number and polarity in drosophila'],W[9242554][2:]


# In[911]:

T['enzymatic amplification of beta-globin genomic sequences and restriction site analysis for diagnosis of sickle-cell anemia'
],W[12589102][2:]


# In[913]:

T['the p53 proto-oncogene can act as a suppressor of transformation'],W[15202103][2:]


# In[912]:

T['Human Whole-Genome Shotgun Sequencing'.lower()],W[21344876][2:]


# In[914]:

T['the sequence of the human genome'],W[24992293][2:]


# In[ ]:




# In[920]:

T['antibody production by single cells'],W[2059859][2:]


# In[919]:

T['Organic Compound Synthesis on the Primitive Earth'.lower()],W[2157658][2:]


# In[915]:

T['chemical and physical-properties of aequorin and green fluorescent protein isolated from aequorea-forskalea'],W[8030085][2:]


# In[917]:

T['intervening sequences of regularly spaced prokaryotic repeats derive from foreign genetic elements'],W[29239492][2:]


# In[916]:

T['A Whole-Cell Computational Model Predicts Phenotype from Genotype'.lower()],W[39797745][2:]


# In[ ]:




# In[ ]:




# # Lin Wang

# In[988]:

T['law of energy distribution in normal spectra'],W[20509][2:]


# In[954]:

1524833,W[1524833][2:]#'a structure for deoxyribose nucleic acid'


# In[958]:

T['period 3 implies chaos'],W[6577389]


# In[962]:

T["collective dynamics of 'small-world' networks"],W[22399745][2:]


# In[ ]:




# In[ ]:




# In[989]:

T['Mapping the Antigenic and Genetic Evolution of Influenza Virus'.lower()],W[28543726][2:]


# In[990]:

T['integrating influenza antigenic dynamics with molecular evolution'],W[42512344][2:]


# In[991]:

T['aerosol transmission is an important mode of influenza a virus spread'],W[41325996][2:]


# In[977]:

T['emergence of scaling in random networks'],W[23638776][2:]


# In[992]:

T['on the theory of the brownian motion-ii'],W[981624][2:]


# In[993]:

T['epochal evolution shapes the phylodynamics of interpandemic influenza a (h3n2) in humans'],W[31458546][2:]


# In[1002]:

#22 nature
#77 pnas
# 505 Brain Research
#468 cell
#3210 Nature Biotechnology
#432 science
#355 Human Molecular Genetics
#4817 Journal of molecular evolution
#216 Biochemistry
#6545 American journal of sociology
#560 Annalen der physik
#1690 American Mathematical Monthly
#5600 British journal of experimental pathology
#71 REVIEWS OF MODERN PHYSICS
#7226 Publicationes Mathematicae
d=[i for i in W if W[i][0]==432  and W[i][-3]==2002]
len(d)


# # best pairs

# In[1006]:

len(W)


# In[1008]:

fm={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}


# In[1023]:

d=[i for i in W if W[i][1]==12  and W[i][2]<-0.2 and W[i][-1]>1000]


# In[1024]:

len(d)


# In[1014]:

Title[13869522]


# In[1016]:

T['vortices in high-temperature superconductors'],W[19044673]


# # AUC/ROC

# In[7]:

from sklearn import metrics


# In[4]:

y = np.array([1, 1, 2, 2])


# In[5]:

pred = np.array([0.1, 0.4, 0.35, 0.8])


# In[6]:

fpr, tpr, thresholds = metrics.roc_curve(y, pred, pos_label=2)


# In[7]:

metrics.auc(fpr, tpr)


# In[19]:

y=[1,1,1,0,0,0]+[1,1,1,1,0]+[1,1,1,1,0,0,0,0,0,0]+[1,1,1,1,1,1,1,0,0,0,0,0,0,0]+[1]*3+[0]*5+[1]*8+[0]*5+[1]*6+[0]*6+[1]*5+[0]*3+[1]*9+[0]*7+[1]*5+[0]*7+[1]*3+[0]*6+[1]*3+[0]*4+[1]*5+[0]*3+[1]*6+[1]*4+[0]*2+[1]*3+[0]*3+[1]*4+[0]*6+[1]*5+[0]*7+[1]*8+[0]*3+[1]*9+[0]*2


# In[11]:

len(y)


# In[18]:

pred=[.86,.83,.48,-0.06,-0.012,-0.005]+[0.0218,0.0246,0.0196,0.0478,-0.0002]+[0.81,0.88,0.08,0.48,-0.009,-0.0007,-0.005,-0.060,-0.00013,-0.006]+[0.13,0.0756,0.23,0.08,0.04,0.02,0.07,-0.053,0.06,-0.0029,-0.0025,-0.0071,-0.022,-0.0063]+[0.87,-0.22,0.17,-0.05,-0.05,-0.035,-0.047,-0.05]+[0.88,0.11,0.56,0.22,0.77,-0.023,0.0007,0.015,-0.005,-0.025,-0.0002,-0.0027,-0.0026]+[0.53,0.28,0.86,0.83,0.092,0.043,0.036,0.054,0.27,0.48,-0.060,-0.012]+[0.65,0.13,0.07,-0.04,-0.032,-0.09,-0.02,-0.055]+[0.88,0.18,0.023,0.114,0.013,-0.0105,-0.011,-0.0093,-0.109,-0.027,-0.009,-0.059,-0.020,-0.055,-0.004,-0.0003]+[0.27,0.48,-0.025,-0.01,-0.0009,-0.060,-0.03,-0.008,-0.01,0.005,0.009,-0.0015]+[0.86,0.043,0.22,-0.0008,-0.014,-0.102,-0.082,-0.0042,-0.022]+[0.27,0.0027,0.93,-0.060,-0.078,-0.19,0.022]+[0.53,0.13,0.92,0.022,0.43,-0.01,-0.050,-0.0002]+[0.10,0.22,-0.003,-0.007,-0.002,-0.001]+[0.88,0.27,0.32,0.43,0.009,-0.01]+[0.36,0.13,-0.013,-0.0046,-0.0000001,0.001]+[0.20,0.069,0.015,-0.0063,-0.031,-0.042,-0.014,-0.0002,-0.004,-0.007]+[0.028,0.019,0.0047,-0.025,-0.060,-0.025,-0.005,-0.0004,-0.004,-0.019,-0.007,-0.007]+[0.42,0.17,0.039,0.062,-0.003,-0.18,0.044,0.143,-0.009,-0.03,-0.02]+[0.489,0.159,0.042,0.025,0.0017,-0.021,-0.050,-0.017,-0.012,-0.018,-0.022]


# In[13]:

fpr, tpr, thresholds = metrics.roc_curve(y, pred, pos_label=1)
metrics.auc(fpr, tpr)


# In[16]:

#extreme papers
y=[1]*20+[0]*20
pred=[0.5]*20+[-0.5]*14+[0.5]*6
fpr, tpr, thresholds = metrics.roc_curve(y, pred, pos_label=1)
metrics.auc(fpr, tpr)


# In[26]:

np.mean([j for i,j in zip(y,pred) if i==1]),len([j for i,j in zip(y,pred) if i==1])


# In[27]:

np.mean([j for i,j in zip(y,pred) if i==0]),len([j for i,j in zip(y,pred) if i==0])


# In[ ]:



