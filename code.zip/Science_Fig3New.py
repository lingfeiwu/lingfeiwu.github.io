
# coding: utf-8

# In[3]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
from scipy import stats

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

def log2linearBin(x,y):
    x=np.log2(x)
    a=[]
    q=sorted(zip(map(int,x),y))
    tag = ''
    d=[]
    for i in q:
        x1,y1 = i
        if x1 == tag: 
            d.append(y1)
        else:   
            if tag:   
                a.append([tag,np.mean(d)])
            tag = x1
            d = []
    a.append([tag,np.mean(d)])
    nx,ny = np.array(a).T
    return 2**nx,ny


# In[48]:

from pandas import DataFrame
from pandas import ExcelWriter

def save_xls(sheetnames,list_dfs, xls_path):
    writer = ExcelWriter(xls_path)
    for n, df in zip(sheetnames,list_dfs):
        df.to_excel(writer,n)
    writer.save()


# # export data

# In[49]:

a = DataFrame({'Team size': range(1,11), '0-10%': disImpact[1][1],'10-50%': disImpact[2][1],'50-75%': disImpact[3][1]                , '75-90%': disImpact[4][1],'90-95%': disImpact[5][1],'95-100%': disImpact[6][1]})


# In[61]:

b = DataFrame({'Team size': range(1,11),fd[12]:disField[12][1],fd[1]:disField[1][1],fd[10]:disField[10][1],fd[6]:disField[6][1],               fd[3]:disField[3][1],fd[0]:disField[0][1],fd[13]:disField[13][1],fd[5]:disField[5][1],fd[4]:disField[4][1]})


# In[62]:

c = DataFrame({'mean':[50.67002,50.20842 ,49.74683 ,49.28524 ,48.82365 ,48.36206 ,47.90047,47.43888,46.97729,46.5157 ],
               'upper':[49.19128,49.07012,48.92893 ,48.73174 ,48.36769 , 47.75083,47.00412,46.21518 ,45.41025,44.59791 ],
               'lower':[52.14875,51.34673,50.56474,49.83874,49.27962,48.97329,48.79682,48.66258,48.54432,48.43348]
               })


# In[64]:

xls_path='/Users/lingfeiw/Dropbox/teams/2 submit nature/0 final/Figure3/Figure3.xlsx'
save_xls(['a','b','c'],         [a,b,c], xls_path)


# In[ ]:




# In[ ]:




# In[79]:

#regression results
#with 100D topic 
ms=[46.75006,46.13893,45.52781,44.91668,44.30555,43.69443,43.0833,42.47217,41.86105,41.24992]
a=[46.18,45.68,45.18,44.65,44.08,43.43,42.74,42.02,41.29,40.56]
b=[47.31853,46.5911,45.87344,45.17778,44.53048,43.95271,43.42467,42.91946,42.42434,41.9342]


# In[1]:

#regression results
#with 100D topic 10,000 scholars
ms=[50.67002,50.20842 ,49.74683 ,49.28524 ,48.82365 ,48.36206 ,47.90047,47.43888,46.97729,46.5157 ]
a=[49.19128,49.07012,48.92893 ,48.73174 ,48.36769 , 47.75083,47.00412,46.21518 ,45.41025,44.59791 ]
b=[52.14875,51.34673,50.56474,49.83874,49.27962,48.97329,48.79682,48.66258,48.54432,48.43348]


# In[6]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#cmap1 = cm.get_cmap('rainbow',6)
ax = fig.add_subplot(111)


ax.set_xlim(1,10)
#ax.set_ylim(40,48)
#ax.set_yticks([40,42,44,46,48])
ax.set_xticks([2,4,6,8,10])
plt.plot(range(1,11),ms,color='RoyalBlue',linewidth=1.5,label='-0.61***')
plt.fill_between(range(1,11),a,b,color='Gray',alpha=0.3,label='95% CI')
plt.legend(loc=1,frameon=False)
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Margins.pdf')


# In[80]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#cmap1 = cm.get_cmap('rainbow',6)
ax = fig.add_subplot(111)


ax.set_xlim(1,10)
ax.set_ylim(40,48)
ax.set_yticks([40,42,44,46,48])
ax.set_xticks([2,4,6,8,10])
plt.plot(range(1,11),ms,color='RoyalBlue',linewidth=1.5,label='-0.61***')
plt.fill_between(range(1,11),a,b,color='Gray',alpha=0.3,label='95% CI')
plt.legend(loc=1,frameon=False)
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Margins.pdf')


# In[8]:

#without 100D topic 
ms=[46.73396,46.12684,45.51972,44.91259,44.30547,43.69834,43.09122,42.48409,41.87697,41.26984]
a=[46.17,45.68,45.17,44.65,44.07,43.44,42.75,42.04,41.32,40.59]
b=[47.29466,46.57364,45.86245,45.17315,44.53106,43.95617,43.4298,42.92612,42.43259,41.9441]


# In[34]:

#with author control
ms1=[44.48395,44.43629,44.38864,44.34098,44.29332,44.24566,44.198,44.15034,44.10269,44.05503]
a1=[43,43.25,43.38,43.45,43.45,43.36,43.2,42.99,42.74,42.47]
b1=[45.86291,45.61307,45.39545,45.22878,45.13495,45.12549,45.19072,45.30901,45.46104,45.63408]


# In[75]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#cmap1 = cm.get_cmap('rainbow',6)
ax = fig.add_subplot(111)


ax.set_xlim(1,10)
ax.set_ylim(40,48)
ax.set_yticks([40,42,44,46,48])
ax.set_xticks([2,4,6,8,10])
plt.plot(range(1,11),ms,color='RoyalBlue',linewidth=1.5,label='-0.61***')
plt.fill_between(range(1,11),a,b,color='Gray',alpha=0.3,label='95% CI')
plt.legend(loc=1,frameon=False)
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Margins.pdf')


# In[58]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#cmap1 = cm.get_cmap('rainbow',6)
ax = fig.add_subplot(111)


ax.set_xlim(1,10)
ax.set_ylim(40,48)
ax.set_yticks([40,42,44,46,48])
ax.set_xticks([2,4,6,8,10])
plt.plot(range(1,11),ms,color='RoyalBlue',linewidth=1.5,label='After controlling author')
plt.fill_between(range(1,11),a,b,color='Blue',alpha=0.1)
plt.plot(range(1,11),ms1,color='gray',linewidth=1.5,linestyle='--'         ,label='Before controlling author')
plt.xlabel('Team size',size=14)
plt.ylabel('Linear prediction of disruption percentile',size=14)
plt.legend(loc=1,frameon=False)
plt.fill_between(range(1,11),a1,b1,color='Gray',alpha=0.05)
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Margins2.pdf')


# In[8]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(subject),int(year),int(teamsize),float(timegap),float(meanimp),float(impact),float(disruptive)]


# In[9]:

S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[10]:

Disruptive=[v[-1] for v in W1.values()]
drss=random.sample([v[-1] for v in W1.values()],100000)
stats.percentileofscore(drss, 0)


# ### by impact 

# In[12]:

Impact=[v[-2] for v in W1.values()]


# In[17]:

drss=random.sample([v[-1] for v in W1.values()],10000)
stats.percentileofscore(drss, 0)


# In[5]:

np.percentile(Impact,10),np.percentile(Impact,50),np.percentile(Impact,75),np.percentile(Impact,90),np.percentile(Impact,95)


# In[18]:

DisImpact=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if 1<=teamsize<=10 and impact>0:
        '''
        if impact==1:
            ilevel=1
        if 2<=impact<=3:
            ilevel=2
        if 4<=impact<=10:
            ilevel=3           
        if 11<=impact<=20:
            ilevel=4           
        if 21<=impact:
            ilevel=5
        '''
        if impact<=1:
            ilevel=1
        if 1<impact<10:
            ilevel=2
        if 10<=impact<24:
            ilevel=3           
        if 24<=impact<53:
            ilevel=4           
        if 53<=impact<84:
            ilevel=5
        if impact>=84:
            ilevel=6
        DisImpact[ilevel][teamsize].append(disruptive)
disImpact={}
disImpact1={}
for ilevel in [1,2,3,4,5,6]:
    disImpact[ilevel]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                   for k,v in DisImpact[ilevel].items()]))
    disImpact1[ilevel]=zip(*sorted([(k,np.mean(v)) for k,v in DisImpact[ilevel].items()]))


# ### by field

# In[57]:

fd={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}


# In[20]:

DisField=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if subject not in [7,8,9,11] and impact>=3:
        if subject ==2:
            subject=13
        DisField[subject][teamsize].append(disruptive)


# In[21]:

disField={}
disField1={}
for subject in DisField:
    disField[subject]=np.array((sorted([(k,stats.percentileofscore(drss, np.mean(DisField[subject][k])),len(DisField[subject][k]))                                   for k in range(1,11)]))).T
    disField1[subject]=np.array((sorted([(k,np.mean(DisField[subject][k]),len(DisField[subject][k])) for k in range(1,11)]))).T


# In[7]:

SlepField=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in S1:
        subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
        sleep=S1[i]
        if subject not in [7,8,9,11] and impact>=2:
            if subject ==2:
                subject=13
            SlepField[subject][teamsize].append(sleep)
slepField={}
for subject in SlepField:
    slepField[subject]=zip(*sorted([(k,np.mean(v)) for k,v in SlepField[subject].items()]))


# In[21]:

slepField1={}
for subject in slepField:
    x,y=slepField[subject]
    ys=[stats.percentileofscore(sleepSample, i) for i in y]
    slepField1[subject]=[x,ys]


# In[54]:

sss=[]
for subject in [12,1,10,6,3,0,13,5,4]:
    ss=[]
    for ts in SlepField[subject]:
        ss+=SlepField[subject][ts]
    aa=[]
    for ts in DisField[subject]:
        aa+=DisField[subject][ts]
    sss.append([fd[subject],stats.percentileofscore(sleepSample,np.mean(ss)),stats.percentileofscore(drss, np.mean(aa))])


# In[145]:

fig = plt.figure(figsize=(12,8),facecolor='white')


cmap1 = cm.get_cmap('summer_r',6)
ax = fig.add_subplot(231)
ip={1:'1',2:'2-3',3:'4-10',4:'11-20',5:'>20'}
for ilevel in [1,2,3,4,5]:
    x,y=disImpact[ilevel]
    plt.plot(x,y,color=cmap1(ilevel),linewidth=1.5,label=ip[ilevel])
ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[67,67],'k--',alpha=0.3)
ax.tick_params(axis='x', which='both',bottom='on',top='off')
plt.legend(frameon=False,loc=3,fontsize=10)
ax.set_xlabel('Team size',fontsize=14)
ax.set_ylabel('Disruption Percentile',fontsize=14)

#
cmap2 = cm.get_cmap('jet_r',9)
ax = fig.add_subplot(232)
n=0
for subject in [12,1,10,6,3,0,13,5,4]:
    x,y=disField[subject]
    plt.plot(x,y,color=cmap2(n),linewidth=1.5,label=fd[subject])
    n+=1
ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[67,67],'k--',alpha=0.3)
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.set_xlabel('Team size',fontsize=14)
ax.set_ylabel('Disruption Percentile',fontsize=14)
#
ax = fig.add_subplot(236)
n=0
for subject,dx in zip([12,1,10,6,3,0,13,5,4][::-1],                      ['1.4','2.3','3.3','3.5','4.4','5.3','6.5','NA','NA'][::-1]):
    plt.plot([1.5,2],[n+1.2,n+1.2],color=cmap2(8-n),linewidth=2)
    plt.text(2.5,n+1,dx,size=14)
    plt.text(4,n+1,fd[subject],size=14)
    n+=1
ax.set_xlim(1,13)
ax.set_ylim(0,12)
ax.tick_params(axis='x', which='both',bottom='on',top='off')
plt.axis('off')
#
ax = fig.add_subplot(233)
n=0
for subject in [12,1,10,6,3,0,13,5,4]:
    x,y=slepField[subject]
    plt.plot(x,y,color=cmap2(n),linewidth=1.5,label=fd[subject])
    n+=1
ax.set_xlim(1,10)
ax.set_ylim(1,10)
ax.set_yticks([0,2.5,5,7.5,10])
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.set_xlabel('Team size',fontsize=14)
ax.set_ylabel('Sleeping Beauty Index',fontsize=14)
#plt.legend(loc=1,fontsize=8)

#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3New.pdf')


# In[ ]:




# In[176]:

for subject in [12,1,10,6,3,0,13,5,4]:
    x,y=disField[subject]
    z = np.polyfit(x[:10],y[:10], 9)
    p = np.poly1d(z)
    et=np.round(sorted([[np.abs(p(i)-70.6),i] for i in np.linspace(1,10,100)])[0][1],1)
    print fd[subject],et


# In[ ]:




# In[9]:

fig = plt.figure(figsize=(5,5),facecolor='white')
cmap1 = cm.get_cmap('summer_r',7)
ax = fig.add_subplot(111)
ip={1:'0-10',2:'10-50',3:'50-75',4:'75-90',5:'90-95',6:'95-100'}
for ilevel in [1,2,3,4,5,6]:
    x,y=disImpact[ilevel]
    plt.plot(x,y,color=cmap1(ilevel),linewidth=2,alpha=1,label=ip[ilevel])
ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)

#plt.legend(frameon=False,loc=3,fontsize=10)
#ax.set_xlabel('Team size',fontsize=14)
#ax.set_ylabel('Disruption Percentile',fontsize=14)
#

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.set_xticklabels('')
ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.1.pdf')



# In[8]:

cs={12:'#800000',1:'#FF1400',10:'#FF7D00',    6:'#C69C6D',    3:'#79BA3A',0:'#39B2A3',13:'#0070B5',    5:'#ABC7D6',4:'#B3B3B3'}


# In[10]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#cmap1 = cm.get_cmap('rainbow',6)
cmap2 = cm.get_cmap('jet_r',len(disField)+1)
ax = fig.add_subplot(111)

n=0
for subject in [12,1,10,6,3,0,13,4,5][::-1]:
    x,y=disField[subject]
    n+=1
    plt.plot(x,y,color=cs[subject],marker='',alpha=n/10.0,linewidth=2,label=fd[subject])
    
ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)


plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.2.pdf')


# In[13]:

def DiffusionWeightAverage(threshold,data):#[value,samplesize] in data
    smoothData=[data[0]]
    for n,j in enumerate(data[1:]):
        value,sampleSize=j
        if sampleSize<threshold:
            lastValue,lastSampleSize=smoothData[n-1]
            value=np.average([lastValue,value], weights=[lastSampleSize, sampleSize])
        smoothData.append([value,sampleSize])
    return smoothData


# In[40]:

# smooth exmaple
#
fig = plt.figure(figsize=(5, 10),facecolor='white')
ax = fig.add_subplot(311)
subject=12
x,y,z=disField[subject]
threshold=sum(z)*0.01
smoothData=DiffusionWeightAverage(threshold,zip(y,z))
y1,z1=np.array(smoothData).T
plt.plot(x,y,linestyle='--',color='RoyalBlue',label='No smoothing')
plt.scatter(x,y,s=z/500.0,alpha=0.3)
plt.plot(x,y1,color='Purple',label='1% tail smoothing')
threshold=sum(z)*0.2
smoothData=DiffusionWeightAverage(threshold,zip(y,z))
y2,z2=np.array(smoothData).T
plt.plot(x,y2,color='Chocolate',label='20% tail smoothing')
#plt.scatter(x,y1,s=z/50.0,color='r',alpha=0.3)
plt.xlim(0,10)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption percentile',fontsize=20)
#plt.text(2,86,'Artificial Intelligence',fontsize=14)
plt.legend(loc=1,frameon=False)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(312)
n=0
for subject in [12,1,10,6,3,0,13,4,5][::-1]:
    n+=1
    x,y,z=disField[subject]
    threshold=sum(z)*0.01
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,color=cs[subject],marker='',alpha=(n/11.0)*0.7,linewidth=2,label=fd[subject])
    
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)

plt.text(2,25,'1% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(313)
n=0
for subject in [12,1,10,6,3,0,13,4,5][::-1]:
    n+=1
    x,y,z=disField[subject]
    threshold=sum(z)*0.2
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,color=cs[subject],marker='',alpha=(n/11.0)*0.7,linewidth=2,label=fd[subject])
    
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)

plt.text(2,25,'20% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_SmoothNew.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[34]:

x,y=slepField[12]
zip(x,y)[:10]


# In[27]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#cmap1 = cm.get_cmap('rainbow',6)
cmap2 = cm.get_cmap('jet_r',len(slepField)+1)
ax = fig.add_subplot(111)
n=0
for subject in [12,1,10,6,3,0,13,5,4][::-1]:
    x,y=slepField1[subject]
    n+=1
    plt.plot(x,y,color=cs[subject],linewidth=2,alpha=n/10.0,label=fd[subject])
    
ax.set_xlim(1,10)
ax.set_ylim(60,100)
ax.set_yticks([60,70,80,90,100])
ax.tick_params(axis='x', which='both',bottom='on',top='off')
#plt.legend(loc=1,fontsize=8)


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
#ax.set_xticklabels('')
#ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.3.1.pdf')


# In[ ]:




# In[12]:

D10={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paper10yearDisruptiveness.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        ndoi,n1,n2,n3=map(int,line.strip().split('\t'))
        if n1+n2+n3>0 and ndoi in W1 and W1[ndoi][1]>=1954:
            dis=(n1-n2)/(n1+n2+n3+0.0)
            D10[int(ndoi)]=dis
C10={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paper10yearImpact.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,imp=map(int,line.strip().split('\t'))
        if Id in W1 and W1[Id][1]>=1954:
            C10[Id]=imp


# In[3]:

D20={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paper20yearDisruptiveness.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        ndoi,n1,n2,n3=map(int,line.strip().split('\t'))
        if n1+n2+n3>0 and ndoi in W1 and W1[ndoi][1]>=1954:
            dis=(n1-n2)/(n1+n2+n3+0.0)
            D20[int(ndoi)]=dis
C20={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paper20yearImpact.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,imp=map(int,line.strip().split('\t'))
        if Id in W1 and W1[Id][1]>=1954:
            C20[Id]=imp


# In[4]:

DisTeamsize20=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in C20 and i in D20:
        teamsize=W1[i][2]
        impact=C20[i]
        disruptive=D20[i]
        if 1<=teamsize<=10 and impact>0:
            if impact==1:
                ilevel=1
            if 2<=impact<=3:
                ilevel=2
            if 4<=impact<=10:
                ilevel=3           
            if 11<=impact<=20:
                ilevel=4           
            if 21<=impact:
                ilevel=5
            DisTeamsize20[teamsize][ilevel].append(disruptive)


# In[25]:

DisTeamsize10=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in C10 and i in D10:
        teamsize=W1[i][2]
        impact=C10[i]
        disruptive=D10[i]
        if 1<=teamsize<=10 and impact>0:
            if impact==1:
                ilevel=1
            if 2<=impact<=3:
                ilevel=2
            if 4<=impact<=10:
                ilevel=3           
            if 11<=impact<=20:
                ilevel=4           
            if 21<=impact:
                ilevel=5
            DisTeamsize10[teamsize][ilevel].append(disruptive)


# In[ ]:




# In[29]:

DisTeamsize=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if 1<=teamsize<=10 and impact>0:
        if impact<=1:
            ilevel=1
        if 1<impact<10:
            ilevel=2
        if 10<=impact<24:
            ilevel=3           
        if 24<=impact<53:
            ilevel=4           
        if 53<=impact<84:
            ilevel=5
        if impact>=84:
            ilevel=6
        if teamsize<=3:
            teamsize=0
        if teamsize>3:
            teamsize=1
        DisTeamsize[teamsize][ilevel].append(disruptive)


# In[10]:

drss=random.sample([v[-1] for v in W1.values()],100000)
stats.percentileofscore(drss, 0)


# In[6]:

disTeamsize20_={}
disTeamsize20={}
for ts in range(1,11):
    disTeamsize20_[ts]=zip(*sorted([(k,stats.percentileofscore(drss20, np.mean(v)))                                   for k,v in DisTeamsize20[ts].items()]))
    disTeamsize20[ts]=zip(*sorted([(k,np.mean(v)) for k,v in DisTeamsize20[ts].items()]))


# In[26]:

disTeamsize10_={}
disTeamsize10={}
for ts in range(1,11):
    disTeamsize10_[ts]=zip(*sorted([(k,stats.percentileofscore(drss10, np.mean(v)))                                   for k,v in DisTeamsize10[ts].items()]))
    disTeamsize10[ts]=zip(*sorted([(k,np.mean(v)) for k,v in DisTeamsize10[ts].items()]))


# In[30]:

disTeamsize_={}
disTeamsize={}
for ts in DisTeamsize.keys():
    disTeamsize_[ts]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                   for k,v in DisTeamsize[ts].items()]))
    disTeamsize[ts]=zip(*sorted([(k,np.mean(v)) for k,v in DisTeamsize[ts].items()]))


# In[37]:

fig = plt.figure(figsize=(5,5),facecolor='white')
cmap = cm.get_cmap('summer_r',10)
#
ax = fig.add_subplot(111)
for ts in range(2):
    x,y=disTeamsize_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label='m = '+str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.ylim(20,100)
#plt.yticks([])
#plt.xlabel('impact level',fontsize=24)
plt.yticks([20,40,60,80,100])
#plt.ylabel('disrution',fontsize=24)
plt.legend(loc=2,fontsize=12,ncol=2,frameon=False)

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.set_xticklabels('')
ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.3.inset.pdf')


# In[37]:

haha=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperSubject.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if 200 in line[1:]:
            haha.append(p)


# In[38]:

haha=set(haha)


# In[39]:

len(haha)


# In[42]:

# papers
J=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(Id) in haha:
            if journal not in J:
                J.add(journal)
            


# In[44]:

J


# In[ ]:




# In[38]:

fig = plt.figure(figsize=(10,10),facecolor='white')
cmap = cm.get_cmap('summer_r',10)
#
ax = fig.add_subplot(221)
for ts in range(1,11):
    x,y=disTeamsize[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label='m = '+str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('impact level',fontsize=24)
plt.ylabel('disrution',fontsize=24)
plt.legend(loc=2,fontsize=8)
#
ax = fig.add_subplot(222)
for ts in range(1,11):
    x,y=disTeamsize10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('impact level in 10 years',fontsize=24)
plt.ylabel('disrution in 10 years',fontsize=24)
#
ax = fig.add_subplot(223)
for ts in range(1,11):
    x,y=disTeamsize_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[70,70],'k--',alpha=0.3)
plt.xlabel('impact level',fontsize=24)
plt.ylabel('disrution percentile',fontsize=24)
#
ax = fig.add_subplot(224)
for ts in range(1,11):
    x,y=disTeamsize10_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('impact level in 10 years',fontsize=24)
plt.ylabel('disrution percentile in 10 years',fontsize=24)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/test.png')


# In[9]:

fig = plt.figure(figsize=(10,10),facecolor='white')
cmap = cm.get_cmap('summer_r',10)
#
ax = fig.add_subplot(222)
for ts in range(1,11):
    x,y=disTeamsize20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('impact level in 20 years',fontsize=24)
plt.ylabel('disrution in 20 years',fontsize=24)
#
ax = fig.add_subplot(224)
for ts in range(1,11):
    x,y=disTeamsize20_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('impact level in 20 years',fontsize=24)
plt.ylabel('disrution percentile in 20 years',fontsize=24)
#
plt.tight_layout()


# In[2]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[3]:

Impact=[v[-3] for v in W.values()]
np.percentile(Impact,10),np.percentile(Impact,99)


# In[4]:

K=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    xx,xx,m,c,d,xx=W[i]
    if d>0:
        K[m][1].append(c)
    else:
        K[m][0].append(c)


# In[7]:

def TopBottomRatio(K):
    data={}
    imps=[]
    for m in K:
        imps+=K[m][0]
        imps+=K[m][1]
    n1, n2=np.percentile(imps,10),np.percentile(imps,99)
    for m in range(1,11):
        dbottom1=len([i for i in K[m][0] if i<=n1])/float(len(K[m][0]))
        dbottom2=len([i for i in K[m][1] if i<=n1])/float(len(K[m][1]))
        dtop1=len([i for i in K[m][0] if i>=n2])/float(len(K[m][0]))
        dtop2=len([i for i in K[m][1] if i>=n2])/float(len(K[m][1]))
        data[m]=[dbottom1,dbottom2,dtop1,dtop2]
    return data


# In[8]:

data=TopBottomRatio(K)


# In[11]:

cmap = cm.get_cmap('rainbow',10)
fig = plt.figure(figsize=(12, 4),facecolor='white')
#
ax = fig.add_subplot(131)
for m in range(1,11):
    dbottom1,dbottom2,dtop1,dtop2=data[m]
    plt.plot([m,m],[dbottom1,dbottom2],color=cmap(m),linewidth=2)
    plt.plot([m-0.1,m+0.1],[dbottom2,dbottom2],color=cmap(m),linewidth=2)
plt.plot([0,11],[0.1,0.1],'k--')
plt.xlim(0,11)   
#
ax = fig.add_subplot(132)
for m in range(1,11):
    dbottom1,dbottom2,dtop1,dtop2=data[m]
    plt.plot([m,m],[dtop1,dtop2],color=cmap(m),linewidth=2)
    plt.plot([m-0.1,m+0.1],[dtop2,dtop2],color=cmap(m),linewidth=2)
plt.plot([0,11],[0.01,0.01],'k--')
plt.xlim(0,11) 
#
ax = fig.add_subplot(133)
k1,k2,k3,k4=np.array([data[m] for m in range(1,11)]).T
plt.plot(k2/(k1+0.0),'bo-')
plt.plot(k4/(k3+0.0),'g^-')
plt.xlim(0,11) 
#
plt.tight_layout()


# In[21]:

fig = plt.figure(figsize=(3,3),facecolor='white')
ax = fig.add_subplot(111)
k1,k2,k3,k4=np.array([data[m] for m in range(1,11)]).T
plt.plot(range(1,11),k2/(k1+0.0),marker='',color='brown',linewidth=2)
plt.plot(range(1,11),k4/(k3+0.0),marker='',color='ForestGreen',linewidth=2)
plt.xlim(1,10) 
plt.yticks([1,2,3])
plt.xticks([2,4,6,8,10])
#
plt.tight_layout()
[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.set_xticklabels('')
ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.3.4.pdf')


# In[ ]:




# In[ ]:




# # two ways to success

# In[60]:

drss=random.sample([v[-1] for v in W1.values()],100000)
stats.percentileofscore(drss, 0)


# In[78]:

def CD(ct):
    D={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearDisruptiveness.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            ndoi,n1,n2,n3=map(int,line.strip().split('\t'))
            if n1+n2+n3>0:
                dis=(n1-n2)/(n1+n2+n3+0.0)
                D[int(ndoi)]=dis
    C={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearImpact.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            Id,imp=map(int,line.strip().split('\t'))
            C[Id]=imp
    return C,D


# In[79]:

C5,D5=CD(5)
C10,D10=CD(10)
C20,D20=CD(20)
C30,D30=CD(30)
C40,D40=CD(40)
C50,D50=CD(50)


# In[312]:

def compare(C,D,yearI):
    DisTeamsize=defaultdict(lambda:[])
    ImpTeamsize=defaultdict(lambda:[])
    n=0
    for i in C:
        if i in W1 and i in D:
            year=W1[i][1]
            if year==yearI:
                teamsize=W1[i][2]
                impact=C[i]
                disruptive=D[i]
                if 1<=teamsize<=7 and impact>0:              
                    DisTeamsize[teamsize].append(disruptive)
                    ImpTeamsize[teamsize].append(impact)
    impTeamsizey=[np.mean(ImpTeamsize[ts]) for ts in range(1,8)]
    disTeamsizey=[np.mean(DisTeamsize[ts]) for ts in range(1,8)]
    disTeamsizey_=[stats.percentileofscore(drss,i) for i in disTeamsizey]
    return impTeamsizey,disTeamsizey,disTeamsizey_


# In[313]:

yearI=1970
sc5,sd5,sdp5=compare(C5,D5,yearI)
sc10,sd10,sdp10=compare(C10,D10,yearI)
sc20,sd20,sdp20=compare(C20,D20,yearI)
sc30,sd30,sdp30=compare(C30,D30,yearI)
sc40,sd40,sdp40=compare(C40,D40,yearI)
#c50,d50,dp50=compare(C50,D50,yearI)


# In[332]:

fig = plt.figure(figsize=(18,8),facecolor='white')
#
ax = fig.add_subplot(251)
par1 = ax.twinx()
ax.plot(range(1,8),sd5, label="Disruption",linewidth=2,color='#117733')
ax.plot([1,7],[0,0],'k--',alpha=0.5)
par1.plot(range(1,8),sc5, label="Impact",linewidth=2,color='#882255')
plt.title('5 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D5',fontsize=20)
par1.set_ylabel('C5',fontsize=20)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)
#
ax = fig.add_subplot(256)
par1 = ax.twinx()
ax.plot(range(1,8),sdp5, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,8),sc5, label="Impact",linewidth=2,color='#882255')
ax.plot([1,7],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP5',fontsize=20)
par1.set_ylabel('C5',fontsize=20)
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)
#
ax = fig.add_subplot(252)
par1 = ax.twinx()
ax.plot(range(1,8),sd10, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,8),sc10, label="Impact",linewidth=2,color='#882255')
ax.plot([1,7],[0,0],'k--',alpha=0.5)
plt.title('10 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D10',fontsize=20)
par1.set_ylabel('C10',fontsize=20)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)
#
ax = fig.add_subplot(257)
par1 = ax.twinx()
ax.plot(range(1,8),sdp10, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,8),sc10, label="Impact",linewidth=2,color='#882255')
ax.plot([1,7],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP10',fontsize=20)
par1.set_ylabel('C10',fontsize=20)
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)
#
ax = fig.add_subplot(253)
par1 = ax.twinx()
ax.plot(range(1,8),sd20, label="Disruption",linewidth=2,color='#117733')
ax.plot([1,7],[0,0],'k--',alpha=0.5)
par1.plot(range(1,8),sc20, label="Impact",linewidth=2,color='#882255')
plt.title('20 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D20',fontsize=20)
par1.set_ylabel('C20',fontsize=20)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)

#
ax = fig.add_subplot(258)
par1 = ax.twinx()
ax.plot(range(1,8),sdp20, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,8),sc20, label="Impact",linewidth=2,color='#882255')
ax.plot([1,7],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP20',fontsize=20)
par1.set_ylabel('C20',fontsize=20)
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)
#
ax = fig.add_subplot(254)
par1 = ax.twinx()
ax.plot(range(1,8),sd30, label="Disruption",linewidth=2,color='#117733')
ax.plot([1,7],[0,0],'k--',alpha=0.5)
par1.plot(range(1,8),sc30, label="Impact",linewidth=2,color='#882255')
plt.title('30 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D30',fontsize=20)
par1.set_ylabel('C30',fontsize=20)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)

#
ax = fig.add_subplot(259)
par1 = ax.twinx()
ax.plot(range(1,8),sdp30, label="Disruption",linewidth=2,color='#117733')
ax.plot([1,7],[71,71],'k--',alpha=0.5)
par1.plot(range(1,8),sc30, label="Impact",linewidth=2,color='#882255')
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP30',fontsize=20)
par1.set_ylabel('C30',fontsize=20)
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)

#
#
ax = fig.add_subplot(255)
par1 = ax.twinx()
ax.plot(range(1,8),sd40, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,8),sc40, label="Impact",linewidth=2,color='#882255')
ax.plot([1,7],[0,0],'k--',alpha=0.5)
plt.title('40 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D40',fontsize=20)
par1.set_ylabel('C40',fontsize=20)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)
#
ax = fig.add_subplot(2,5,10)
par1 = ax.twinx()
ax.plot(range(1,8),sdp40, label="Disruption",linewidth=2,color='#117733')
ax.plot([1,7],[71,71],'k--',alpha=0.5)
par1.plot(range(1,8),sc40, label="Impact",linewidth=2,color='#882255')
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP40',fontsize=20)
par1.set_ylabel('C40',fontsize=20)
ax.set_xticklabels(range(1,8),fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([5,10,15,20,25,30,35])
par1.set_yticklabels([5,10,15,20,25,30,35],rotation=45,fontsize=16)

#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S4.pdf')


# In[270]:

def compareAll(C,D,yearI):
    DisTeamsize=defaultdict(lambda:[])
    ImpTeamsize=defaultdict(lambda:[])
    n=0
    for i in C:
        if i in W1 and i in D:
            year=W1[i][1]
            if year<=yearI:
                teamsize=W1[i][2]
                impact=C[i]
                disruptive=D[i]
                if 1<=teamsize<=10 and impact>0:              
                    DisTeamsize[teamsize].append(disruptive)
                    ImpTeamsize[teamsize].append(impact)
    impTeamsizey=[np.mean(ImpTeamsize[ts]) for ts in range(1,11)]
    disTeamsizey=[np.mean(DisTeamsize[ts]) for ts in range(1,11)]
    disTeamsizey_=[stats.percentileofscore(drss,i) for i in disTeamsizey]
    return impTeamsizey,disTeamsizey,disTeamsizey_


# In[271]:

c5,d5,dp5=compareAll(C5,D5,2009)
c10,d10,dp10=compareAll(C10,D10,2004)
c20,d20,dp20=compareAll(C20,D20,1994)
c30,d30,dp30=compareAll(C30,D30,1984)
c40,d40,dp40=compareAll(C40,D40,1974)


# In[333]:

fig = plt.figure(figsize=(18,8),facecolor='white')
#
ax = fig.add_subplot(251)
par1 = ax.twinx()
ax.plot(range(1,11),d5, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c5, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[0,0],'k--',alpha=0.5)
plt.title('5 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D5',fontsize=20)
par1.set_ylabel('C5',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(256)
par1 = ax.twinx()
ax.plot(range(1,11),dp5, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c5, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP5',fontsize=20)
par1.set_ylabel('C5',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(252)
par1 = ax.twinx()
ax.plot(range(1,11),d10, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c10, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[0,0],'k--',alpha=0.5)
plt.title('10 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D10',fontsize=20)
par1.set_ylabel('C10',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(257)
par1 = ax.twinx()
ax.plot(range(1,11),dp10, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c10, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP10',fontsize=20)
par1.set_ylabel('C10',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(253)
par1 = ax.twinx()
ax.plot(range(1,11),d20, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c20, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[0,0],'k--',alpha=0.5)
plt.title('20 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D20',fontsize=20)
par1.set_ylabel('C20',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(258)
par1 = ax.twinx()
ax.plot(range(1,11),dp20, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c20, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP20',fontsize=20)
par1.set_ylabel('C20',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(254)
par1 = ax.twinx()
ax.plot(range(1,11),d30, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c30, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[0,0],'k--',alpha=0.5)
plt.title('30 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D30',fontsize=20)
par1.set_ylabel('C30',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)

#
ax = fig.add_subplot(259)
par1 = ax.twinx()
ax.plot(range(1,11),dp30, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c30, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP30',fontsize=20)
par1.set_ylabel('C30',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
#
ax = fig.add_subplot(255)
par1 = ax.twinx()
ax.plot(range(1,11),d40, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c40, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[0,0],'k--',alpha=0.5)
plt.title('40 years',fontsize=24)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('D40',fontsize=20)
par1.set_ylabel('C40',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([-0.01,-0.005,0,0.005,0.01])
ax.set_yticklabels([-0.01,-0.005,0,0.005,0.01],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
ax = fig.add_subplot(2,5,10)
par1 = ax.twinx()
ax.plot(range(1,11),dp40, label="Disruption",linewidth=2,color='#117733')
par1.plot(range(1,11),c40, label="Impact",linewidth=2,color='#882255')
ax.plot([1,10],[71,71],'k--',alpha=0.5)
ax.set_xlabel('team size',fontsize=20)
ax.set_ylabel('DP40',fontsize=20)
par1.set_ylabel('C40',fontsize=20)
ax.set_xticks([2,4,6,8,10])
ax.set_xticklabels([2,4,6,8,10],fontsize=16)
ax.set_yticks([0,20,40,60,80,100])
ax.set_yticklabels([0,20,40,60,80,100],rotation=45,fontsize=16)
par1.set_yticks([10,20,30,40,50])
par1.set_yticklabels([10,20,30,40,50],rotation=45,fontsize=16)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S3.pdf')


# In[ ]:




# In[ ]:

crss=random.sample([v[-2] for v in W1.values()],100000)


# In[337]:

def compare2(C,D,yearI):
    DisTeamsize=defaultdict(lambda:defaultdict(lambda:[]))
    n=0
    for i in C:
        if i in W1 and i in D:
            year=W1[i][1]
            if year==yearI:
                teamsize=W1[i][2]
                impact=C[i]
                disruptive=D[i]
                if 1<=teamsize<=7 and impact>0: 
                    '''
                    if impact<k50:
                        ilevel=1
                    if k50<=impact<k75:
                        ilevel=2
                    if k75<=impact<k90:
                        ilevel=3           
                    if k90<=impact<k95:
                        ilevel=4           
                    if k95<=impact:
                        ilevel=5  
                    '''
                    if impact==1:
                        ilevel=1
                    if 2<=impact<=3:
                        ilevel=2
                    if 4<=impact<=10:
                        ilevel=3           
                    if 11<=impact<=20:
                        ilevel=4           
                    if 21<=impact<=50:
                        ilevel=5
                    if 50<impact:
                        ilevel=6
                    DisTeamsize[teamsize][ilevel].append(disruptive)                    
    disTeamsize_={}
    disTeamsize={}
    for ts in range(1,8):
        disTeamsize[ts]=zip(*sorted([(k,np.mean(v)) for k,v in DisTeamsize[ts].items()]))
        disTeamsize_[ts]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                       for k,v in DisTeamsize[ts].items()]))
        
    return disTeamsize,disTeamsize_


# In[339]:

yearI=1970
scd5,scdp5=compare2(C5,D5,yearI)
scd10,scdp10=compare2(C10,D10,yearI)
scd20,scdp20=compare2(C20,D20,yearI)
scd30,scdp30=compare2(C30,D30,yearI)
scd40,scdp40=compare2(C40,D40,yearI)


# In[343]:

fig = plt.figure(figsize=(15,8),facecolor='white')
cmap = cm.get_cmap('bwr_r',6)
#
ax = fig.add_subplot(251)
for ts in range(1,6):
    x,y=scd5[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label='m='+str(ts))
ax.set_xlim(1,5)
plt.title('5 years',fontsize=24)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C5',fontsize=20)
plt.ylabel('D5',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
plt.legend(loc=1,fontsize=8,frameon=False,ncol=2)
#
ax = fig.add_subplot(256)
for ts in range(1,6):
    x,y=scdp5[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C5',fontsize=20)
plt.ylabel('DP5',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
ax = fig.add_subplot(252)
for ts in range(1,6):
    x,y=scd10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('10 years',fontsize=24)
plt.xlabel('C10',fontsize=20)
plt.ylabel('D10',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(257)
for ts in range(1,6):
    x,y=scdp10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C10',fontsize=20)
plt.ylabel('DP10',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
#
ax = fig.add_subplot(253)
for ts in range(1,6):
    x,y=scd20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('20 years',fontsize=24)
plt.xlabel('C20',fontsize=20)
plt.ylabel('D20',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(258)
for ts in range(1,6):
    x,y=scdp20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C20',fontsize=20)
plt.ylabel('DP20',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
ax = fig.add_subplot(254)
for ts in range(1,6):
    x,y=scd30[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('30 years',fontsize=24)
plt.xlabel('C30',fontsize=20)
plt.ylabel('D30',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(259)
for ts in range(1,6):
    x,y=scdp30[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C30',fontsize=20)
plt.ylabel('DP30',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
ax = fig.add_subplot(255)
for ts in range(1,6):
    x,y=scd40[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('40 years',fontsize=24)
plt.xlabel('C40',fontsize=20)
plt.ylabel('D40',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(2,5,10)
for ts in range(1,6):
    x,y=scdp40[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.5)
plt.xlabel('C40',fontsize=20)
plt.ylabel('DP40',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S6.pdf')


# In[ ]:




# In[302]:

def compare2All(C,D,yearI):
    DisTeamsize=defaultdict(lambda:defaultdict(lambda:[]))
    n=0
    for i in C:
        if i in W1 and i in D:
            year=W1[i][1]
            if year<=yearI:
                teamsize=W1[i][2]
                impact=C[i]
                disruptive=D[i]
                if 1<=teamsize<=10 and impact>0:   
                    '''
                    if impact<k50:
                        ilevel=1
                    if k50<=impact<k75:
                        ilevel=2
                    if k75<=impact<k90:
                        ilevel=3           
                    if k90<=impact<k95:
                        ilevel=4           
                    if k95<=impact:
                        ilevel=5
                    '''
                    if impact==1:
                        ilevel=1
                    if 2<=impact<=3:
                        ilevel=2
                    if 4<=impact<=10:
                        ilevel=3           
                    if 11<=impact<=20:
                        ilevel=4           
                    if 21<=impact<=50:
                        ilevel=5
                    if 50<impact:
                        ilevel=6
                    DisTeamsize[teamsize][ilevel].append(disruptive)                    
    disTeamsize_={}
    disTeamsize={}
    for ts in range(1,11):
        disTeamsize[ts]=zip(*sorted([(k,np.mean(v)) for k,v in DisTeamsize[ts].items()]))
        disTeamsize_[ts]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                       for k,v in DisTeamsize[ts].items()]))
        
    return disTeamsize,disTeamsize_


# In[342]:

cd5,cdp5=compare2All(C5,D5,2009)
cd10,cdp10=compare2All(C10,D10,2004)
cd20,cdp20=compare2All(C20,D20,1994)
cd30,cdp30=compare2All(C30,D30,1984)
cd40,cdp40=compare2All(C40,D40,1974)


# In[344]:

fig = plt.figure(figsize=(15,8),facecolor='white')
cmap = cm.get_cmap('bwr_r',8)
#
ax = fig.add_subplot(251)
for ts in range(1,8):
    x,y=cd5[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label='m='+str(ts))
ax.set_xlim(1,5)
plt.title('5 years',fontsize=24)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C5',fontsize=20)
plt.ylabel('D5',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
plt.legend(loc=1,fontsize=8,frameon=False,ncol=2)
#
ax = fig.add_subplot(256)
for ts in range(1,8):
    x,y=cdp5[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C5',fontsize=20)
plt.ylabel('DP5',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
ax = fig.add_subplot(252)
for ts in range(1,8):
    x,y=cd10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('10 years',fontsize=24)
plt.xlabel('C10',fontsize=20)
plt.ylabel('D10',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(257)
for ts in range(1,8):
    x,y=cdp10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C10',fontsize=20)
plt.ylabel('DP10',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
#
ax = fig.add_subplot(253)
for ts in range(1,8):
    x,y=cd20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('20 years',fontsize=24)
plt.xlabel('C20',fontsize=20)
plt.ylabel('D20',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(258)
for ts in range(1,8):
    x,y=cdp20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C20',fontsize=20)
plt.ylabel('DP20',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
ax = fig.add_subplot(254)
for ts in range(1,8):
    x,y=cd30[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('30 years',fontsize=24)
plt.xlabel('C30',fontsize=20)
plt.ylabel('D30',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(259)
for ts in range(1,8):
    x,y=cdp30[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C30',fontsize=20)
plt.ylabel('DP30',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
ax = fig.add_subplot(255)
for ts in range(1,8):
    x,y=cd40[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.title('40 years',fontsize=24)
plt.xlabel('C40',fontsize=20)
plt.ylabel('D40',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05],fontsize=16,rotation=45)
#
ax = fig.add_subplot(2,5,10)
for ts in range(1,8):
    x,y=cdp40[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k--',alpha=0.5)
plt.xlabel('C40',fontsize=20)
plt.ylabel('DP40',fontsize=20)
plt.xticks(range(1,7),['1','2-3','4-10','11-20','21-50','>50'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16,rotation=45)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S5.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[231]:

C,D=C5,D5
yearI=1970

def MeanCompare(C,D,yearI):
    c=defaultdict(lambda:[])
    d=defaultdict(lambda:[])
    for i in C:
        if i in D and i in W1:
            year=W1[i][1]
            if year==yearI:
                teamsize=W1[i][2]
                if 1<=teamsize<=7:
                    c[teamsize].append(C[i])
                    d[teamsize].append(D[i])
    cs=[np.mean(c[ts]) for ts in range(1,8)]
    ds=[np.mean(d[ts]) for ts in range(1,8)]
    return cs,ds


# In[232]:

yearI=1970
cs5,ds5=MeanCompare(C5,D5,yearI)


# In[236]:

cs10,ds10=MeanCompare(C10,D10,yearI)
cs20,ds20=MeanCompare(C20,D20,yearI)
cs30,ds30=MeanCompare(C30,D30,yearI)
cs40,ds40=MeanCompare(C40,D40,yearI)


# In[254]:

fig = plt.figure(figsize=(10,5),facecolor='white')
#
ax = fig.add_subplot(121)
cmap = cm.get_cmap('bwr_r',8)
n=0
for j in zip(*[cs5,cs10,cs20,cs30,cs40]):
    n+=1
    plt.plot(range(1,6),j,color=cmap(n),label='m='+str(n))
    plt.legend(loc=2,fontsize=10,frameon=False)
    plt.xlabel('Years',fontsize=20)
    plt.ylabel('<Impact>',fontsize=20)
    plt.xticks(range(1,6),['5','10','20','30','40'],rotation=45,fontsize=16)
    plt.yticks(fontsize=16,rotation=45)
#
ax = fig.add_subplot(122)
n=0
for j in zip(*[ds5,ds10,ds20,ds30,ds40]):
    n+=1
    plt.plot(range(1,6),j,color=cmap(n),label='m='+str(n))
    plt.legend(loc=2,fontsize=10,frameon=False)
    plt.xlabel('Years',fontsize=20)
    plt.ylabel('<Disruption>',fontsize=20)
    plt.xticks(range(1,6),['5','10','20','30','40'],rotation=45,fontsize=16)
    plt.yticks(fontsize=16,rotation=45)
plt.tight_layout()


# In[ ]:




# In[61]:

ct=10
def Cohort(ct):
    D={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearDisruptiveness.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            ndoi,n1,n2,n3=map(int,line.strip().split('\t'))
            #if n1+n2+n3>0 and ndoi in W1 and W1[ndoi][1]>=1954:
            if n1+n2+n3>0 and ndoi in W1 and W1[ndoi][1]==1960:
                dis=(n1-n2)/(n1+n2+n3+0.0)
                D[int(ndoi)]=dis
    C={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearImpact.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            Id,imp=map(int,line.strip().split('\t'))
            #if Id in W1 and W1[Id][1]>=1954:
            if Id in W1 and W1[Id][1]==1960:
                C[Id]=imp
    k50,k75,k90,k95=[np.percentile(C.values(),k) for k in [50,75,90,95]]
    DisTeamsize=defaultdict(lambda:defaultdict(lambda:[]))
    n=0
    for i in W1:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        if i in C and i in D:
            teamsize=W1[i][2]
            impact=C[i]
            disruptive=D[i]
            if 1<=teamsize<=10 and impact>0:
                '''
                if impact==1:
                    ilevel=1
                if 2<=impact<=3:
                    ilevel=2
                if 4<=impact<=10:
                    ilevel=3           
                if 11<=impact<=20:
                    ilevel=4           
                if 21<=impact<=50:
                    ilevel=5
                if impact>50:
                    ilevel=6
                '''
                if impact<k50:
                    ilevel=1
                if k50<=impact<k75:
                    ilevel=2
                if k75<=impact<k90:
                    ilevel=3           
                if k90<=impact<k95:
                    ilevel=4           
                if k95<=impact:
                    ilevel=5               
                DisTeamsize[teamsize][ilevel].append(disruptive)
    disTeamsize_={}
    disTeamsize={}
    for ts in range(1,11):
        disTeamsize_[ts]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                       for k,v in DisTeamsize[ts].items()]))
        disTeamsize[ts]=zip(*sorted([(k,np.mean(v)) for k,v in DisTeamsize[ts].items()]))
    return disTeamsize,disTeamsize_


# In[62]:

d5,d5_=Cohort(5)
d10,d10_=Cohort(10)
d20,d20_=Cohort(20)
d30,d30_=Cohort(30)
d40,d40_=Cohort(40)
d50,d50_=Cohort(50)


# In[17]:

fig = plt.figure(figsize=(18,8),facecolor='white')
cmap = cm.get_cmap('summer_r',10)
#
ax = fig.add_subplot(261)
for ts in range(1,11):
    x,y=d5[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C5',fontsize=20)
plt.ylabel('D5',fontsize=20)
#
ax = fig.add_subplot(267)
for ts in range(1,11):
    x,y=d5_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C5',fontsize=20)
plt.ylabel('DP5',fontsize=20)
#
ax = fig.add_subplot(262)
for ts in range(1,11):
    x,y=d10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C10',fontsize=20)
plt.ylabel('D10',fontsize=20)
#
ax = fig.add_subplot(268)
for ts in range(1,11):
    x,y=d10_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C10',fontsize=20)
plt.ylabel('DP10',fontsize=20)
#
ax = fig.add_subplot(263)
for ts in range(1,11):
    x,y=d20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C20',fontsize=20)
plt.ylabel('D20',fontsize=20)
#
ax = fig.add_subplot(269)
for ts in range(1,11):
    x,y=d20_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C20',fontsize=20)
plt.ylabel('DP20',fontsize=20)
#
ax = fig.add_subplot(264)
for ts in range(1,11):
    x,y=d30[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C30',fontsize=20)
plt.ylabel('D30',fontsize=20)
#
ax = fig.add_subplot(2,6,10)
for ts in range(1,11):
    x,y=d30_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C30',fontsize=20)
plt.ylabel('DP30',fontsize=20)
#
ax = fig.add_subplot(265)
for ts in range(1,11):
    x,y=d40[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C40',fontsize=20)
plt.ylabel('D40',fontsize=20)
#
ax = fig.add_subplot(2,6,11)
for ts in range(1,11):
    x,y=d40_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C40',fontsize=20)
plt.ylabel('DP40',fontsize=20)
#
ax = fig.add_subplot(266)
for ts in range(1,11):
    x,y=d50[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[0,0],'k--',alpha=0.3)
plt.xlabel('C50',fontsize=20)
plt.ylabel('D50',fontsize=20)
#
ax = fig.add_subplot(2,6,12)
for ts in range(1,11):
    x,y=d50_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,6)
plt.plot([1,10],[71,71],'k--',alpha=0.3)
plt.xlabel('C50',fontsize=20)
plt.ylabel('DP50',fontsize=20)
#
plt.tight_layout()


# In[76]:

fig = plt.figure(figsize=(18,8),facecolor='white')
cmap = cm.get_cmap('summer_r',10)
#
ax = fig.add_subplot(261)
for ts in range(1,6):
    x,y=d5[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label='m='+str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k-',alpha=0.5)
plt.xlabel('C5',fontsize=20)
plt.ylabel('D5',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05,0.1],fontsize=16)
plt.legend(loc=1,fontsize=14,frameon=False)
plt.title('1965',fontsize=20)
#
ax = fig.add_subplot(267)
for ts in range(1,6):
    x,y=d5_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k-',alpha=0.5)
plt.xlabel('C5',fontsize=20)
plt.ylabel('DP5',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16)
#
ax = fig.add_subplot(262)
for ts in range(1,6):
    x,y=d10[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k-',alpha=0.5)
plt.xlabel('C10',fontsize=20)
plt.ylabel('D10',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05,0.1],fontsize=16)
plt.title('1970',fontsize=20)
#
ax = fig.add_subplot(268)
for ts in range(1,6):
    x,y=d10_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k-',alpha=0.5)
plt.xlabel('C10',fontsize=20)
plt.ylabel('DP10',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16)
#
ax = fig.add_subplot(263)
for ts in range(1,6):
    x,y=d20[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k-',alpha=0.5)
plt.xlabel('C20',fontsize=20)
plt.ylabel('D20',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05,0.1],fontsize=16)
plt.title('1980',fontsize=20)
#
ax = fig.add_subplot(269)
for ts in range(1,6):
    x,y=d20_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k-',alpha=0.5)
plt.xlabel('C20',fontsize=20)
plt.ylabel('DP20',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16)
#
#
ax = fig.add_subplot(264)
for ts in range(1,6):
    x,y=d30[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k-',alpha=0.5)
plt.xlabel('C30',fontsize=20)
plt.ylabel('D30',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05,0.1],fontsize=16)
plt.title('1990',fontsize=20)
#
ax = fig.add_subplot(2,6,10)
for ts in range(1,6):
    x,y=d30_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k-',alpha=0.5)
plt.xlabel('C30',fontsize=20)
plt.ylabel('DP30',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16)
#
ax = fig.add_subplot(265)
for ts in range(1,6):
    x,y=d40[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k-',alpha=0.5)
plt.xlabel('C40',fontsize=20)
plt.ylabel('D40',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05,0.1],fontsize=16)
plt.title('2000',fontsize=20)
#
ax = fig.add_subplot(2,6,11)
for ts in range(1,6):
    x,y=d40_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k-',alpha=0.5)
plt.xlabel('C40',fontsize=20)
plt.ylabel('DP40',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16)
#
ax = fig.add_subplot(266)
for ts in range(1,6):
    x,y=d50[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[0,0],'k-',alpha=0.5)
plt.xlabel('C50',fontsize=20)
plt.ylabel('D50',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([-0.05,0,0.05,0.1],fontsize=16)
plt.title('2010',fontsize=20)
#
ax = fig.add_subplot(2,6,12)
for ts in range(1,6):
    x,y=d50_[ts]
    plt.plot(x,y,color=cmap(ts),linewidth=2,label=str(ts))
ax.set_xlim(1,5)
plt.plot([1,10],[71,71],'k-',alpha=0.5)
plt.xlabel('C50',fontsize=20)
plt.ylabel('DP50',fontsize=20)
plt.xticks(range(1,6),['0-50','50-75','75-90','90-95','95-100'],rotation=45,fontsize=16)
plt.yticks([0,20,40,60,80,100],fontsize=16)
#
plt.tight_layout()


# In[ ]:




# In[ ]:

def DisImp(ct):


    return disTeamsize,disTeamsize_


# In[9]:

np.percentile(S1.values(),99)


# In[11]:

np.percentile([W1[i][5] for i in W1],99)


# In[ ]:




# In[12]:

beauties=set([])
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
    if i in S1:
        if year>=1955 and S1[i]>63.5 and 1<=teamsize<=3 and impact>214:
            beauties.add(i)


# In[13]:

len(beauties)


# In[ ]:




# In[ ]:




# In[14]:

Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        if int(year)>=1954:
            Y[int(ndoi)]=int(year)


# In[15]:

#
B=defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:0)))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in Y and p in W1:
            year=Y[p]
            ts=W1[p][2]
            for j in line[1:]:
                if j in beauties:
                    B[j][year][ts]+=1


# In[75]:

sum([sum([sum(v.values()) for k,v in B[j].items()]) for j in B])


# In[ ]:




# In[17]:

B.keys()[0]


# In[19]:


data=B[16580609]


# In[21]:

data[1993]


# In[29]:

DD={}
n=0
for j in B:
    year0=Y[j]
    n+=1
    if n%100==0:
        flushPrint(n/100)
    data=B[j]
    dd={}
    for year in data:
        s=0
        b=0
        for i in data[year]:
            if i<=3:
                s+=data[year][i]
            else:
                b+=data[year][i]
        dd[year-year0]=b/float((s+b))
    DD[j]=dd


# In[42]:

CC=defaultdict(lambda:[])
for p in DD:
    for year, ratio in DD[p].items():
        CC[year].append(ratio)


# In[59]:

x,y=np.array([(k,np.mean(v)) for k,v in CC.items()]).T


# In[2]:

fig = plt.figure(figsize=(10, 5),facecolor='white')
#
ax = fig.add_subplot(122)
plt.plot(x,y,marker='o',color='Royalblue')
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Year since publication',fontsize=20)
plt.ylabel('Large team citation percentage',fontsize=20)
#
ax = fig.add_subplot(121)
cmap = cm.get_cmap('rainbow_r',4)
n=0
for i in [16580609, 3325955, 2088966]:
    x1,y1=np.array(DD[i].items()).T
    plt.plot(x1,y1,color=cmap(n))
    n+=1
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Year since publication',fontsize=20)
plt.ylabel('Large team citation percentage',fontsize=20)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/rippling.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[34]:

for j in DD.keys()[:100]:
    x,y=np.array(sorted(DD[j].items())).T
    plt.plot(x,y,'b-',alpha=0.1)


# In[ ]:



