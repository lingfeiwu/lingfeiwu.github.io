
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
from openpyxl import load_workbook
from scipy import stats
import matplotlib.patches as patches

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# # nobel prize papers

# In[2]:

WOS={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        doi,ndoi,year=line.strip().split('\t')
        WOS[doi]=int(ndoi)


# In[6]:

# papers
S=defaultdict(lambda:defaultdict(lambda:[]))
T=defaultdict(lambda:defaultdict(lambda:[]))
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]
            S[int(year)][int(journal)].append(int(Id))
            T[int(journal)][int(year)].append(int(Id))


# In[7]:

# papers
Disruptive=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            Disruptive.append(float(disruptive))


# In[9]:

drss=random.sample(Disruptive,10000)
stats.percentileofscore(drss, 0)


# In[ ]:




# In[14]:

wb1 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physiology or Medicine.xlsx', read_only=True)
wb2 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physics.xlsx', read_only=True)
wb3 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Chemistry.xlsx', read_only=True)

def GetIDs(wb):
    sheet = wb.get_sheet_by_name(wb.get_sheet_names()[0])
    data=[]
    sheet = wb.get_sheet_by_name('Sheet1')
    for row in sheet.iter_rows():
        data_row = []
        for cell in row:
            data_row += [cell.value]
        data += [data_row]
    d=[]
    j=set([])
    for i in data[1:]:
        a=str(i[-1])
        if a in WOS and WOS[a] in W:
            d.append(WOS[a])
    return list(set(d))


# In[15]:

d1=GetIDs(wb1)
d2=GetIDs(wb2)
d3=GetIDs(wb3)
d=d1+d2+d3


# In[16]:

len(d1),len(d2),len(d3),len(d)


# In[17]:

min(set([W[i][0] for i in d])),max(set([W[i][0] for i in d]))


# In[18]:

#control groups
d_={}
for i in d:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    j=random.choice(S[year][journal])
    d_[i]=j


# In[19]:

disD=defaultdict(lambda:[])
disD_=defaultdict(lambda:[])
for i in d:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    if 1<=teamsize<=10:
        disD[teamsize].append(disruptive)
for i in d_.values():
    year,subject,teamsize,impact,disruptive,journal=W[i]
    if 1<=teamsize<=10:
        disD_[teamsize].append(disruptive)
x,y=np.array([(k,np.mean(v)) for k,v in disD.items()]).T
y1=[stats.percentileofscore(drss, i) for i in y]
x_,y_=np.array([(k,np.mean(v)) for k,v in disD_.items()]).T
y1_=[stats.percentileofscore(drss, i) for i in y_]


# In[20]:

plt.plot(x,y,'bo-')
plt.plot(x_,y_,'ro-')


# # grants 

# In[31]:

FF=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/grant1900_2015.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if len(line)==3:
            ndoi,fname,fnumber=line
            ndoi=int(ndoi)
            FF.add(ndoi)


# In[67]:

J={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','r') as f:
    for line in f:
        line=line.strip().split('\t')
        J[int(line[0])]=line[1].lower()


# In[34]:

#1.year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[32]:

len(FF)


# In[38]:

cy=Counter(Y.values())


# In[35]:

cc=Counter([Y[i] for i in FF])


# In[44]:

x,y=np.array(sorted([(i,cc[i]/float(cy[i])) for i in cc])).T
plt.plot(x,y,'bo-')
plt.xlim(2004,2014)


# In[37]:

startYear=2008
endYear=2010
# new articles
F={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/grant1900_2015.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if len(line)==3:
            ndoi,fname,fnumber=line
            ndoi=int(ndoi)
            if ndoi in W and startYear<=W[ndoi][0]<=endYear:
            #if ndoi in W1:
                if ndoi not in F:
                    F[ndoi]=[]
                F[ndoi].append(fname+' ' +fnumber)


# In[45]:

len(F)


# In[46]:

US=set([])
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if Id in W and startYear<=W[Id][0]<=endYear:
            US.add(Id)

CN=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'nsfc' in j:
            CN.add(i)
            break
        if 'national science foundation' in j and 'china' in j:
            CN.add(i)
            break

EU=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'european research council' in j:
            EU.add(i)
            break
        if ' erc' in j:
            EU.add(i)
            break   
        if ' fpa' in j:
            EU.add(i)
            break 
        if 'european commission' in j:
            EU.add(i)
            break  
        if 'european community' in j:
            EU.add(i)
            break   

JP=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'jsps' in j:
            JP.add(i)
            break
        if 'japan society for the promotion of science' in j:
            JP.add(i)
            break

DE=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'dfg' in j:
            DE.add(i)
            break
        if 'german research foundation' in j:
            DE.add(i)
            break


# In[84]:

f=set().union(*[US,CN,EU,JP,DE])


# In[85]:

len(US),len(CN),len(EU),len(JP),len(DE),len(f)


# In[86]:

#2008-2014: (198103, 80448, 81296, 58275, 75881, 477702)


# In[87]:

#control groups
f_={}
for i in f:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    #j=random.choice(S[year][journal])
    js=S[year][journal]
    f_[i]=js


# In[88]:

disF=defaultdict(lambda:[])
disF_=defaultdict(lambda:[])
for i in f:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    if 1<=teamsize<=10:
        disF[teamsize].append(disruptive)
for i in f_.values():
    for j in i:
        year,subject,teamsize,impact,disruptive,journal=W[j]
        if 1<=teamsize<=10:
            disF_[teamsize].append(disruptive)
x,y=np.array([(k,np.mean(v)) for k,v in disF.items()]).T
y1=[stats.percentileofscore(drss, i) for i in y]
x_,y_=np.array([(k,np.mean(v)) for k,v in disF_.items()]).T
y1_=[stats.percentileofscore(drss, i) for i in y_]


# In[89]:

plt.plot(x,y,'bo-')
plt.plot(x_,y_,'ro-')


# In[52]:

plt.plot(x,y,'bo-')
plt.plot(x_,y_,'ro-')


# In[ ]:




# In[53]:

JN=defaultdict(int)
for i in f:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    if year==2010:
        JN[journal]+=1
        
        


# In[56]:

len(JN),len(S[2010])


# In[82]:

JK=[]
for j in JN:
    a=JN[j]
    b=len(S[2010][j])+0.0
    if b>=1000:
        JK.append([a/b,int(b),j,J[j]])


# In[ ]:




# In[83]:

sorted(JK,reverse=True)


# In[ ]:




# In[94]:

J=set([])
for i in f:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    J.add(journal)
len(J)


# In[101]:

J1=set([])
test=defaultdict(lambda:[])
for i in W:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    if 1<=teamsize<=10 and 2004<=year<=2014:
        test[teamsize].append(disruptive)
        J1.add(journal)


# In[102]:

c=J1-J


# In[106]:

d=J-J1


# In[107]:

len(J1),len(J),len(c),len(d)


# In[111]:

JC=defaultdict(lambda:0)
JN=defaultdict(lambda:0)
for i in W:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    JC[journal]+=impact
    JN[journal]+=1


# In[113]:

np.mean([JC[j]/float(JN[j]) for j in J]),np.mean([JC[j]/float(JN[j]) for j in c])


# In[114]:

np.mean([JC[j]/float(JN[j]) for j in J1])


# In[115]:

test=defaultdict(lambda:[])
for i in W:
    year,subject,teamsize,impact,disruptive,journal=W[i]
    if 1<=teamsize<=10 and 2004<=year<=2014 and journal in J:
        test[teamsize].append(disruptive)


# In[116]:

a,b=np.array([(k,np.mean(v)) for k,v in test.items()]).T
plt.plot(a,b,'go-')


# In[ ]:




# In[105]:

a,b=np.array([(k,np.mean(v)) for k,v in test.items()]).T
plt.plot(a,b,'go-')


# In[100]:

a,b=np.array([(k,np.mean(v)) for k,v in test.items()]).T
plt.plot(a,b,'go-')


# In[121]:




# In[122]:

plt.plot(x,y,'bo-')
plt.plot(x_,y_,'ro-')


# In[ ]:



