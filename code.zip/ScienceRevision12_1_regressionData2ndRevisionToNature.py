
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE
import operator

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
def flushPrints(d):
    sys.stdout.write('\r')
    sys.stdout.write(d)
    sys.stdout.flush()


# In[4]:

# papers
a=0
b=0
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            a+=1
            if 1<=int(teamsize)<=10:
                b+=1


# In[5]:

a,b


# In[6]:

23573988/24173947.0


# In[ ]:




# In[ ]:




# ### 1. read data

# In[2]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(teamsize),int(impact),int(subject),float(disruptive),int(journal),int(year)]


# In[ ]:




# In[2]:


            
# all paper disruption 
n=0
R={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/teamPerformance1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,n1,n2,n3=map(int,line.strip().split('\t'))
        if n1+n2>0:
            R[Id]=n1/(n1+n2+0.0)
        


# In[16]:

# all paper disruption 
n=0
D={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/teamPerformance1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,n1,n2,n3=map(int,line.strip().split('\t'))
        if n1+n2>0:
            D[Id]=(n1-n2+0.0)/(n1+n2+n3+0.0)


# In[395]:

N={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/KLnobelty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#175
        Id,novelty=line.strip().split('\t')
        N[int(Id)]=float(novelty)


# In[396]:

len(R),len(D),len(W),len(N)


# In[3]:

len(D)


# ### export figure data

# In[12]:

nbins=30000
ds=D.values()
N, bins, patches = plt.hist(ds, bins=nbins,edgecolor='white', linewidth=0)


# In[20]:

from pandas import DataFrame
from pandas import ExcelWriter

def save_xls(sheetnames,list_dfs, xls_path):
    writer = ExcelWriter(xls_path)
    for n, df in zip(sheetnames,list_dfs):
        df.to_excel(writer,n)
    writer.save()


# In[30]:

b_sample_means_name,b_sample_means_value=zip(*[('breakthrough_paper_'+str(n),k) for n,k in enumerate([0.93,0.92,0.88,0.87,0.86,0.83,0.81,
0.53,0.48,0.43,0.43,0.42,0.36,0.32,0.28,0.27,
0.27,0.22,0.20,0.16])]+[('Nobel',0.1),('Original',0.01),('Review',-0.01),\
                        ('Prior_work_headlinening',-0.005)])
b_sample_means = DataFrame({'b_sample_means_name': b_sample_means_name,                             'b_sample_means_value': b_sample_means_value})
b_distribution = DataFrame({'frequency': N, 'bin': bins[1:]})
b_sample_means = DataFrame({'b_sample_means_name': b_sample_means_name,                             'b_sample_means_value': b_sample_means_value})


# In[ ]:




# In[32]:

xls_path='/Users/lingfeiw/Dropbox/teams/3 submit nature/Figure1/Figure1.xlsx'
save_xls(['b_distribution','b_sample_means'],         [b_distribution,b_sample_means], xls_path)


# In[ ]:




# In[19]:




# In[22]:




# In[ ]:




# ### 2. distribution of disruption of all papers

# In[6]:

ds=D.values()
peaks=[]
for i in range(1,100):
    for j in range(1,i):
        peaks.append(j/i)
        peaks.append(-j/i)
peaks=sorted(set(peaks))


# In[7]:

nbins=500
cmap = cm.get_cmap('rainbow',nbins)
fig = plt.figure(figsize=(8, 3),facecolor='white')
ax = fig.add_subplot(111)
#
N, bins, patches = ax.hist(ds, bins=nbins,edgecolor='white', linewidth=0)
delta=bins[1]-bins[0]
#smooth
ys={}
for i in range(1,len(N)-2):
    ys[i]=(patches[i-1]._height+           patches[i+1]._height)*0.5
for i,j,z in zip(range(0,nbins),N,bins):
    if j==0:
        j=2
    patches[i].set_facecolor(color='RoyalBlue')
    for p in peaks:
        if z<p<z+delta and 0<i<len(N):
            patches[i]._height=ys[i]
    r=(np.log(patches[i]._height)/np.log(max(N)))**3
    patches[i].set_alpha(r)
#
plt.ylim(1,10**7)
plt.xlim(-1,1)

plt.yscale('log')
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/wordsDis.pdf')
plt.show()


# In[517]:

nbins=30000
cmap = cm.get_cmap('rainbow',nbins)
fig = plt.figure(figsize=(8, 3),facecolor='white')
ax = fig.add_subplot(111)
#
N, bins, patches = ax.hist(ds, bins=nbins,edgecolor='white', linewidth=0)
LN=np.log(max(N))
#smooth
ys={}
for i in range(1,len(N)-2):
    ys[i]=(patches[i-1]._height+           patches[i+1]._height)*0.5
for i,j,z in zip(range(0,nbins),N,bins):
    if j==0:
        j=1
    patches[i].set_facecolor(color='RoyalBlue')
    for p in peaks:
        if z<=p<=z+delta and 0<i<len(N)-2 and i in ys:
            patches[i]._height=ys[i]
    if patches[i]._height==0:
        patches[i]._height=1
    r=(np.log(patches[i]._height)/LN)**5
    patches[i].set_alpha(r)
#
plt.plot([0.1,0.1],[1,1*10**5],color='brown')
plt.text(0.1,1*10**5,'Nobel')
#
plt.plot([0.0008,0.0008],[1,1*10**6],color='brown')
plt.text(0.0008,1*10**6,'Reviewed')

plt.plot([-0.0009,-0.0009],[1,1*10**6],color='brown')
plt.text(-0.0009,1*10**6,'Reviewing',ha='left')
#
plt.plot([-0.0049,-0.0049],[1,1*10**6],color='brown')
plt.text(-0.0049,1*10**6,'Title citation',ha='right')

for k in [0.93,0.92,0.88,0.87,0.86,0.83,0.81,
0.53,0.48,0.43,0.43,0.42,0.36,0.32,0.28,0.27,
0.27,0.22,0.20,0.16]:
    plt.plot([k,k],[1,1*10**6],color='gold')
    
#
plt.yscale('log')
plt.xscale('symlog',linthreshx=0.001)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/wordsDisv.pdf')
plt.show()


# In[11]:

nbins=50000
cmap = cm.get_cmap('rainbow',nbins)
fig = plt.figure(figsize=(10, 3),facecolor='white')
ax = fig.add_subplot(111)
#
N, bins, patches = ax.hist(ds, bins=nbins,edgecolor='white', linewidth=0)
LN=np.log(max(N))
#smooth
ys={}
for i in range(1,len(N)-2):
    ys[i]=(patches[i-1]._height+           patches[i+1]._height)*0.5
delta=bins[1]-bins[0]
for i,j,z in zip(range(0,nbins),N,bins):
    if j==0:
        j=1
    patches[i].set_facecolor(color='RoyalBlue')
    for p in peaks:
        if z<=p<=z+delta and 0<i<len(N)-2 and i in ys:
            patches[i]._height=ys[i]
    if patches[i]._height==0:
        patches[i]._height=1
    r=(np.log(patches[i]._height)/LN)**5
    patches[i].set_alpha(r)
#
plt.plot([0.1,0.1],[1,1*10**5],color='brown')
plt.text(0.1,1*10**5,'Nobel')
#
plt.plot([0.0008,0.0008],[1,1*10**6],color='brown')
plt.text(0.0008,1*10**6,'Reviewed')

plt.plot([-0.0009,-0.0009],[1,1*10**6],color='brown')
plt.text(-0.0009,1*10**6,'Reviewing',ha='left')
#
plt.plot([-0.0049,-0.0049],[1,1*10**6],color='brown')
plt.text(-0.0049,1*10**6,'Title citation',ha='right')

plt.plot([0.2147,0.2147],[1,1*10**6],color='k')
plt.plot([-0.01147,-0.01147],[1,1*10**6],color='k')
plt.plot([0.86,0.86],[1,1*10**6],color='g')
plt.plot([-0.58,-0.58],[1,1*10**6],color='g')  
#
plt.yscale('log')
plt.xscale('symlog',linthreshx=0.001)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/wordsDisv3.pdf')
plt.show()


# In[7]:

bins[1]-bins[0]


# In[5]:

nbins=30000
cmap = cm.get_cmap('rainbow',nbins)
fig = plt.figure(figsize=(8, 3),facecolor='white')
ax = fig.add_subplot(111)
#
#smooth
#
plt.plot([0.1,0.1],[1,1*10**5],color='brown')
plt.text(0.1,1*10**5,'Nobel')
#
plt.plot([0.0008,0.0008],[1,1*10**6],color='brown')
plt.text(0.0008,1*10**6,'Reviewed')

plt.plot([-0.0009,-0.0009],[1,1*10**6],color='brown')
plt.text(-0.0009,1*10**6,'Reviewing',ha='left')
#
plt.plot([-0.0049,-0.0049],[1,1*10**6],color='brown')
plt.text(-0.0049,1*10**6,'Title citation',ha='right')

for k in [0.93,0.92,0.88,0.87,0.86,0.83,0.81,
0.53,0.48,0.43,0.43,0.42,0.36,0.32,0.28,0.27,
0.27,0.22,0.20,0.16]:
    plt.plot([k,k],[1,1*10**6],color='gold')
    
plt.plot([0.2147,0.2147],[1,1*10**6],color='k')
plt.plot([-0.01147,-0.01147],[1,1*10**6],color='k')

plt.ylim(1,10**7)
#
plt.yscale('log')
plt.xscale('symlog',linthreshx=0.001)
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/wordsDisv2.pdf')
plt.show()


# In[ ]:




# In[3]:

np.mean([0.93,0.92,0.88,0.87,0.86,0.83,0.81,
0.53,0.48,0.43,0.43,0.42,0.36,0.32,0.28,0.27,
0.27,0.22,0.20,0.16])


# In[15]:

stats.percentileofscore(ds, 0.86)


# In[10]:

stats.percentileofscore(ds, 0.16)


# In[16]:

stats.percentileofscore(ds, -0.58)


# In[17]:

stats.percentileofscore(ds, 0.0008),stats.percentileofscore(ds, -0.0009)


# In[20]:

100-76.147


# In[18]:

stats.percentileofscore(ds, -0.0049)


# In[11]:

nbins=300
cmap = cm.get_cmap('rainbow',nbins)
fig = plt.figure(figsize=(8, 3),facecolor='white')
ax = fig.add_subplot(111)
#
N, bins, patches = ax.hist(ds, bins=nbins,edgecolor='white', linewidth=0)
LN=np.log(max(N))
#smooth
ys={}
for i in range(1,len(N)-2):
    ys[i]=(patches[i-1]._height+           patches[i+1]._height)*0.5
delta=bins[1]-bins[0]
for i,j,z in zip(range(0,nbins),N,bins):
    if j==0:
        j=1
    patches[i].set_facecolor(color='RoyalBlue')
    for p in peaks:
        if z<=p<=z+delta and 0<i<len(N)-2 and i in ys:
            patches[i]._height=ys[i]
    if patches[i]._height==0:
        patches[i]._height=1
    r=(np.log(patches[i]._height)/LN)**5
    patches[i].set_alpha(r)
#
plt.plot([0.1,0.1],[1,1*10**5],color='brown')
plt.text(0.1,1*10**5,'Nobel')
#
plt.plot([0.0008,0.0008],[1,1*10**6],color='brown')
plt.text(0.0008,1*10**6,'Reviewed')

plt.plot([-0.0009,-0.0009],[1,1*10**6],color='brown')
plt.text(-0.0009,1*10**6,'Reviewing',ha='left')
#
plt.plot([-0.0049,-0.0049],[1,1*10**6],color='brown')
plt.text(-0.0049,1*10**6,'Title citation',ha='right')

for k in [0.93,0.92,0.88,0.87,0.86,0.83,0.81,
0.53,0.48,0.43,0.43,0.42,0.36,0.32,0.28,0.27,
0.27,0.22,0.20,0.16]:
    plt.plot([k,k],[1,1*10**6],color='gold')
    
for k in [-0.58,-0.04,0.86]:
    plt.plot([k,k],[1,1*10**6],color='g')
plt.plot([0.52,.52],[1,1*10**6],color='k')
#
plt.yscale('log')
plt.xscale('symlog',linthreshx=0.001)
plt.tight_layout()
plt.show()


# In[ ]:




# In[323]:

xa=['test','assessment','measure','estimation','tool','device','method','technique']
ya=[1.23,1.27,1.29,1.33,1.36,1.53,1.57,1.63]
xb=['theory','model','hypothesis','mechanism','pattern']
yb=list(2-np.array([0.79,0.80,0.86,0.91,0.95]))
yb


# In[382]:

fig = plt.figure(figsize=(6, 4),facecolor='white')
ax = fig.add_subplot(111)
ax.bar(range(len(yb+ya)),np.array(yb+ya),width=0.8,tick_label=map(str,yb+ya))
plt.ylim(1,2)
plt.xticks(rotation=80)
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/words1.pdf')
plt.show()


# In[ ]:




# In[ ]:




# In[365]:

a1=['interact','associate','is','confirm','correlate','are','cause','introduce','use']
b1=[2-0.31,2-0.48,2-0.52,2-0.52,2-0.56,2-0.61,1.16,1.25,1.52]


# In[383]:

fig = plt.figure(figsize=(6, 4),facecolor='white')
ax = fig.add_subplot(111)
ax.bar(range(len(a1)),np.array(b1),width=0.8,tick_label=map(str,b1))
plt.ylim(1,2)
plt.xticks(rotation=80)
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/words2.pdf')
plt.show()


# In[368]:

a2=['not','within','between','how','what','who','why']
b2=[2-0.50,2-0.66,2-0.90,1.23,1.39,1.43,1.46]


# In[384]:

fig = plt.figure(figsize=(6, 4),facecolor='white')
ax = fig.add_subplot(111)
ax.bar(range(len(a2)),np.array(b2),width=0.8,tick_label=map(str,b2))
plt.ylim(1,2)
plt.xticks(rotation=80)
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/words3.pdf')
plt.show()


# ### 3. disruption and KL novelty

# In[397]:

d=defaultdict(lambda:[])
n=0
for i in N:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)#175
    if i in D:
        dis=np.round(D[i],1)
        nov=N[i]
        d[dis].append(nov)
d=dict(d)


# In[398]:

len(N)


# In[399]:

x,y,z=np.array(sorted([(k,np.mean(v),np.std(v)) for k,v in d.items()])).T


# In[400]:

plt.plot(x,y,'bo-')
plt.fill_between(x,y-z/2.0,y+z/2.0,color='green',alpha=0.1)
plt.plot([-1,1],[8,8],'k--')
plt.xlabel("Disruption")
plt.ylabel("KL novelty")


# In[404]:

dd=[]
z=0
for key in d:
    z+=1
    flushPrint(z)
    n=50
    data=d[key]
    m=int(len(data)*.8)
    if m>1000:
        m=1000
    ms=[]
    for j in range(n):
        flushPrints(str(z)+'_'+str(j))
        ms.append(np.mean(np.random.choice(data,m,replace=True)))
    a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
    dd.append([key,a,b])
dd=sorted(dd)


# In[523]:

fig = plt.figure(figsize=(8, 3),facecolor='white')
ax = fig.add_subplot(111)
plt.plot(x,y,marker='.',color='SteelBlue')
x1,y1,y2=np.array(dd).T
plt.fill_between(x1[10:],y1[10:],y2[10:],color='ForestGreen',alpha=0.3)
plt.fill_between(x1[:11],y1[:11],y2[:11],color='red',alpha=0.3)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/wordsKLnovelty.pdf')


# In[519]:

x1[10:]


# In[208]:

a,b=np.array([(N[i],D[i]) for i in N if i in D]).T


# In[219]:

plt.plot(a,b,'b.',alpha=0.3,markersize=3)
plt.xlabel('KL novelty')
plt.ylabel('Disruption')


# In[223]:

f=defaultdict(lambda:[])
n=0
for i in N:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)#175
    if i in D:
        dis=D[i]
        nov=np.round(N[i],0)
        f[nov].append(dis)
f=dict(f)


# In[225]:

x1,y1,z1=np.array(sorted([(k,np.mean(v),np.std(v)) for k,v in f.items()])).T


# In[231]:

plt.plot(x1,y1,'b.-')
plt.fill_between(x1,y1-z1/2.0,y1+z1/2.0,color='green',alpha=0.1)
plt.plot([0,25],[0,0],'k--')
plt.ylim(-0.2,0.1)
plt.ylabel("Disruption")
plt.xlabel("KL novelty")


# In[ ]:




# In[ ]:




# In[ ]:




# In[11]:




# In[110]:




# In[156]:




# In[94]:

def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,11):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b


# In[150]:

plt.hist(d[0.1],50,color='b',alpha=0.2)
#plt.hist(d[0.8],50,color='g',alpha=0.2,normed=1)
plt.show()


# In[148]:

plt.hist(d[0],50,color='b',alpha=0.2)
#plt.hist(d[0.8],50,color='g',alpha=0.2,normed=1)
plt.show()


# In[114]:

d[0.1][:3]


# In[115]:

d[0.8][:3]


# In[127]:




# In[129]:

plt.plot(x,y,'bo-')
x1,y1,y2=np.array(dd).T
plt.fill_between(x1,y1,y2,color='green',alpha=0.1)


# In[93]:

plt.plot(x,y,'bo-')
plt.fill_between(x,y-z/2.0,y+z/2.0,color='green',alpha=0.1)
plt.plot([-1,1],[8,8],'k--')
plt.xlabel("Disruption")
plt.ylabel("KL novelty")


# In[155]:

plt.plot(x,y,'bo-')
plt.fill_between(x,y-z/2.0,y+z/2.0,color='green',alpha=0.1)
plt.plot([-1,1],[8,8],'k--')
plt.xlabel("Disruption")
plt.ylabel("KL novelty")


# In[22]:

pearsonr(x, y)


# In[3]:

# diverse scholar: include small-team, disruptive-research scholars
n=0
authorid=0
B={}
D=[]
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        v=map(int,line[1:])
        #v=[i for i in v if i in W and 1955<W[i][-1]<=2005]
        v=[i for i in v if i in W]
        if v:
            B[authorid]=line[0]
            for i in v:
                teamsize,impact,topicid,disruption,journal,pubyear=W[i]
                if teamsize>15:
                    teamsize=15
                ts=[0]*15
                ts[teamsize-1]=1
                D.append([disruption]+ts+[authorid,pubyear,topicid])
            authorid+=1
            #if nauthor>1,000,000:
            #    break
len(B),len(D)#(25398049, 56443309) for 1955-2005
#38000470, 96386516


# In[18]:

#
#D=np.array(D)
#dis=D[:,0]
#disruption_pt=np.array(stats.rankdata(dis, "average")/len(dis))
#D[:,0]=disruption_pt*100
#len(D)# replace disruption to disruption percentiles


# In[5]:

#D=np.array(D)
#dis=D[:,0]
#disruption_pt=0.5*np.log((1+dis)/(1-dis))
#D[:,0]=disruption_pt


# In[6]:

max([i[0] for i in D])


# In[26]:

n=1000000
#x=np.linspace(-1,1,1000)
x=dis[:n]
#y=0.5*np.log((1+x)/(1-x))
y=disruption_pt[:n]
plt.plot(x,y,'b.')


# In[ ]:




# In[20]:

v=D[0]
str(float(v[0]))+'\t'+'\t'.join([str(int(i)) for i in v[1:]]) + '\n'


# In[80]:

#versions: 
#1. radom 1k authors (>=2paper), 
#2. radom 10k authors (>=2paper)
#3. radom 10k authors (>=1 paper), 
#4. radom 1,000,000 authors (>=1 paper) ------good
#5. all 852,153 authors (>=2 paper) --------good
#6. all 8,527,512 authors (>=2 paper)
#7. all 38,000,470 authors (>=1 papers)---not sure
#8. all 34,789,926 papers of name disambiguated authors, 7,158,483 scholars
#----9. all 38,000,470 authors (>=1 papers)---too big
#----9. all 56,443,309 papers 1956-2005 from 25,398,049 scholars
#9. all 96,386,516 papers from 38,000,470 scholars
#10.all 96,386,516 papers from 38,000,470 scholars  original disruption


# In[7]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption2ndRevision_10_authorDic.txt', "wb") as f:
    for k in B:
        f.write(str(k)+'\t' + str(B[k])+'\n')


# In[8]:

n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption2ndRevision_10.txt', "wb") as f:
    for v in D:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#964
        f.write(str(float(v[0]))+'\t'+'\t'.join([str(int(i)) for i in v[1:]]) + '\n')


# In[ ]:




# In[ ]:




# In[ ]:




# ### whole dataset

# In[4]:

len(W)


# In[9]:

nauthor=0
A={}
B={}
D=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/Team2.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#116
        line=line.strip().split('\t')
        p=int(line[0])
        m=len(line)-1
        if p in W and W[p][0]==m:# all authors are identified
            teamsize,topicid,disruption,journal,pubyear=W[p]
            if teamsize>15:
                teamsize=15
            ts=[0]*15
            ts[teamsize-1]=1
            for a in line[1:]:
                if a not in A:
                    A[a]=nauthor
                    B[nauthor]=a
                    nauthor+=1
                D.append([disruption]+ts+[A[a],pubyear,topicid])           


# In[10]:

# replace disruption to disruption percentiles
D=np.array(D)
dis=D[:,0]
disruption_pt=np.array(stats.rankdata(dis, "average")/len(dis))
D[:,0]=disruption_pt*100


# In[11]:

len(D),len(A),len(B)


# In[12]:

36965331/7158483.0


# In[14]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption2ndRevision_7_authorDic.txt', "wb") as f:
    for k in B:
        f.write(str(k)+'\t' + str(B[k])+'\n')


# In[23]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption2ndRevision_7.txt', "wb") as f:
    for v in D:
        f.write(str(float(v[0]))+'\t'+'\t'.join([str(int(i)) for i in v[1:]]) + '\n')


# # whote datset with scholars of 2+ papers

# In[3]:

n=0
N=defaultdict(lambda:0)
# papers in which all authors are identified 
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/Team2.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#116
        line=line.strip().split('\t')
        N[len(line)-1]+=1


# In[6]:

del N[0]


# In[13]:

x,y=np.array(N.items()).T
plt.plot(x,y/float(y.sum()),'bo-',label='author name disambiguated papers')
plt.plot(x1,y1/float(y1.sum()),'go-',label='all papers')
#plt.xscale('log')
#plt.yscale('log')
plt.xlim(1,10)


# In[9]:

cc=Counter([W[i][0] for i in W])
x1,y1=np.array(sorted(cc.items())).T


# In[14]:

n=0
nauthor=0
A={}
P=defaultdict(lambda:0)
# papers in which all authors are identified 
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/Team2.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#116
        line=line.strip().split('\t')
        p=int(line[0])
        if p in W:
            for a in line[1:]:
                if a not in A:
                    A[a]=nauthor
                    nauthor+=1
                P[A[a]]+=1               


# In[17]:

# diverse scholar: include small-team, disruptive-research scholars
n=0
nauthor=0
A={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#81,800,000
        line=line.strip().split('\t')
        v=map(int,line[1:])
        v=[i for i in v if i in W]
        if len(v)>=1 and random.random()<0.1:
            nauthor+=1
            A[nauthor]=len(v)
            if nauthor>1000000:
                break
len(A)


# In[18]:

cc1=Counter(A.values())


# In[ ]:

cc=Counter(P.values())


# In[35]:

fig = plt.figure(figsize=(10, 4),facecolor='white')
ax = fig.add_subplot(121)
#
x1,y1=np.array(sorted(cc.items())).T
x2,y2=np.array(sorted(cc1.items())).T
plt.plot(x2,y2,'go-',label='(exp. 1) random 1m scholars')
plt.plot(x1,y1,'bo-',label='(exp. 2) 7m scholars in all disam-papers')
plt.legend(fontsize=10)
#plt.xscale('log')
#plt.yscale('log')
plt.xlim(1,10)
plt.xlabel('N of publication',size=16)
plt.ylabel('Frequency',size=16)
plt.ylim(0,3000000)
#
ax = fig.add_subplot(122)
x1,y1=np.array(sorted(cc.items())).T
x2,y2=np.array(sorted(cc1.items())).T
plt.plot(x2,y2/float(y2.sum()),'go-',label='(exp. 1) random 1m scholars')
plt.plot(x1,y1/float(y1.sum()),'bo-',label='(exp. 2) 7m scholars in all disam-papers')

#plt.xscale('log')
#plt.yscale('log')
plt.xlim(1,10)
plt.ylim(0,1)
plt.xlabel('N of publication',size=16)
plt.ylabel('Probability',size=16)
plt.legend(fontsize=10)


# In[ ]:




# In[5]:

n=0
nauthor=0
A={}
B={}
P=defaultdict(lambda:[])
# papers in which all authors are identified 
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/Team2.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#116
        line=line.strip().split('\t')
        p=int(line[0])
        m=len(line)-1
        if p in W and W[p][0]==m:# all authors are identified
            for a in line[1:]:
                if a not in A:
                    A[a]=nauthor
                    B[nauthor]=a
                    nauthor+=1
                P[A[a]].append(p)                


# In[6]:

len(P)


# In[7]:

cc=Counter(map(len,P.values()))


# In[21]:

sum([k*v for k,v in cc.items()])


# In[9]:

max(cc.keys())


# In[16]:

n,m


# In[23]:

D=[]
n=0
for u in P:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)#71
    if len(P[u])>=2:
        for p in P[u]:
            teamsize,topicid,disruption,journal,pubyear=W[p]
            if teamsize>15:
                teamsize=15
            ts=[0]*15
            ts[teamsize-1]=1  
            D.append([disruption]+ts+[u,pubyear,topicid]) 


# In[24]:

len(D)


# In[25]:

n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption2ndRevision_8_authorDic.txt', "wb") as f:
    for u in B:
        if len(P[u])>=2:
            n+=1
            f.write(str(k)+'\t' + str(B[k])+'\n')
n


# In[26]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorDisruption2ndRevision_8.txt', "wb") as f:
    for v in D:
        f.write(str(float(v[0]))+'\t'+'\t'.join([str(int(i)) for i in v[1:]]) + '\n')


# In[ ]:




# In[2]:

-.7104862-.0432902


# In[2]:




# In[7]:

nonfix=[-.0022048,-.0023823,-.0024124,-.0025324,-.0026259,-.0026805,-.0026705,-.002744,
        -.0027682,-.002822,-.0029016,-.0030009,-.0030581,-.0033785]
fix=   [-.0001975,-.0003201,-.0003383,-.0004639 ,-.0005576,-.0006895,-.0007459,-.0008957,
        -.0009901,-.0010725, -.0011694,-.0013409, -.0013706,-.0016437]

dfix=[[-.0002773,-.0001177],
 [ -.000399, -.0002412],
 [-.0004171 ,  -.0002596],
 [ -.0005427  , -.0003852],
 [-.0006366,   -.0004787],
 [-.0007688  ,  -.0006102],
 [-.0008257  , -.0006661],
 [-.0009765 ,  -.0008149],
 [ -.001072 ,  -.0009082],
 [-.0011561  , -.0009889],
 [-.0012563  , -.0010824],
 [-.0014318  , -.0012501],
 [-.0014693  , -.0012719],
 [-.0017327 ,  -.0015546]]

dnofix=[[-.0022713  , -.0021382],
[-.0024467,   -.0023178],
[-.0024762 ,  -.0023486],
[ -.002596 ,  -.0024689],
[-.0026894  , -.0025623],
[-.0027443 ,  -.0026167],
[ -.0027349 ,  -.0026061],
[-.0028095 ,  -.0026785],
[-.0028347 ,  -.0027017],
[-.0028901 ,  -.0027539],
[ -.0029733 ,  -.0028299],
[ -.0030768 ,   -.002925],
[ -.003141  , -.0029752],
[-.0034475  , -.0033096]]

x,y=zip(*dfix)
x1,y1=zip(*dnofix)


# In[50]:

fig = plt.figure(figsize=(5, 5),facecolor='white')
#
ax = fig.add_subplot(111)
plt.fill_between(range(2,16),x,y,color='gray',alpha=0.5)
plt.plot(range(2,16),fix,color='blue',label='With author fixed effects')
#
plt.plot(range(2,16),nonfix,color='green',label='Without author fixed effects')
plt.fill_between(range(2,16),x1,y1,color='gray',alpha=0.5)
plt.ylim(-0.003,0.0005)
plt.xlim(2,10)
plt.xticks([2,4,6,8,10])
#
plt.legend(loc=1,frameon=False)
#

ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('team size',fontsize=16)
plt.ylabel('regression coefficient',fontsize=16)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2_101.pdf')


# In[44]:

-.001


# In[48]:

stats.percentileofscore(ds,-.0001975)-stats.percentileofscore(ds,-.0009901)


# In[ ]:




# In[40]:



#
ax = fig.add_subplot(122)
plt.fill_between(range(2,16),x,y,color='gray',alpha=0.5)
plt.plot(range(2,16),fix,color='blue',label='With author fixed effects')
#
plt.plot(range(2,16),nonfix,color='green',label='Without author fixed effects')
plt.fill_between(range(2,16),x1,y1,color='gray',alpha=0.5)
plt.ylim(-0.003,0.0005)
plt.xlim(2,10)
plt.xticks([2,4,6,8,10])
ax.set_yticks([-0.003,-0.0025,-0.002,-0.0015,-0.001,-0.0005,0,0.0005])
ax.set_yticklabels(['32','34','38','41','46','53','68','75'])
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.legend(loc=1,frameon=False)
#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2_100.pdf')


# In[ ]:




# In[22]:

ds=random.sample(D.values(),100000)


# In[23]:

stats.percentileofscore(ds,0),stats.percentileofscore(ds,-0.003),stats.percentileofscore(ds,-0.)


# In[24]:

marks= [-0.003,-0.0025,-0.002,-0.0015,-0.001,-0.0005,0,0.0005,0.001]


# In[25]:

ps=[stats.percentileofscore(ds,i) for i in marks]


# In[26]:

ps


# In[37]:

ps=['32','34','38','41','46','53','68','75','77']


# In[ ]:




# In[ ]:




# In[ ]:




# In[62]:

nonfix=[-3.031597,-3.081768,-3.068917,-3.302813,-3.756684,-4.190455,-4.646,
       -5.256102,-5.78906,-6.471692,-7.240433,-8.013681,-8.2683,-10.674]
fix=[-.7104862,-.9051582,-1.165447,-1.620146,-2.162747,-2.691827,-3.238197,
    -3.842076,-4.442213,-4.917321,-5.545198,-6.110612,-6.231235,-8.441754]

dfix=[[-.7953333,-.625639],
 [ -.9912426, -.8190738],
 [-1.252562 ,  -1.078332],
 [-1.708519  , -1.531773],
 [-2.252195,   -2.073298],
 [-2.78259  , -2.601065],
 [-3.33066   ,-3.145734],
 [-3.936347,   -3.747805],
 [-4.538579 ,  -4.345847],
 [-5.016685  , -4.817957],
 [-5.647865,   -5.442531],
 [-6.217657 ,  -6.003566],
 [-6.344162  , -6.118308],
 [-8.546084  , -8.337424]]

dnofix=[[-3.078037,   -2.985157],
[-3.128474  , -3.035062],
[-3.116541  , -3.021292],
[-3.351715  , -3.253911],
[-3.806698  , -3.706671],
[-4.24195   ,-4.138961],
[-4.699375  , -4.592624],
[-5.311792  , -5.200411],
[-5.847217  , -5.730902],
[-6.533691  , -6.409693],
[-7.306866 ,  -7.173999],
[-8.085932 ,   -7.94143],
[-8.347333  , -8.189268],
[-10.74252 ,  -10.60549]]

x,y=zip(*dfix)
x1,y1=zip(*dnofix)


# In[68]:

with open('/Users/lingfeiw/Desktop/fig.csv','wb') as f:
    for v in zip(x,fix,y,x1,nonfix,y1):
        f.write(','.join(map(str,v))+'\n')


# In[38]:

fig = plt.figure(figsize=(10, 5),facecolor='white')
#
ax = fig.add_subplot(121)
plt.fill_between(range(2,16),x1,y1,color='RoyalBlue',alpha=0.7)
plt.ylim(-11,0)
plt.xlim(2,16)
#plt.plot()
#
ax = fig.add_subplot(122)
plt.fill_between(range(2,16),x,y,color='ForestGreen',alpha=0.7)
plt.ylim(-11,0)
plt.xlim(2,16)
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2_99.pdf')


# In[63]:

fig = plt.figure(figsize=(5, 5),facecolor='white')
#
ax = fig.add_subplot(111)
plt.fill_between(range(2,16),x,y,color='gray',alpha=0.5)
plt.plot(range(2,16),fix,color='blue',label='With author fixed effects')
#
plt.plot(range(2,16),nonfix,color='green',label='Without author fixed effects')
plt.fill_between(range(2,16),x1,y1,color='gray',alpha=0.5)
plt.ylim(-6,0)
plt.xlim(2,10)
plt.xticks([2,4,6,8,10])
#
plt.legend(loc=1,frameon=False)
plt.xlabel('teamsize',size=16)
plt.ylabel('regression coefficient',size=16)
#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2_99.pdf')


# In[64]:

fig = plt.figure(figsize=(5, 5),facecolor='white')
#
ax = fig.add_subplot(111)
plt.fill_between(range(2,16),x,y,color='gray',alpha=0.5)
plt.plot(range(2,16),fix,color='blue',label='With author fixed effects')
#
plt.plot(range(2,16),nonfix,color='green',label='Without author fixed effects')
plt.fill_between(range(2,16),x1,y1,color='gray',alpha=0.5)
plt.ylim(-6,0)
plt.xlim(2,10)
plt.xticks([2,4,6,8,10])
#
plt.legend(loc=1,frameon=False)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2_99.pdf')


# In[12]:




# In[13]:




# In[ ]:



