
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator


# In[2]:

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# ### Nobel papers and grants

# #### Grant disrubution over time and fields

# In[3]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[4]:

len(W)


# In[5]:

GY=defaultdict(lambda:defaultdict(lambda:0))
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if Id in W:
            year=W[Id][0]
            if year>=2008:
                if grantSize<10**5:
                    GY[1][year]+=1
                if 10**5<=grantSize<10**6:
                    GY[2][year]+=1
                if 10**6<=grantSize:
                    GY[3][year]+=1
FY=defaultdict(lambda:defaultdict(lambda:0))
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if Id in W:
            year=W[Id][0]
            if year>=2008:
                field=W[Id][1]
                if grantSize<10**5:
                    FY[1][field]+=1
                if 10**5<=grantSize<10**6:
                    FY[2][field]+=1
                if 10**6<=grantSize:
                    FY[3][field]+=1


# In[6]:

fd={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}


# In[7]:

fs=[12, 1, 3, 6, 5, 9, 4, 11, 10, 13, 2, 0, 7]


# In[8]:

fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(122)
x,y=np.array(GY[3].items()).T
plt.plot(x,y,'ro-',label='> 1M')
x,y=np.array(GY[2].items()).T
plt.plot(x,y,'go-',label='100k ~ 1M')
x,y=np.array(GY[1].items()).T
plt.plot(x,y,'bo-',label='< 100k')
plt.legend(loc=2,fontsize=10)
plt.xticks(range(2008,2015),map(str,range(2008,2015)))
#
ax = fig.add_subplot(121)
bar_width = 0.3
plt.barh(np.arange(13)+bar_width*2, [FY[3][i] for i in fs[::-1]],          bar_width,color='r',label='> 1M')
plt.barh(np.arange(13)+bar_width, [FY[2][i] for i in fs[::-1]],         bar_width,color='g',label='100k ~ 1M')
plt.barh(np.arange(13), [FY[1][i] for i in fs[::-1]],          bar_width,color='b',label='< 100k')
plt.yticks(np.arange(13)+bar_width, [fd[i] for i in fs[::-1]])
plt.legend(loc=4,fontsize=10)
#
plt.show()


# In[111]:




# In[9]:

gt=defaultdict(lambda:[0,0])# n of grants, total size
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if grantSize>=10**5:
            gt[Id][0]+=1
            gt[Id][1]+=grantSize

G=defaultdict(lambda:[])
GJ=defaultdict(lambda:set([]))
for k,v in gt.items():
    if k in W:
        year,subject,teamsize,impact,disruptive,journal=W[k]
        if year>=2008:
            grantsize=v[1]/v[0]
            if grantsize>=10**6:
                gs=2
            else:
                gs=1
            G[gs].append([teamsize,impact,disruptive])
            GJ[gs].add(journal)

N=defaultdict(lambda:[])
NJ=defaultdict(lambda:set([]))
with open('/Users/lingfeiw/Documents/research/teamscience/nobel/nobelFinal.txt','r') as f:
    for line in f:
        line=line.strip().split('\t')
        nobelawardyear,nobelprizekind,author,publishyear,WOSid, nid,         teamsize, impact, disruptiveness=line
        if int(publishyear)<=int(nobelawardyear)-10 and int(nid) in W:
            ### the work of noble prize winners 10 years before they got the prizes 
            journal=W[int(nid)][-1]
            N[int(nobelprizekind)].append([int(teamsize), int(impact), float(disruptiveness)])
            NJ[int(nobelprizekind)].add(journal)
#1=生理学或医学，2=物理，3=化学，4=经济学

t1,i1,d1= np.array(N[1]).T
t2,i2,d2= np.array(N[2]).T
t3,i3,d3= np.array(N[3]).T
t4,i4,d4= np.array(G[1]).T
t5,i5,d5= np.array(G[2]).T


# In[10]:

# team size base-line distributions
tMed=Counter([v[2] for v in W.values() if v[-1] in NJ[1] ])
tPhy=Counter([v[2] for v in W.values() if v[-1] in NJ[2]])
tChe=Counter([v[2] for v in W.values() if v[-1] in NJ[3]])
tNSFb=Counter([v[2] for v in W.values() if v[-1] in GJ[1] and v[0]>=2008])
tNSFs=Counter([v[2] for v in W.values() if v[-1] in GJ[2] and v[0]>=2008])
#
xtMed,ytMed=np.array(sorted(tMed.items())).T
xtPhy,ytPhy=np.array(sorted(tPhy.items())).T
xtChe,ytChe=np.array(sorted(tChe.items())).T
xtNSFb,ytNSFb=np.array(sorted(tNSFb.items())).T
xtNSFs,ytNSFs=np.array(sorted(tNSFs.items())).T
#
ytMed=ytMed/float(ytMed.sum())
ytPhy=ytPhy/float(ytPhy.sum())
ytChe=ytChe/float(ytChe.sum())
ytNSFb=ytNSFb/float(ytNSFb.sum())
ytNSFs=ytNSFs/float(ytNSFs.sum())


# In[11]:

x1,y1=np.array(sorted(Counter(t1).items())).T
x2,y2=np.array(sorted(Counter(t2).items())).T
x3,y3=np.array(sorted(Counter(t3).items())).T
x4,y4=np.array(sorted(Counter(t4).items())).T
x5,y5=np.array(sorted(Counter(t5).items())).T
y1=y1/float(sum(y1))
y2=y2/float(sum(y2))
y3=y3/float(sum(y3))
y4=y4/float(sum(y4))
y5=y5/float(sum(y5))


# In[12]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(15,3)) 
ax = fig.add_subplot(151)
plt.plot(xtMed,ytMed,'k--')
plt.plot(x1,y1,color=cmap(0),marker='.',linestyle='-',label='Pre-Nobel MED')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.35)
#
ax = fig.add_subplot(152)
plt.plot(xtPhy,ytPhy,'k--')
plt.plot(x2,y2,color=cmap(1),marker='.',linestyle='-',label='Pre-Nobel PHY')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.35)
#
ax = fig.add_subplot(153)
plt.plot(xtChe,ytChe,'k--')
plt.plot(x3,y3,color=cmap(2),marker='.',linestyle='-',label='Pre-Nobel CHE')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.35)
#
ax = fig.add_subplot(154)
plt.plot(xtNSFs,ytNSFs,'k--')
plt.plot(x4,y4,color=cmap(3),marker='.',linestyle='-',label='NSF <1M')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.35)
#
ax = fig.add_subplot(155)
plt.plot(xtNSFb,ytNSFb,'k--')
plt.plot(x5,y5,color=cmap(4),marker='.',linestyle='-',label='NSF >1M')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.35)
#
plt.tight_layout()


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[6]:




# In[13]:

NB=list(d1[t1>3])+list(d2[t2>3])+list(d3[t3>3])
NS=list(d1[t1<=3])+list(d2[t2<=3])+list(d3[t3<=3])
FB=list(d4[t4>3])+list(d5[t5>3])
FS=list(d4[t4<=3])+list(d5[t5<=3])
#
NB=[np.round(i,3) for i in NB]
NS=[np.round(i,3) for i in NS]
FB=[np.round(i,3) for i in FB]
FS=[np.round(i,3) for i in FS]


# In[14]:

xns1,yns1=np.array(sorted(Counter(NS).items())).T
yns1=yns1/float(yns1.sum())
xnb1,ynb1=np.array(sorted(Counter(NB).items())).T
ynb1=ynb1/float(ynb1.sum())
xfs1,yfs1=np.array(sorted(Counter(FS).items())).T
yfs1=yfs1/float(yfs1.sum())
xfb1,yfb1=np.array(sorted(Counter(FB).items())).T
yfb1=yfb1/float(yfb1.sum())

disNobelBaseLine=[v[4] for v in W.values() if v[-1]                   in NJ[1] or v[-1] in NJ[2] or v[-1] in NJ[3]]
disNSFBaseLine=[v[4] for v in W.values() if v[-1]                   in GJ[1] or v[-1] in GJ[2] and v[0]>=2008]
disNobelBaseLine=[np.round(i,3) for i in disNobelBaseLine]
disNSFBaseLine=[np.round(i,3) for i in disNSFBaseLine]
xdisNobelBaseLine,ydisNobelBaseLine=np.array(sorted(Counter(disNobelBaseLine).items())).T
xdisNSFBaseLine,yNSFBaseLine=np.array(sorted(Counter(disNSFBaseLine).items())).T
ydisNobelBaseLine=ydisNobelBaseLine/float(ydisNobelBaseLine.sum())
yNSFBaseLine=yNSFBaseLine/float(yNSFBaseLine.sum())


dicNobel=dict((i,j) for i,j in  zip(xdisNobelBaseLine,ydisNobelBaseLine) if -0.02<=i<=0.02)
dicNSF=dict((i,j) for i,j in  zip(xdisNSFBaseLine,yNSFBaseLine) if -0.02<=i<=0.02)
xns2,yns2=np.array([(i,j/dicNobel[i]) for i,j in  zip(xns1,yns1) if i in dicNobel]).T
xnb2,ynb2=np.array([(i,j/dicNobel[i]) for i,j in  zip(xnb1,ynb1) if i in dicNobel]).T
xfs2,yfs2=np.array([(i,j/dicNSF[i]) for i,j in  zip(xfs1,yfs1) if i in dicNSF]).T
xfb2,yfb2=np.array([(i,j/dicNSF[i]) for i,j in  zip(xfb1,yfb1) if i in dicNSF]).T


# In[ ]:




# In[412]:




# In[413]:




# In[416]:




# In[417]:




# In[421]:




# In[434]:

fig = plt.figure(figsize=(8,4)) 
ax = fig.add_subplot(121)
plt.plot(xdisNobelBaseLine,ydisNobelBaseLine,'k--')
plt.plot(xns1,yns1,color='#AA4466',marker='',linestyle='-',linewidth=2,label='Nobel small')
plt.plot(xnb1,ynb1,color='#AA4466',marker='',linestyle='-',alpha=0.5,label='Nobel big')
plt.xticks([-0.02,-0.01,0,0.01,0.02])
plt.xlim(-0.02,0.02)
plt.xlabel('disruptiveness')
plt.ylabel('probability')
plt.legend(loc=2,fontsize=10,numpoints=1)
#
ax = fig.add_subplot(122)
plt.plot(xdisNSFBaseLine,yNSFBaseLine,'k--')
plt.plot(xfs1,yfs1,color='RoyalBlue',marker='',linestyle='-',linewidth=2,label='NSF small')
plt.plot(xfb1,yfb1,color='RoyalBlue',marker='',linestyle='-',alpha=0.5,label='NSF big')
plt.xticks([-0.02,-0.01,0,0.01,0.02])
plt.xlim(-0.02,0.02)
plt.xlabel('disruptiveness')
plt.ylabel('probability')
plt.legend(loc=2,fontsize=10,numpoints=1)
#
plt.tight_layout()


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[435]:




# In[15]:

fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(121)
#patterns = [ "/" , "\\" , "|" , "-" , "+" , "x", "o", "O", ".", "*" ]
w = 1/8.0
r=3
plt.bar(np.array([1,2]), [sum(y1[:r])/sum(ytMed[:r]),sum(y1[r:])/sum(ytMed[r:])],        w,label='Pre-Nobel Medicine',color='#AA4466',alpha=0.9,hatch=".")
plt.bar(np.array([1,2])+w, [sum(y3[:r])/sum(ytChe[:r]),sum(y3[r:])/sum(ytChe[r:])],         w,label='Pre-Nobel Chemistry',color='#AA4466',alpha=0.6,hatch=".")
plt.bar(np.array([1,2])+2*w, [sum(y2[:r])/sum(ytPhy[:r]),sum(y2[r:])/sum(ytPhy[r:])],        w,label='Pre-Nobel Physics',color='#AA4466',alpha=0.4,hatch=".")
plt.bar(np.array([1,2])+3*w, [sum(y4[:r])/sum(ytNSFs[:r]),sum(y4[r:])/sum(ytNSFs[r:])],        w,label='NSF < 1M',color='RoyalBlue',alpha=0.4,hatch="/" )
plt.bar(np.array([1,2])+4*w, [sum(y5[:r])/sum(ytNSFs[:r]),sum(y5[r:])/sum(ytNSFs[r:])],        w,label='NSF >= 1M',color='RoyalBlue',alpha=0.6,hatch="/" )
plt.legend(loc=1,fontsize=12,ncol=2,frameon=False)
ax.set_xlim(0.8,2.8)
ax.set_ylim(0,2)
ax.set_xticks([1.35,2.3])
ax.set_xticklabels(['Small team (m<=3)','Big team (m>3)'],fontsize=14)
ax.plot([0,10],[1,1],'k--')
ax.set_ylabel('Probability ratio',fontsize=14)
#
ax = fig.add_subplot(122)
plt.plot(xns2,yns2,color='#AA4466',marker='',linestyle='-',linewidth=2,label='Pre-Nobel Small')
plt.plot(xnb2,ynb2,color='#AA4466',marker='',linestyle='-',alpha=0.5,label='Pre-Nobel Big')
plt.plot(xfs2,yfs2,color='RoyalBlue',marker='',linestyle='-',linewidth=2,label='NSF Small')
plt.plot(xfb2,yfb2,color='RoyalBlue',marker='',linestyle='-',alpha=0.5,label='NSF Big')
plt.xlim(-0.02,0.02)
ax.set_xticks([-0.02,-0.01,0,0.01,0.02])
plt.plot([0,0],[0,5],color='gray')
plt.plot([-1,1],[1,1],'k--')
plt.ylim(0,3)
ax.set_yticks([0,1,2,3])
plt.legend(loc='upper center',fontsize=12,frameon=False,numpoints=1,ncol=2)
ax.set_xlabel('Disruption',fontsize=14)
ax.set_ylabel('Probability ratio',fontsize=14)
#
#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.pdf')


# In[30]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
#patterns = [ "/" , "\\" , "|" , "-" , "+" , "x", "o", "O", ".", "*" ]
w = 1/8.0
r=3
plt.bar(np.array([1,2]), [sum(y1[:r])/sum(ytMed[:r]),sum(y1[r:])/sum(ytMed[r:])],        w,label='Pre-Nobel Medicine',color='#AA4466',alpha=0.9,hatch=".")
plt.bar(np.array([1,2])+w, [sum(y3[:r])/sum(ytChe[:r]),sum(y3[r:])/sum(ytChe[r:])],         w,label='Pre-Nobel Chemistry',color='#AA4466',alpha=0.6,hatch=".")
plt.bar(np.array([1,2])+2*w, [sum(y2[:r])/sum(ytPhy[:r]),sum(y2[r:])/sum(ytPhy[r:])],        w,label='Pre-Nobel Physics',color='#AA4466',alpha=0.4,hatch=".")
plt.bar(np.array([1,2])+3*w, [sum(y4[:r])/sum(ytNSFs[:r]),sum(y4[r:])/sum(ytNSFs[r:])],        w,label='NSF < 1M',color='RoyalBlue',alpha=0.4,hatch="/" )
plt.bar(np.array([1,2])+4*w, [sum(y5[:r])/sum(ytNSFs[:r]),sum(y5[r:])/sum(ytNSFs[r:])],        w,label='NSF >= 1M',color='RoyalBlue',alpha=0.6,hatch="/" )
plt.legend(loc=1,fontsize=12,ncol=2,frameon=False)
ax.set_xlim(0.8,2.8)
ax.set_ylim(0,2)
ax.set_xticks([1.35,2.3])
#ax.set_xticklabels(['Small team (m<=3)','Big team (m>3)'],fontsize=14)
ax.set_xticklabels([],[])
ax.plot([0,10],[1,1],'k--')
#ax.set_ylabel('Probability ratio',fontsize=14)
ax.set_yticklabels('')

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.1.pdf')


# In[31]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)

plt.plot(xns2,yns2,color='#AA4466',marker='',linestyle='-',linewidth=2,label='Pre-Nobel Small')
plt.plot(xnb2,ynb2,color='#AA4466',marker='',linestyle='-',alpha=0.5,label='Pre-Nobel Big')
plt.plot(xfs2,yfs2,color='RoyalBlue',marker='',linestyle='-',linewidth=2,label='NSF Small')
plt.plot(xfb2,yfb2,color='RoyalBlue',marker='',linestyle='-',alpha=0.5,label='NSF Big')
plt.xlim(-0.02,0.02)
ax.set_xticks([-0.02,-0.01,0,0.01,0.02])
plt.plot([0,0],[0,5],color='gray')
plt.plot([-1,1],[1,1],'k--')
plt.ylim(0,3)
ax.set_yticks([0,1,2,3])
plt.legend(loc='upper center',fontsize=12,frameon=False,numpoints=1,ncol=2)
#ax.set_xlabel('Disruption',fontsize=14)
#ax.set_ylabel('Probability ratio',fontsize=14)
ax.set_yticklabels('')
ax.set_xticklabels('')


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[ ]:



