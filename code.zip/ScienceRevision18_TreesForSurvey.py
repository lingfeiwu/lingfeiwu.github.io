
# coding: utf-8

# In[2]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# # export Figure data

# In[3]:

#bak=13869522
#davis=19977309
#randall=23644437
#selected=set([13869522,19977309,23644437])
selected=set([2949166,20818608,1736713,36896787,12058637,
              25690137,28082205,28704796,13828119,27869190,491562])


# In[5]:

#year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        Y[int(ndoi)]=int(year)


# In[6]:

#get ref
R={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        ref=line[1:]
        p=line[0]
        if p in selected:
            R[p]=ref


# In[14]:

#generate networks
F=defaultdict(lambda:[])
Ref=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        cites=set(line[1:])
        p=line[0]
        y=Y[p]
        for idx in selected:
            pubYear=Y[idx]
            ref=R[idx]
            if y>pubYear:
                if idx in cites:
                    F[idx].append([p,idx]) 
                o=set(cites).intersection(ref)
                if o:
                    for j in o:
                        F[idx].append([p,j])  


# In[15]:

len(selected),len(R),len(F)


# In[18]:

for idx in F:
    with open('/Users/lingfeiw/Desktop/versions/11_trees_data/'+str(idx)+'.csv', "w") as f:
        edges=F[idx]
        for i,j in edges:
            f.write(str(i)+','+str(Y[i])+','+str(j)+','+str(Y[j])+'\n')


# In[4]:

#prepare data for trees
F=defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:[])))
Roots=defaultdict(lambda:defaultdict(int))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        cites=set(line[1:])
        p=line[0]
        y=Y[p]
        for idx in selected:
            pubYear=Y[idx]
            ref=R[idx]
            if y>pubYear:
                if idx in cites: #cite focal paper
                    o=set(cites).intersection(ref)
                    if o:# alos cite prior
                        F[idx][y][2].append(p)
                    else:# only cite focal paper
                        F[idx][y][1].append(p)
                else:
                    o=set(cites).intersection(ref)
                    if o:# only cite prior
                        #F[y][3]+=1
                        for j in o:
                            Roots[idx][j]+=1


# In[10]:

Roots[bak]


# In[36]:

from pandas import DataFrame
from pandas import ExcelWriter
def save_xls(sheetnames,list_dfs, xls_path):
    writer = ExcelWriter(xls_path)
    for n, df in zip(sheetnames,list_dfs):
        df.to_excel(writer,n)
    writer.save()


# In[34]:

DD={}
for idx in selected:
    Roots_=Roots[idx]
    F_=F[idx]
    roots=[[i,Y[i],Roots_[i]] for i in zip(*sorted([(Y[k],k) for k in Roots_]))[1]]
    yearParameters=[min([Y[i] for i in Roots_]),Y[idx],2014]
    citations=[]
    for y in sorted(F_.keys()):# sorted by year
        for t in [1,2]:
            if t in F_[y]:
                for i in F_[y][t]:
                    if i in W and W[i][-1]>0:
                        citations.append([y,t,W[i][-1]])
    #
    ri,ry,rc=zip(*roots)
    cy,ct,cc=zip(*citations)
    rootsdf = DataFrame({'roots_id': ri, 'roots_year': ry,'roots_citations': rc})
    citationsdf = DataFrame({'pubYear': cy, 'type': ct,'citations': cc})
    yearParametersdf=DataFrame({'fromYear_pubYear_toYear': yearParameters})
    DD[str(idx)+'_roots']=rootsdf
    DD[str(idx)+'_citationsdf']=citationsdf
    DD[str(idx)+'_yearParametersdf']=yearParametersdf


# In[37]:

xls_path='/Users/lingfeiw/Dropbox/teams/2 submit nature/0 final/Figure1/Figure1.xlsx'
save_xls(DD.keys(),         DD.values(), xls_path)


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:

'''
NW
#Brian Uzzi  'UZZI, B'
#Luis Amaral   amaral@northwestern.edu   'AMARAL, LAN'
Ben Jones, Economics   bjones@kellogg.northwestern.edu 'JONES, B+76' 'JONES, BF+8'

UChicago:
Stefano Allesina, Ecology   sallesina@uchicago.edu 'ALLESINA, S+0'
Andrey Rzhetsky, Computational Biology   arzhetsky@uchicago.edu arzhetsk@medicine.bsd.uchicago.edu 'RZHETSKY, A+4'
#Stephane Bonhomme, Economics    sbonhomme@uchicago.edu  no paper
Luis Bettencourt, Physics lmbettencourt@gmail.com lmbett@lanl.gov   
Rina Foygel, Statistics  rina.foygel@gmail.com rina@uchicago.edu rina.barber@gmail.com
Ron Burt, Sociology ron.burt@chicagobooth.edu


S=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#141
        name,uni,email=line.strip().split('\t')
        es=email.split('__')
        us=uni.split('__')
        e=es[0].split('_')[0]
        if 'ron.burt@chicagobooth.edu' in e:
            S.add(name)
            
Z={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        i=line[0]
        if i.split('+')[0]=='BURT, RS':
            Z[i]=map(int,line[1:])
'''


# In[47]:

data={'burt':[40340439,10249929,40533042],
'brian':[32106786,32519299,38552454,33589482,41994155,41885506,29476625,38656786,
  37711448,32282297,34125723,34499508, 38540645, 34029685,36857043, 36931486,19048072,
        27146810,40945819],
'jones':[32106786,32519299,34125723,38663894,41468497,41885506,41994155],
'amaral':[40542135,41992961,20711937,24706565,24706566,24706567,23403017,20711949,20711950,20731925,
 32412906,28593690,36896773,32280101,33477236,19552307,25551925,29503497,25551935,25551936,
 29642819,25551941,28620872,23731787,25390668,30034159,32282297,20255832,31509299,
 18314853,24412261,29476625,21704298,40950380,
 36907117,29543540,26981310,34545271,21434489,23559802,25299903,29246076,23559808,24208514,18509957,34498183,
 29280911,22989461,23750813,19587231,26290337,27786919,33907883,40711341,32724207,41094321,18867385,
 21500093,19790531,23679687,28071628,34127565,25209552,34148573,
 32644833,26221794,24607975,37194978,22674154,23464914,23758063,
 28156144,27334392,28257805,26066687,34545280,28156173,29668622,
 28156143,26001169,27898807,31519637,23353113,26283292,25970978,32476303,25970992,31449907,28350772,41230645,24921911,22116665,
 39058759,27124556,23362381,38861138,25753940,24330581,36713815,23212379,17856349,43081288,20836707,
 32528228,36524389,35649896,22325616,26264956,23431914,26570622,37845141,33156997,38280072,25457557,25728239,
 25301406,24332707,22610341,29565862,20744615,35379628,43501487,25581489,24506290,36511668,40260535,38243260,
 22531518,23488959,28870082,30452164,43491272,33940556,22410189,32107982,21265362,21265363,20204506,19868640,25985509,
 38421479,40417257,36555765,26749943,34787832,26043898,41732540,28625986],
'stephano':[41533057,38274178,39245827,37811844,35816967,40185097,28512266,30596418,32304143,
 42153233,36871700,36692846,35049967,37889439,33242018,40535317,33501096,39279111,28790572,
 43265847,43482247,27411645,35512130,31331274,39723725,40045518,31264463,35060692,27898062,
 38071382,39789275,38749788,40341341,40725477,35049959,31042152,38273513,37580782,42964079,
 35345807,30102014,35049961,29662840,30118868,33471354,39434110,41129749],
'andrey':[32481281,41743492,30605445,32304775,34594184,31456137,39362955,37142669,38167956,28077210,
 33090077,31576223,38513264,30978468,38378152,33258269,27645491,25635380,31125431,42625723,
 28371392,25552608,34891724,26583629,33184847,32040409,37277408,24739939,36796144,33631351,
 35567738,29957886,32481281,41743492,30605445,32304775,34594184,31456137,39362955,37142669,
 38167956,28077210,33090077,31576223,38513264,30978468,38378152,33258269,27645491,25635380,
 31125431,42625723,28371392,25552608,34891724,26583629,33184847,32040409,37277408,24739939,
 36796144,33631351,35567738,29957886],
'bettencourt':[43361632,38325735,43023559,42519189,41872319,39076709,
            33478025,25513359,33564818,24742423,23718182,37071528,43639213,32015156,23209399,
 33245236,22674106,33593661,33548228,31752389,28068038,38765131,31788492,22109262,28068048,
 34562773,39796185,40950366,25341281,24542052,41361385,26066673,30778610,26264948,38513269,
 21102953,27314425,34769151],
'rina':[37793362,39667402,42441563,43355393]}


# In[3]:

c=set.union(*map(set,data.values()))
len(c)


# In[4]:

C={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in c:
            C[p]=line[1:]


# In[138]:

len(Y)


# In[ ]:




# In[16]:

W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        W[int(Id)]=[int(journal),int(subject),float(disruptive),int(year),int(teamsize),int(impact)]


# In[5]:

len(C)


# In[10]:

n=0
Title={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        t=line[1]
        Title[p]=t.lower()


# In[66]:

data.keys()


# In[88]:

S={}
for name in data:
    s=set([j for i in data[name]  if i in C for j in C[i] ])
    r=sorted([(W[j][2],W[j][-1],W[j][3],j) for j in s if j in W and W[j][-1]>10])
    r=r[:10]+r[-10:]
    #r[::-1]
    S[name]=zip(*r[::-1])[-1]


# In[96]:

selected=set.union(*map(set,S.values()))
len(selected)


# # citation data to select ref

# In[ ]:




# In[2]:

selected=set([22399745,23638776])


# In[8]:

len(R),len(selected)


# In[7]:

F=defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:[])))
Roots=defaultdict(lambda:defaultdict(int))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        cites=set(line[1:])
        p=line[0]
        y=Y[p]
        for idx in selected:
            pubYear=Y[idx]
            ref=R[idx]
            if y>pubYear:
                if idx in cites: #cite focal paper
                    o=set(cites).intersection(ref)
                    if o:# alos cite prior
                        F[idx][y][2].append(p)
                    else:# only cite focal paper
                        F[idx][y][1].append(p)
                else:
                    o=set(cites).intersection(ref)
                    if o:# only cite prior
                        #F[y][3]+=1
                        for j in o:
                            Roots[idx][j]+=1


# In[8]:

len(F),len(Roots)


# In[10]:

import os
import errno


name='test'
for idx in selected:
    Roots_=Roots[idx]
    F_=F[idx]
    #export Roots
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/treeAuto/'+name+'/'+str(idx)+'/roots.txt'
    if not os.path.exists(os.path.dirname(filename)):
        try:
            os.makedirs(os.path.dirname(filename))
        except OSError as exc: # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise
    with open(filename, "w") as f:
        for i in zip(*sorted([(Y[k],k) for k in Roots_]))[1]:# sorted by year
            f.write(str(i)+','+str(Y[i])+','+str(Roots_[i])+'\n')
    #export Year Parameters        
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/treeAuto/'+name+'/'+str(idx)+'/yearParameters.txt'
    with open(filename, "w") as f:
        f.write(str(min([Y[i] for i in Roots_]))+','+str(Y[idx])+','+str(2014)+'\n')
    # export leaves
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/treeAuto/'+name+'/'+str(idx)+'/citations.txt'
    with open(filename, "w") as f:
        for y in sorted(F_.keys()):# sorted by year
            for t in [1,2]:
                if t in F_[y]:
                    for i in F_[y][t]:
                        if i in W and W[i][-1]>0:
                            f.write(str(y)+','+str(t)+','+str(W[i][-1])+'\n')    


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:

#export Roots
with open('/Users/lingfeiw/Documents/research/teamscience/team/treeAuto/'+str(idx)+'/roots.txt','wb') as f:
    for i in zip(*sorted([(Y[k],k) for k in Roots]))[1]:# sorted by year
        f.write(str(i)+','+str(Y[i])+','+str(Roots[i])+'\n')
#export Year Parameters
with open('/Users/lingfeiw/Documents/research/teamscience/team/treeAuto/'+str(idx)+'/yearParameters.txt','wb') as f:
    f.write(str(min([Y[i] for i in Roots]))+','+str(pubYear)+','+str(2014)+'\n')
# export leaves
with open('/Users/lingfeiw/Documents/research/teamscience/team/treeAuto/'+str(idx)+'/citations.txt','wb') as f:
    for y in sorted(F.keys()):# sorted by year
        for t in [1,2]:
            for i in F[y][t]:
                if i in W and W[i][-1]>0:
                    f.write(str(y)+','+str(t)+','+str(W[i][-1])+'\n')


# In[ ]:




# # Brian

# In[139]:

s=set([j for i in brian for j in C[i] ])
sorted([(W[j][2],Title[j],W[j][-1],W[j][3]) for j in s if j in W and W[j][-1]>100])[-10:]


# In[27]:

sorted([(W[j][2],Title[j],W[j][-1],W[j][3]) for j in s if j in W and W[j][-1]>100])[:10]


# In[146]:

[Title[i] for i in ids]


# In[152]:

[[Title[i],i,float(str(np.round(W[i][2],2))),W[i][-1]] for i in ids]


# In[ ]:




# # Jones

# In[41]:

s=set([j for i in jones if i in C for j in C[i] ])
sorted([(W[j][2],Title[j],W[j][-1],W[j][3]) for j in s if j in W and W[j][-1]>10])[-10:]


# In[44]:

s=set([j for i in jones if i in C for j in C[i] ])
sorted([(W[j][2],Title[j],W[j][-1],W[j][3]) for j in s if j in W and W[j][-1]>10])[:10]


# # Amaral

# In[45]:

s=set([j for i in amaral if i in C for j in C[i] ])
sorted([(W[j][2],Title[j],W[j][-1],W[j][3]) for j in s if j in W and W[j][-1]>10])[-10:]


# In[46]:

s=set([j for i in amaral if i in C for j in C[i] ])
sorted([(W[j][2],Title[j],W[j][-1],W[j][3]) for j in s if j in W and W[j][-1]>10])[:10]


# In[ ]:



