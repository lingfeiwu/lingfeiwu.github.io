
# coding: utf-8

# In[21]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,11):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b


# In[ ]:




# # The percentage of reciprocated citations

# In[2]:

#1.year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[2]:

#aggregate data by team size
W=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            W.add(int(Id))


# In[5]:

#
R={}
n=0
m=0
k=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p = line[0]
        if p in W:
            k+=1
            yp=Y[p]
            refs=line[1:]
            l=[i for i in refs if i in Y and Y[i]>yp]
            if l:
                m+=1


# In[9]:

n,m,k,len(W)


# In[8]:

100*30744/24174022.0


# # althernative measures for disruption 

# In[46]:

len(W)


# In[39]:

S=set(random.sample(W,100000))


# In[55]:

#
I={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            I[int(Id)]=int(impact)


# In[65]:

T={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            T[int(Id)]=int(teamsize)


# In[58]:

R1={}
for i in R0:
    refs=R0[i]
    refs=[j for j in refs if j in I and I[j]>=24]#top 25% impact in population
    R1[i]=refs #refs may be empty


# In[53]:

# refs of 100,000 focal papers
R0={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p = line[0]
        refs=line[1:]
        if p in S:
            R0[p]=refs
#finding focal paper by ref id, one ref id may link to many focal papers
K=defaultdict(lambda:set([]))
for i in R0:
    refs=R0[i]
    for j in refs:
        K[j].add(i)
K=dict(K)
# unique set of all focal papers and their refs
Z=set([])
for i in R0:
    Z.add(i)
    for j in R0[i]:
        Z.add(j)


# In[59]:

len(R0),len(R1),len(K),len(Z)


# In[63]:

#
D0=defaultdict(lambda:[0,0,0])# n_dis,n_dev,n_ref
D4=defaultdict(lambda:[0,0,0])# n_dis,n_dev,n_ref, only keep popular refs
D5=defaultdict(lambda:[0,0,0])# w_dis,w_dev,w_ref
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        i = line[0]
        refs=line[1:]
        F=set(refs).intersection(S)
        if F: # i cite focal paper f 
            for f in F:
                r0=R0[f]
                r1=R1[f]
                v0=set(refs).intersection(r0)
                v1=set(refs).intersection(r1)
                if v0: # i also cite the refs of focal paper f
                    D0[f][1]+=1 # i contribute to n_dev of f in papers 
                    D5[f][1]+=len(v0)+1 # i contribute to w_dev of f in links
                else:  # i only cite focal paper f but not its refs
                    D0[f][0]+=1 # i contribute to n_dis of f in papers 
                    D5[f][0]+=1 # i contribute to w_dis of f in links
                if v1:
                    D4[f][1]+=1
                else:
                    D4[f][0]+=1
        else: # i does not cite any focal paper
            U=set(refs).intersection(Z) 
            if U:#i cite refs of focal paper but not focal paper
                F=set.union(*[K[j] for j in U])#get focal papers
                for f in F:
                    D0[f][2]+=1 # i contribute to n_ref of f in papers 
                    r0=R0[f]
                    r1=R1[f]
                    v0=set(refs).intersection(r0)
                    v1=set(refs).intersection(r1)
                    D5[f][2]+=len(v0)  # i contribute to w_ref of f in links
                    if v1:
                        D4[f][2]+=1


# In[190]:

#write
'''
f = open('/Users/lingfeiw/Documents/research/teamscience/team/natureRevData/DisAlternative.txt', "wb")
for i in D0:
    if i in D4 and i in D5:
        n1,n2,n3=D0[i]
        imp=I[i]
        m=T[i]
        if imp>=1 and n1+n2==imp and 1<=m<=10 and n3>0:
            n1_,n2_,n3_=D4[i]
            w1,w2,w3=D5[i]
            f.write(str(i)+'\t'+'\t'.join(map(str,[m,n1,n2,n3,n1_,n2_,n3_,w1,w2,w3])) + '\n')
#'''


# In[347]:

len(DS)


# In[2]:

DS={}
path="/Users/lingfeiw/Documents/research/teamscience/team/natureRevData/DisAlternative.txt"
with open(path, "r") as f:
    for line in f:
        line=line.strip().split('\t')
        if line[0].isdigit():
            idx=int(line[0])
            m,n1,n2,n3,n1_,n2_,n3_,w1,w2,w3=map(float,line[1:])
            d0=(n1-n2)/(n1+n2+n3+0.0)
            d3=(n1_-n2_)/(n1_+n2_+n3_+0.0)
            d1=n1/(n1+n2+0.0)
            d2=w1/(w1+w2+0.0)
            DS[idx]=[m,d0,d1,d2,d3]


# In[ ]:

# add self-ciation data


# In[5]:

S=set(DS.keys())


# In[47]:

# refs of 100,000 focal papers_including self cites
R0={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p = line[0]
        refs=line[1:]
        if p in S:
            R0[p]=refs
#finding focal paper by ref id, one ref id may link to many focal papers
K=defaultdict(lambda:set([]))
for i in R0:
    refs=R0[i]
    for j in refs:
        K[j].add(i)
K=dict(K)
# unique set of all focal papers and their refs
Z=set([])
for i in R0:
    Z.add(i)
    for j in R0[i]:
        Z.add(j)


# In[48]:

#
D6=defaultdict(lambda:[0,0,0])# n_dis,n_dev,n_ref, remove self-citation
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        i = line[0]
        refs=line[1:]
        F=set(refs).intersection(S)
        if F: # i cite focal paper f 
            for f in F:
                r0=R0[f]
                v0=set(refs).intersection(r0)
                if v0: # i also cite the refs of focal paper f
                    D6[f][1]+=1 # i contribute to n_dev of f in papers 
                else:  # i only cite focal paper f but not its refs
                    D6[f][0]+=1 # i contribute to n_dis of f in papers 
        else: # i does not cite any focal paper
            U=set(refs).intersection(Z) 
            if U:#i cite refs of focal paper but not focal paper
                F=set.union(*[K[j] for j in U])#get focal papers
                for f in F:
                    D6[f][2]+=1 # i contribute to n_ref of f in papers 


# In[50]:

'''
with open('/Users/lingfeiw/Documents/research/teamscience/team/natureRevData/DisAlternativeCompre2.txt', "wb") as f:
    with open("/Users/lingfeiw/Documents/research/teamscience/team/natureRevData/DisAlternative.txt", "r") as f1:
        for line in f1:
            line=line.strip().split('\t')
            if line[0].isdigit():
                idx=int(line[0])
                m,n1,n2,n3,n1_,n2_,n3_,w1,w2,w3=map(int,line[1:])
                nn1,nn2,nn3=D6[idx]
                f.write(str(idx)+'\t'+'\t'.join(map(str,[m,n1,n2,n3,nn1,nn2,nn3,n1_,n2_,n3_,w1,w2,w3])) + '\n')
'''


# In[ ]:




# In[78]:

DS1={}
path="/Users/lingfeiw/Documents/research/teamscience/team/natureRevData/DisAlternativeCompre2.txt"
with open(path, "r") as f:
    for line in f:
        line=line.strip().split('\t')
        if line[0].isdigit():
            idx=int(line[0])
            m,n1,n2,n3,nn1,nn2,nn3,n1_,n2_,n3_,w1,w2,w3=map(float,line[1:])
            #if nn1+nn2+nn3>0:
            d0=(n1-n2)/(n1+n2+n3+0.0)
            d1=(nn1-nn2)/(nn1+nn2+nn3+0.0)
            d2=(n1_-n2_)/(n1_+n2_+n3_+0.0)
            d3=n1/(n1+n2+0.0)
            d4=w1/(w1+w2+0.0)
            DS1[idx]=[m,d0,d1,d2,d3,d4]


# In[79]:

t0=defaultdict(lambda:[])
t1=defaultdict(lambda:[])
t2=defaultdict(lambda:[])
t3=defaultdict(lambda:[])
t4=defaultdict(lambda:[])
for i in DS1:
        m,d0,d1,d2,d3,d4=DS1[i]
        t0[m].append(d0)
        t1[m].append(d1)
        t2[m].append(d2)
        t3[m].append(d3)
        t4[m].append(d4)
x0,y0=np.array([(k,np.mean(v)) for k,v in t0.items()]).T
x1,y1=np.array([(k,np.mean(v)) for k,v in t1.items()]).T
x2,y2=np.array([(k,np.mean(v)) for k,v in t2.items()]).T
x3,y3=np.array([(k,np.mean(v)) for k,v in t3.items()]).T
x4,y4=np.array([(k,np.mean(v)) for k,v in t4.items()]).T


# In[ ]:




# In[97]:

fig = plt.figure(figsize=(5,6),facecolor='white')
#cmap = cm.get_cmap('rainbow',4)
#
ax = fig.add_subplot(111)
ax.plot(x0,y0,color='gray',linestyle='--',linewidth=1.5,label=r'$D_0$')
ax.plot(x1,y1,color='gray',marker='',linewidth=1.5,label=r'$D_1$')
ax.plot(x2,y2,color='ForestGreen',marker='o',linewidth=1.5,label=r'$D_2$')
ax.plot(x3,y3,color='Chocolate',marker='^',linewidth=1.5,label=r'$D_3$')
ax.plot(x4,y4,color='RoyalBlue',marker='s',linewidth=1.5,label=r'$D_4$')
ax.plot(x0,y0,color='white',linewidth=2)
ax.plot(x1,y1,color='white',linewidth=2)
plt.xticks(np.arange(2, 10+1, 2))
ax.tick_params(axis='both', which='major', labelsize=14)
ax.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlabel('Team size',fontsize=20)
#plt.ylabel('Alternative Disruption',fontsize=20)
plt.ylim(0,0.5)
#
ax2 = ax.twinx()
ax2.plot(x0,y0,color='gray',linestyle='--',linewidth=1.5,label=r'$D_0$')
ax2.plot(x1,y1,color='gray',marker='',linewidth=1.5,label=r'$D_1$')
#plt.ylabel('Disruption',fontsize=20,color='gray')
plt.title('Alternative Disruption',size=16)
plt.ylim(-0.005,0.015)
ax2.tick_params(axis='both', which='major', labelsize=12)
ax2.tick_params(axis='y', colors='gray')

#

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_Alt.pdf')


# # 1. Show the variance of disruption across team sizes 

# In[2]:

#aggregate data by team size
dP=defaultdict(lambda:[])
cP=defaultdict(lambda:[])# 288
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=10 and int(impact)>0 and int(year)>=1954:
            dP[int(teamsize)].append(float(disruptive))
            cP[int(teamsize)].append(int(impact))


# In[3]:

Dp={}
Dp1={}
for m in dP:
    flushPrint(m)
    ds=dP[m]
    x,y= np.array(sorted(Counter([np.round(i,4) for i in ds if -0.05<i<0.05]).items())).T
    x1,y1= np.array(sorted(Counter([np.round(i,3) for i in ds]).items())).T
    y=y/float(y.sum())
    y1=y1/float(y1.sum())
    Dp[m]=[x,y]
    Dp1[m]=[x1,y1]


# In[5]:

fig = plt.figure(figsize=(10, 5),facecolor='white')
cmap = cm.get_cmap('rainbow_r',11)
#
#
#
ax = fig.add_subplot(121)
for m in [1,3,9]:
    x1,y1=Dp1[m] 
    plt.plot(x1,y1,color=cmap(m),marker='.',markersize=2,linestyle='',label='team size = '+str(m))
plt.yscale('log')
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Disruption '+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
ax.legend(loc=2,fontsize=10,numpoints=1,frameon=False,ncol=1,markerscale=4)
#
ax = fig.add_subplot(122)
for m in [1,3,9]:
    x,y=Dp[m]
    mm=np.mean(dP[m])
    md=np.std(dP[m])
    a,b=(mm-md/2,mm+md/2)
    plt.plot(x,y,color=cmap(m),marker='.',markersize=2,linestyle='')
    plt.plot([mm,mm],[1*10**-5,0.1],linewidth=2,linestyle='--',color=cmap(m))
    plt.axvspan(a, b, facecolor=cmap(m),edgecolor=None, alpha=0.3)
plt.yscale('log')
plt.xlim(-0.005,0.005)
plt.xticks([-0.05,-0.025,0,0.025,0.05],['-0.05','-0.025','0','0.025','0.05'],rotation=0)
plt.ylim(1*10**-5,0.1)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Disruption '+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_variance.pdf')


# In[86]:

fig = plt.figure(figsize=(6, 4),facecolor='white')
cmap = cm.get_cmap('rainbow_r',11)
ax = fig.add_subplot(111)
for m in [1,3,9]:
    x,y=Dp[m]
    mm=np.mean(dP[m])
    md=np.std(dP[m])
    a,b=(mm-md/2,mm+md/2)
    plt.plot(x,y,color=cmap(m),marker='.',markersize=2,linestyle='',label='team size = '+str(m))
    plt.plot([mm,mm],[1*10**-5,0.1],linewidth=2,linestyle='--',color=cmap(m))
    plt.axvspan(a, b, facecolor=cmap(m),edgecolor=None, alpha=0.3)
plt.yscale('log')
plt.xlim(-0.005,0.005)
plt.xticks([-0.05,-0.025,0,0.025,0.05],['-0.05','-0.025','0','0.025','0.05'],rotation=0)
plt.ylim(1*10**-5,0.1)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Disruption '+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
ax.legend(loc=1,fontsize=10,numpoints=1,frameon=False,ncol=1,markerscale=4)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_variance_zoomin.pdf')


# In[10]:

for m in range(1,11):
    v=dP[m]
    i,j=(np.percentile(v,25),np.percentile(v,75))
    mv=np.mean(v)
    dv=np.std(v)
    a,b=(mv-dv/2,mv+dv/2)
    print (m,a,b,len(v),dv,dv/len(v),i,j)


# # The association between disruption and team size is invariant of  

# ### The impact of references 

# In[13]:

Wmp={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperImpactMedian.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,medianImp=line.strip().split('\t')
        Wmp[int(paper)]=float(medianImp)


# In[14]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(teamsize),float(disruptive)]


# In[19]:

DisImpact=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in Wmp:
        year,teamsize,disruptive=W1[i]
        j=Wmp[i]
    if 1<=teamsize<=10 and impact>0:
        if j<14:#<10
            ilevel=1
        if 14<=j<49.5:#10-50
            ilevel=2   
        if 49.5<=j<87:#50-75
            ilevel=3
        if 87<=j<148:#75-90
            ilevel=4
        if 148<=j<212:#90-95
            ilevel=5
        if j>=212:#>95
            ilevel=6
        DisImpact[ilevel][teamsize].append(disruptive)


# In[20]:

drss=random.sample([v[-1] for v in W1.values()],100000)
stats.percentileofscore(drss, 0)


# In[21]:

disImpact={}
disImpact1={}
for ilevel in [1,2,3,4,5,6]:
    disImpact[ilevel]=zip(*sorted([(k,stats.percentileofscore(drss, np.mean(v)))                                   for k,v in DisImpact[ilevel].items()]))
    disImpact1[ilevel]=zip(*sorted([(k,np.mean(v)) for k,v in DisImpact[ilevel].items()]))


# In[46]:

fig = plt.figure(figsize=(6,5),facecolor='white')
cmap1 = cm.get_cmap('summer_r',7)
ax = fig.add_subplot(111)
ip={1:'0-10',2:'10-50',3:'50-75',4:'75-90',5:'90-95',6:'95-100'}
for ilevel in [1,2,3,4,5,6]:
    x,y=disImpact[ilevel]
    plt.plot(x,y,color=cmap1(ilevel),linewidth=2,alpha=1,label='Ref. Pop. %tile  '+ip[ilevel])
ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)

ax.legend(loc="lower right", bbox_to_anchor=(0.9,0.4),frameon=False,fontsize=12)
ax.set_xlabel('Team size',fontsize=14)
ax.set_ylabel('Disruption Percentile',fontsize=14)
#
ax.tick_params(axis='both', which='major', labelsize=14)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.xlabel('Team size',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/ControlRefMedianImpact.pdf')


# ### Althernative measures for disruption 

# In[322]:

SA={}
n=0
m=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        if len(line)>=101:
            SA[line[0]]=map(int,line[1:])
            m+=1
            if m>10000:
                break


# In[250]:

len(SA)


# In[255]:

v=SA['TAKAUE, Y+0']


# In[257]:

T[25239040]


# In[258]:

D={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            D[int(Id)]=float(disruptive)


# In[340]:

dss=random.sample(D.values(),10000)


# In[341]:

stats.percentileofscore(dss,0)


# In[313]:

C


# In[343]:

beta=[]
for n in range(10000):
    data=SA.values()[n]
    C=defaultdict(lambda:[])
    for i in data:
        if i in T and i in D:
            m=T[i]
            d=D[i]
            if 1<=m<=3:
                C[0].append(d)
            if m>3:
                C[1].append(d)
    if C and len(C.keys())==2:
        x,y=np.array(sorted([(k,np.mean(v)) for k,v in C.items()])).T
        y[0]=stats.percentileofscore(dss,y[0])
        y[1]=stats.percentileofscore(dss,y[1])
        plt.plot(x,y,'b-',alpha=0.1)
        beta.append(y[1]-y[0])
plt.xlim(-0.1,1.1)
plt.plot([0,1],[70,70],'r-')


# In[344]:

len([i for i in beta if i<0])


# In[327]:

len([i for i in beta if i<0])


# In[345]:

plt.hist(beta,500)
#plt.xlim(-0.02,0.02)
#plt.plot([-0.00103,-0.00103],[0,2500],'r-')
#plt.plot([-0.0005,-0.0005],[0,2500],'g-')
plt.show()


# In[346]:

np.mean(beta),np.median(beta)


# In[336]:

plt.hist(beta,500)
plt.xlim(-0.02,0.02)
plt.plot([-0.00103,-0.00103],[0,2500],'r-')
plt.plot([-0.0005,-0.0005],[0,2500],'g-')
plt.show()


# In[335]:

np.mean(beta),np.median(beta)


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[4]:

JS={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        idx,j,_=line.strip().split('\t')
        JS[int(idx)]=j.lower()
J={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperJournal.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        idx,j=map(int,line.strip().split('\t'))
        if j in JS:
            J[idx]=JS[j]


# In[161]:

# papers
W=defaultdict(lambda:defaultdict())
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            #W[int(Id)]=[int(teamsize),float(disruptive)]
            if 200<=int(impact)<999 and 1980<=int(year)<=1985 and int(Id) in J:
                #if float(disruptive)>0.1 or float(disruptive)<-0.1 :
                W[int(subject)][int(Id)]=[float(disruptive),int(impact),int(teamsize),int(year),J[int(Id)]]


# In[256]:

# papers
P=defaultdict(lambda:defaultdict())
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            #W[int(Id)]=[int(teamsize),float(disruptive)]
            if int(impact)>999 and int(Id) in J:
                #if float(disruptive)>0.1 or float(disruptive)<-0.1 :
                P[int(subject)][int(Id)]=[float(disruptive),int(impact),int(teamsize),int(year),J[int(Id)]]


# In[ ]:




# In[ ]:




# In[233]:

W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            #W[int(Id)]=[int(teamsize),float(disruptive)]
            #if 200<=int(impact)<999 and 1980<=int(year)<=1985 and int(Id) in J:
                #if float(disruptive)>0.1 or float(disruptive)<-0.1 :
            W1[int(Id)]=[float(disruptive),int(impact),int(teamsize),int(year)]


# In[8]:

# papers
Title={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=int(line[0])
        Title[p]=line[1]


# In[ ]:

#i=13869522
#i=19977309
#i=23644437


# In[45]:

len(J)


# In[143]:

Title[i]


# # 1:'Biology',

# In[294]:

np.percentile([v[1] for v in P[1].values()],99)


# In[165]:

i=1
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[3]


# In[167]:

sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[4]


# In[176]:

sorted([[np.abs(v[0]),v[1],v[2],v[3],v[4],Title[k].lower()] for k,v in W[i].items() if v[1]>500])[:5]


# In[ ]:

###


# In[297]:

i=1
sorted([v+[Title[k].lower(),k] for k,v in P[i].items() if v[1]>12461],reverse=True)[2]


# In[301]:

i=1
sorted([v+[Title[k].lower(),k] for k,v in P[i].items() if v[1]>12461])[0]


# In[304]:

sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower()] for k,v in P[i].items() if v[1]>12461])[3]


# In[245]:

dis=[v[0] for k,v in W[1].items()]
a=0.715801886792
b=-0.130337078652
c=6.2480196009300003e-05
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# In[305]:

dis=[v[0] for k,v in P[1].items()]
a=0.916179985452
b=-0.369826215668
c=0.042448781859
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# In[ ]:




# In[ ]:




# # 2:'Business and management',

# In[ ]:




# # 3:'Chemistry',

# In[182]:

i=3
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[5]


# In[183]:

i=3
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[4]


# In[188]:

i=3
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower()] for k,v in W[i].items()])[10]


# In[246]:

i=3
dis=[v[0] for k,v in W[i].items()]
a=0.749116607774
b=-0.148936170213
c=8.59364929317e-05
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# In[306]:

np.percentile([v[1] for v in P[3].values()],99)


# In[312]:

i=3
sorted([v+[Title[k].lower(),k] for k,v in P[i].items() if v[1]>8019],reverse=True)[:5]


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# # 4:'Computer and information technology',

# In[189]:

i=4
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[3]


# In[190]:

i=4
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[0]


# In[196]:

i=4
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower(),k] for k,v in W[i].items()])[2]


# In[247]:

i=4
dis=[v[0] for k,v in W[i].items()]
a=0.686585365854
b=-0.162112932605
c=0.00115673799884
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# # 5:'Engineering',

# In[197]:

i=5
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[7]


# In[198]:

i=5
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[0]


# In[202]:

i=5
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower(),k] for k,v in W[i].items()])[1]


# In[248]:

i=5
dis=[v[0] for k,v in W[i].items()]
a=0.774847870183
b=-0.272727272727
c=0.000239520958084
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# In[ ]:




# # 6:'Environmental and earth sciences',

# In[204]:

i=6
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[5]


# In[93]:

i=6
sorted([v+[Title[k].lower()] for k,v in W[i].items()])[7]


# In[207]:

i=6
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower()] for k,v in W[i].items()])[3]


# In[249]:

i=6
dis=[v[0] for k,v in W[i].items()]
a=0.788617886179
b=-0.128904313337,
c=0.000277315585136
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# # 7:'Humanities',

# In[ ]:




# # 8:'Law',

# In[ ]:




# # 9:'Mathematics',

# In[208]:

i=9
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[0]


# In[209]:

i=9
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[4]


# In[211]:

sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower()] for k,v in W[i].items()])[1]


# In[250]:

i=9
dis=[v[0] for k,v in W[i].items()]
a=0.887096774194
b=-0.148506151142,
c=0.000115848007414
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# # 10:'Medicine',

# In[212]:

i=10
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[2]


# In[213]:

i=10
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[14]


# In[218]:

# i=10
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower(),k] for k,v in W[i].items()])[1]


# In[251]:

i=10
dis=[v[0] for k,v in W[i].items()]
a=0.938906752412
b=-0.155378486056,
c=0.0
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# # 11:'Multidisciplinary Sciences',

# In[219]:

i=11
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()],reverse=True)[7]


# In[220]:

i=11
sorted([v+[Title[k].lower(),k] for k,v in W[i].items()])[7]


# In[222]:

i=11
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower(),k] for k,v in W[i].items()])[4]


# In[252]:

i=11
dis=[v[0] for k,v in W[i].items()]
a=0.527407407407
b=-0.111764705882,
c=0.0
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# In[ ]:




# # 12:'Physical sciences',

# In[237]:

i=12
#i=13869522
#i=19977309
#i=23644437


# In[234]:

W1[13869522]


# In[235]:

W1[19977309]


# In[236]:

W1[23644437]


# In[ ]:




# In[ ]:




# # 13:'Social sciences'

# In[225]:

i=13
sorted([v+[Title[k].lower()] for k,v in W[i].items()],reverse=True)[0]


# In[227]:

i=13
sorted([v+[Title[k].lower()] for k,v in W[i].items()])[1]


# In[231]:

i=13
sorted([[np.abs(v[0]),v[0],v[1],v[2],v[3],v[4],Title[k].lower(),k] for k,v in W[i].items()])[0]


# In[253]:

i=13
dis=[v[0] for k,v in W[i].items()]
a=0.568134171908
b=-0.067664281067,
c=0.000155933260564
stats.percentileofscore(dis,a),stats.percentileofscore(dis,b),stats.percentileofscore(dis,c)


# In[ ]:



