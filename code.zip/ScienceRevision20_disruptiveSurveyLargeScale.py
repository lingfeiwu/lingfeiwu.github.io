
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
from openpyxl import load_workbook
from scipy import stats
import matplotlib.patches as patches

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# # Select active scholars in 2012, 2013, 2014 with diverse interests

# In[3]:

#year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[7]:

W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        #if int(teamsize) > 0 and int(impact)>0:
        W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[3]:

ids=[1736713,12058637,36896787,13828119,25690137,28704796,28082205,20818608,27869190,491562,2949166]


# In[12]:

zip(*sorted([(W[i][4],i) for i in ids],reverse=True))[0]


# In[17]:

zip(*sorted([(W[i][4],i,W[i][2]) for i in ids],reverse=True))[2]


# In[ ]:




# In[74]:

#  email to author name
E=defaultdict(lambda:[])
I={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#141
        name,uni,email=line.strip().split('\t')
        if email!='None':
            if len(email.split('__'))==1:
                e=email.split('__')[0].split('_')[0]# the main email
                if e:
                    E[e].append(name)
                    if uni!='None' and e not in I:
                        I[e]=uni.split('__')[0].split('_')[0]# the main institution
# author name to email
E_={}
for i in E:
    for j in E[i]:
        E_[j]=i


# In[77]:

len(E),len(E_),len(I)


# In[121]:

# active users in 2012,2013,2014 and increasiingly productive
U=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        name=line[0]
        if name in E_:
            e=E_[name]
            v=map(int,line[1:])
            ys=set([Y[j] for j in v if j in Y])
            if len(ys)>=3:
                if 2012 in ys and 2013 in ys and 2014 in ys:
                    U[e]+=[j for j in v if j in Y]

Z={}
for i in U:
    c=Counter([Y[j] for j in U[i]])
    if c[2012]<c[2013] and c[2013]<c[2014]:
        Z[i]=U[i]
        
len(U),len(Z)


# In[122]:

z=[i for i in Z if len(set([W[j][1] for j in Z[i] if j in W]))>=3]# target scholars
sz=set(z)
len(z)


# In[126]:

#find names
Names={}
for e in z:
    cc=Counter([i.split(',')[0].lower() for i in  E[e]])
    if len(cc)==1:
        Names[e]=cc.keys()[0].capitalize()
    else:
        a,b=cc.most_common(2)
        if a[1]>b[1]:
            Names[e]=a[0].capitalize()
# find institutions - chinese institutions are less reliable
Ins={}
for e in Names:
    if e in I:
        Ins[e]=I[e]
    else:
        Ins[e]='None'


# In[139]:

len(Names),len(Ins),len(Z),len(z)


# In[129]:

Names.items()[:10]


# In[ ]:

# add james and dashun


# In[136]:

Names['jevans@uchicago.edu']='Evans'
Names['dashunwang@gmail.com']='Wang'
Z['jevans@uchicago.edu']=[33702786,34484277,34589824,35145055,35319291,36243418,                          36632459,36892242,36970301,37571717,38167956,41864001,42706000]
Z['dashunwang@gmail.com']=[41864029]
len(Names)


# # Calculate local disruptons

# In[140]:

# the papers of target scholars
zp=set([j for i in Names for j in Z[i]]) 

# the reference of the papers of target scholars
P={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in zp:
            P[p]=line[1:]
            
# the reference of target scholars
R={}
for e in Names:
    r=set([k for j in Z[e] if j in P for k in P[j]])
    R[e]=r

    
# the reference of all reference of target scholars 
rr=set([k for e in R for k in R[e] ])
RR={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in rr:
            RR[p]=line[1:]


# In[342]:

len(zp),len(P),len(R),len(rr),len(RR)


# In[141]:

e


# In[146]:

# Global most diruptive is also local most diruptive  ?
L={}
n=0
for e in Names:
    n+=1
    if n%100==0:
        flushPrint(n/100)
    LD=defaultdict(lambda:[0,0,0])#n1,n2,n3
    for p in Z[e]:
        if p in P:
            p_ref=set(P[p])
            for j in R[e]:# j is the focal paper
                if j in RR:
                    j_ref=RR[j]
                    if j in p_ref:# p cite j
                        o=set(p_ref).intersection(j_ref)
                        if o:# p cite both j and the ref of j
                            LD[j][1]+=1
                        else:#p only cite j
                            LD[j][0]+=1
                    else:
                        o=set(p_ref).intersection(j_ref)
                        if o:#p only cite the ref of j
                            LD[j][2]+=1
    L[e]=LD


# In[277]:

data={}
for e in L:
    LD=L[e]
    LD=dict((k,(v[0]-v[1]+0.0)/sum(v)) for k,v in LD.items() if k in W and W[k][3]>=100)
    #LD=dict((k,(v[0]-v[1]+0.0)/sum(v)) for k,v in LD.items() if k in W and W[k][3]>=1000)
    sd=sorted([(LD[i],W[i][4],i) for i in LD if i in W],key=lambda x:(x[0],x[1]))
    if len(sd)>=2 and sd[0][1]<0 and sd[-1][1]>0:
        data[e]=[sd[0],sd[-1]]


# In[278]:

len(data)


# In[279]:

cite={}
for e in data:
    a,b=data[e]
    dev=a[2]
    dis=b[2]
    x=sorted([(W[i][-1],i) for i in Z[e] if i in W and dev in set(P[i])])
    y=sorted([(W[i][-1],i) for i in Z[e] if i in W and dis in set(P[i])])
    if x and y:
        citeDev=x[0][1]
        citeDis=y[0][1]
        cite[e]=[dev,citeDev,dis,citeDis]


# In[280]:

len(cite)


# In[227]:

n=0
Title={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        t=line[1]
        Title[p]=t.lower()


# In[303]:

Data={}
for e in cite:
    name=Names[e]
    email=e
    if e in I:
        institution=I[e]
    else:
        institution='None'
    FirstPaperYear=Y[sorted(Z[e])[0]]
    Npaper=len(Z[e])
    Nref=len(R[e])
    devPaper,devPaperFrom,disPaper,disPaperFrom=cite[e]
    dev=W[devPaper][4]
    devCite=W[devPaper][3]
    dis=W[disPaper][4]
    disCite=W[disPaper][3]
    devPaperImage='http://www.junminghuang.com/disruptive-research/'+str(devPaper)+'.png'
    disPaperImage='http://www.junminghuang.com/disruptive-research/'+str(disPaper)+'.png'
    DevPaper,DevPaperFrom,DisPaper,DisPaperFrom=[Title[i].capitalize() for i in cite[e]]
    PaperList='_'.join(map(str,sorted(Z[e])))
    Data[e]=[name,email,institution,FirstPaperYear,Npaper,Nref,             DisPaper,disPaper,dis,disCite,disPaperImage,DisPaperFrom,disPaperFrom,             DevPaper,devPaper,dev,devCite,devPaperImage,DevPaperFrom,devPaperFrom,PaperList]
len(Data)


# In[289]:

Data['jevans@uchicago.edu']


# In[284]:

Data['jevans@uchicago.edu']


# In[285]:

'''
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata.txt','w') as f:
    for e in Data:
        f.write('\t'.join(map(str,Data[e]))+'\n')  
'''


# In[8]:

Data=[]
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata.txt','r') as f:
    for line in f:
        line=line.strip().split('\t')
        #name,email,institution,FirstPaperYear,Npaper,Nref,\
        #DisPaper,disPaper,dis,disCite,disPaperImage,DisPaperFrom,disPaperFrom,\
        #DevPaper,devPaper,dev,devCite,devPaperImage,DevPaperFrom,devPaperFrom,PaperList=line
        line=[j.replace(","," ") for j in line]
        if "@" in line[1]:
            Data.append(line)
        if line[1]=='xgq-2001@163..com':
            line[1]='xgq-2001@163.com'
        if line[1]=='ocejl@univ.gda..pl':
            line[1]='ocejl@univ.gda.pl'
        if line[1]=='zsolt@nucleus.szbk.u.-szeged.hu':
            line[1]='zsolt@nucleus.szbk.u-szeged.hu'
len(Data)


# In[9]:

D2=[v for v in Data if v[1] in ['jevans@uchicago.edu','dashunwang@gmail.com']]
D20=random.sample(Data,20)
D200=random.sample(Data,200)


# In[10]:

rownames=['Name','Email','Institution','FirstPaperYear','Npaper','Nref','DisPaper','disPaper','dis','disCite','disPaperImage','DisPaperFrom','disPaperFrom','DevPaper','devPaper','dev','devCite','devPaperImage','DevPaperFrom','devPaperFrom','PaperList']


# In[11]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata2.csv','w') as f:
    f.write(','.join(rownames)+'\n')
    for v in D2:
        f.write(','.join(v)+'\n')
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata20.csv','w') as f:
    f.write(','.join(rownames)+'\n')
    for v in D20:
        f.write(','.join(v)+'\n') 
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata200.csv','w') as f:
    f.write(','.join(rownames)+'\n')
    for v in D200:
        f.write(','.join(v)+'\n') 
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata.csv','w') as f:
    f.write(','.join(rownames)+'\n')
    for v in Data:
        f.write(','.join(v)+'\n') 


# In[ ]:




# In[ ]:




# # prepare data for trees

# In[296]:

selected=set([])
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/surveyScholarAlldata.txt','r') as f:
    for line in f:
        line=line.strip().split('\t')
        name,email,institution,FirstPaperYear,Npaper,Nref,        DisPaper,disPaper,dis,disCite,disPaperImage,DisPaperFrom,disPaperFrom,        DevPaper,devPaper,dev,devCite,devPaperImage,DevPaperFrom,devPaperFrom,PaperList=line
        selected.add(int(disPaper))
        selected.add(int(devPaper))
len(selected)


# In[297]:

#get ref
R={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        ref=line[1:]
        p=line[0]
        if p in selected:
            R[p]=ref
R_=defaultdict(lambda:[])
for p in R:
    for j in R[p]:
        R_[j].append(p)
R_=dict(R_)
len(R_)
F=defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:[]))) # N of papers
Roots=defaultdict(lambda:defaultdict(int))# N of citations - a paper may cite multiple refs 
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        cites=set(line[1:])
        p=line[0]
        y=Y[p]
        t=[i for i in cites if i in selected]
        if t:
            for s in t:# cite selected paper s
                ref=R[s]
                o=cites.intersection(ref)
                if o:# cite selected paper s and its ref
                    F[s][y][2].append(p)
                else:# only selected paper s
                    F[s][y][1].append(p)
        else:
            t_=[i for i in cites if i in R_]
            if t_:# only cite the ref of s
                for r in t_: 
                    si=R_[r]
                    for s in si:
                        Roots[s][r]+=1


# In[ ]:




# In[ ]:




# In[302]:

import os
import errno


for idx in selected:
    Roots_=Roots[idx]
    F_=F[idx]
    #export Roots
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000trees/'+str(idx)+'/roots.txt'
    if not os.path.exists(os.path.dirname(filename)):
        try:
            os.makedirs(os.path.dirname(filename))
        except OSError as exc: # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise
    with open(filename, "w") as f:
        for i in zip(*sorted([(Y[k],k) for k in Roots_]))[1]:# sorted by year
            f.write(str(i)+','+str(Y[i])+','+str(Roots_[i])+'\n')
    #export Year Parameters        
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000trees/'+str(idx)+'/yearParameters.txt'
    with open(filename, "w") as f:
        f.write(str(min([Y[i] for i in Roots_]))+','+str(Y[idx])+','+str(2014)+'\n')
    # export leaves
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000trees/'+str(idx)+'/citations.txt'
    with open(filename, "w") as f:
        for y in sorted(F_.keys()):# sorted by year
            for t in [1,2]:
                if t in F_[y]:
                    for i in F_[y][t]:
                        if i in W and W[i][3]>0:
                            f.write(str(y)+','+str(t)+','+str(W[i][3])+'\n')
                            
filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000trees/ids.txt'
with open(filename, "w") as f:
    for i in selected:
        f.write(str(i)+'\n')


# In[ ]:




# # 10,000 ripples

# In[5]:

ids=[]
filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000trees/ids.txt'
with open(filename, "r") as f:
    for line in f:
        ids.append(int(line))


# In[12]:

a=[i for i in ids if i in W and W[i][4]>0]
b=[i for i in ids if i in W and W[i][4]<0]
c=[i for i in ids if i in W and W[i][4]==0]
len(a),len(b),len(c)


# In[14]:

filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000treesCover/idsDis.txt'
with open(filename, "w") as f:
    for i in a:
        f.write(str(i)+'\n')
filename = '/Users/lingfeiw/Documents/research/teamscience/team/9000treesCover/idsDev.txt'
with open(filename, "w") as f:
    for i in b:
        f.write(str(i)+'\n')


# In[160]:

F=defaultdict(lambda:[0,0])# N_total, N_dis
F1=defaultdict(lambda:[0,0])# N_total, N_dis
for i in W:
    y=W[i][0]
    if 1910<=y<1930:
        t=1
    if 1930<=y<1950:
        t=2
    if 1950<=y<1970:
        t=3
    if 1970<=y<1990:
        t=4
    if 1990<=y<2010:
        t=5
    dis=W[i][-2]
    F[t][0]+=1
    if dis>0:
        F[t][1]+=1
    if W[i][3]>=100:
        F1[t][0]+=1
        if dis>0:
            F1[t][1]+=1        


# In[161]:

R=dict([k,int(1000*v[1]/float(v[0]))] for k,v in F.items())
R1=dict([k,int(1000*v[1]/float(v[0]))] for k,v in F1.items())
R,R1


# In[142]:

plt.plot(R.values(),'bo-')
plt.plot(R1.values(),'go-')
#plt.ylim(0,1000)


# In[ ]:




# In[162]:

#sample 1,000 tree for each 20 years
Kdis=defaultdict(lambda:0)
Kdev=defaultdict(lambda:0)
K1=defaultdict(lambda:[])
for i in W:
    if W[i][3]>=30:
        y=W[i][0]
        if 1910<=y<1930:
            t=1
        if 1930<=y<1950:
            t=2
        if 1950<=y<1970:
            t=3
        if 1970<=y<1990:
            t=4
        if 1990<=y<2010:
            t=5   
        if len(K1[t])<1000:
            dis=W[i][-2]
            if dis>0:
                if Kdis[t]<R[t]:
                    K1[t].append(i)
                    Kdis[t]+=1
            if dis<0:
                if Kdev[t]<1000-R[t]:
                    K1[t].append(i)
                    Kdev[t]+=1
K1=dict(K1)


# In[163]:

selected=set([j for k in K1 for j in K1[k]])
len(selected)


# In[149]:

def decade(y):
    if 1910<=y<2010:
        if 1910<=y<1930:
            t=1
        if 1930<=y<1950:
            t=2
        if 1950<=y<1970:
            t=3
        if 1970<=y<1990:
            t=4
        if 1990<=y<2010:
            t=5
        return t
    else:
        pass


# In[165]:

[(k,len(v)) for k,v in K1.items()]


# In[166]:

[(t,len([i for i in K1[t] if W[i][-2]>0])/float(len(K1[t]))) for t in range(1,6)]


# In[126]:




# In[60]:

#year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[167]:

#get ref
R={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        ref=line[1:]
        p=line[0]
        if p in selected:
            R[p]=ref
R_=defaultdict(lambda:[])
for p in R:
    for j in R[p]:
        R_[j].append(p)
R_=dict(R_)
len(R_)
F=defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:[]))) # N of papers
Roots=defaultdict(lambda:defaultdict(int))# N of citations - a paper may cite multiple refs 
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        cites=set(line[1:])
        p=line[0]
        y=Y[p]
        t=[i for i in cites if i in selected]
        if t:
            for s in t:# cite selected paper s
                ref=R[s]
                o=cites.intersection(ref)
                if o:# cite selected paper s and its ref
                    F[s][y][2].append(p)
                else:# only selected paper s
                    F[s][y][1].append(p)
        else:
            t_=[i for i in cites if i in R_]
            if t_:# only cite the ref of s
                for r in t_: 
                    si=R_[r]
                    for s in si:
                        Roots[s][r]+=1


# In[169]:

import os
import errno

for idx in selected:
    if idx in Roots and Roots[idx]:
        Roots_=Roots[idx]
        F_=F[idx]
        #export Roots
        filename = '/Users/lingfeiw/Documents/research/teamscience/team/5000trees/'+str(idx)+'/roots.txt'
        if not os.path.exists(os.path.dirname(filename)):
            try:
                os.makedirs(os.path.dirname(filename))
            except OSError as exc: # Guard against race condition
                if exc.errno != errno.EEXIST:
                    raise
        with open(filename, "w") as f:
            for i in zip(*sorted([(Y[k],k) for k in Roots_]))[1]:# sorted by year
                f.write(str(i)+','+str(Y[i])+','+str(Roots_[i])+'\n')
        #export Year Parameters        
        filename = '/Users/lingfeiw/Documents/research/teamscience/team/5000trees/'+str(idx)+'/yearParameters.txt'
        with open(filename, "w") as f:
            f.write(str(min([Y[i] for i in Roots_]))+','+str(Y[idx])+','+str(2014)+'\n')
        # export leaves
        filename = '/Users/lingfeiw/Documents/research/teamscience/team/5000trees/'+str(idx)+'/citations.txt'
        with open(filename, "w") as f:
            for y in sorted(F_.keys()):# sorted by year
                for t in [1,2]:
                    if t in F_[y]:
                        for i in F_[y][t]:
                            if i in W and W[i][3]>0:
                                f.write(str(y)+','+str(t)+','+str(W[i][3])+'\n')
                            
filename = '/Users/lingfeiw/Documents/research/teamscience/team/5000trees/ids.txt'
with open(filename, "w") as f:
    for i in selected:
        f.write(str(i)+'\n')


# In[170]:

O=defaultdict(lambda:[])
for i in Roots:
    if i in F:
        y=W[i][0]
        t=decade(y)
        if t:
            O[t].append(i)
[(k,len(v)) for k,v in O.items()]


# In[171]:

for k in O:
    filename = '/Users/lingfeiw/Documents/research/teamscience/team/5000trees/ids'+str(k)+'.txt'
    with open(filename, "w") as f:
        for i in O[k]:
            f.write(str(i)+'\n')


# In[ ]:




# In[ ]:



