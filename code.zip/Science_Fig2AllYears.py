
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from scipy import stats
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

def log2linearBin(x,y):
    x=[np.round(i,0) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(np.round(np.exp2(i),0),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(sorted(newlist)).T
    return nx,ny

def log2linearBinInt(x,y):
    x=[int(i) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(int(np.exp2(i)),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(newlist).T
    return nx,ny

# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,11):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b


# # export figure 2 data

# In[21]:

from pandas import DataFrame
from pandas import ExcelWriter


# In[22]:

def save_xls(sheetnames,list_dfs, xls_path):
    writer = ExcelWriter(xls_path)
    for n, df in zip(sheetnames,list_dfs):
        df.to_excel(writer,n)
    writer.save()


# In[116]:

a_main = DataFrame({'Team size': xdisPaper[:10], 'Disruption percentile': ydisPaper[:10]                , 'Citations':yimpPaper[:10]})
#a_inset = DataFrame({'Team size': xdisPaperlog, 'Disruption percentile': ydisPaperlog\
#                , 'Citations':yimpPaperlog})
b_main = DataFrame({'Team size': xdisPatent[1:11], 'Disruption percentile': ydisPatent[1:11]                , 'Citations':yimpPatent[1:11]})
#b_inset = DataFrame({'Team size': xdisPatentlog[1:], 'Disruption percentile': ydisPatentlog[1:]\
#                , 'Citations':yimpPatentlog[1:]})
c_main = DataFrame({'Team size': xdisGithub[:10], 'Disruption percentile': ydisGithub[:10]                , 'Citations':yimpGithub[:10]})
#c_inset = DataFrame({'Team size': xdisGithublog[:8], 'Disruption percentile': ydisGithublog[:8]\
#                , 'Citations':yimpGithublog[:8]})
d = DataFrame({'Team size':tss,'Disruption ratio': r2_paper/ratio                , 'Citation ratio':r1_paper/ratio})
e = DataFrame({'Team size':tss,'Disruption ratio': r2_patent/ratio                , 'Citation ratio':r1_patent/ratio})
f = DataFrame({'Team size':tss,'Disruption ratio': r2_Github/ratio                , 'Citation ratio':r1_Github/ratio})

xls_path='/Users/lingfeiw/Dropbox/teams/3 submit nature/Figure2/Figure2.xlsx'
#save_xls(['a_main','a_inset','b_main','b_inset','c_main','c_inset','d','e','f'],\
#         [a_main,a_inset,b_main,b_inset,c_main,c_inset,d,e,f], xls_path)


# In[23]:

a_main = DataFrame({'Team size': xdisPaper10, 'Disruption percentile': ydisPaper10                , 'Citations':yimpPaper10})
b_main = DataFrame({'Team size': xdisPatent11, 'Disruption percentile': ydisPatent11                , 'Citations':yimpPatent11})
c_main = DataFrame({'Team size': xdisGithub10, 'Disruption percentile': ydisGithub10                , 'Citations':yimpGithub10})

d = DataFrame({'Team size':tss,'Disruption ratio': r2_paper_ratio                , 'Citation ratio':r1_paper_ratio})
e = DataFrame({'Team size':tss,'Disruption ratio': r2_patent_ratio                , 'Citation ratio':r1_patent_ratio})
f = DataFrame({'Team size':tss,'Disruption ratio': r2_Github_ratio                , 'Citation ratio':r1_Github_ratio})
xls_path='/Users/lingfeiw/Dropbox/teams/3 submit nature/Figure2/Figure2.xlsx'
save_xls(['a_main','b_main','c_main','d','e','f'],         [a_main,b_main,c_main,d,e,f], xls_path)


# In[13]:

xdisPaper10,ydisPaper10,yimpPaper10=zip(*[(1.0, 86.25, 22.083361008049692),
 (2.0, 80.810000000000002, 23.924599938413632),
 (3.0, 76.900000000000006, 22.582241413818906),
 (4.0, 57.699999999999996, 22.667640864065341),
 (5.0, 47.82, 23.153330799534363),
 (6.0, 43.039999999999999, 24.064975788077298),
 (7.0, 40.089999999999996, 25.522307452303192),
 (8.0, 38.82, 27.054649769799983),
 (9.0, 37.539999999999999, 28.710867931594958),
 (10.0, 36.82, 30.289609429941205)])


# In[14]:

xdisPatent11,ydisPatent11,yimpPatent11=zip(*[(1.0, 73.630887773634385, 7.9000373059871771),
 (2.0, 73.683814600281565, 8.8625339336185807),
 (3.0, 73.362492343073299, 9.469699848024316),
 (4.0, 73.430464359021215, 9.6510288286357309),
 (5.0, 71.945826571953617, 10.597313089946562),
 (6.0, 71.985588857962668, 11.345148063781322),
 (7.0, 71.928632069895642, 11.541831300463837),
 (8.0, 73.678709982483099, 12.54810676598386),
 (9.0, 68.22402286868774, 12.952896589063347),
 (10.0, 69.805648393926049, 15.339539007092199)])


# In[16]:

xdisGithub10,ydisGithub10,yimpGithub10=zip(*[(1.0, 67.992565055762071, 2.4348776821101543),
 (2.0, 35.944237918215613, 2.883972215075894),
 (3.0, 35.304832713754649, 2.9431621465666473),
 (4.0, 34.724907063197023, 3.2478977463841239),
 (5.0, 34.156133828996282, 3.6619915848527351),
 (6.0, 33.486988847583646, 4.172831632653061),
 (7.0, 30.773234200743495, 4.7081128747795411),
 (8.0, 25.78066914498141, 5.1917159763313609),
 (9.0, 24.096654275092938, 6.6590214067278284),
 (10.0, 22.750929368029741, 5.8913480885311875)])


# In[17]:

tss,r2_paper_ratio,r1_paper_ratio=zip(*[(1.0, 1.7199047778095973, 0.93018161175431446),
 (2.0, 1.2828967029493328, 1.0237034843531569),
 (3.0, 1.0498922503341208, 0.9343386219914287),
 (4.0, 0.82151235404311185, 0.94772186419872484),
 (5.0, 0.62585109085810553, 0.99305703394810207),
 (6.0, 0.48949170023241995, 1.0616497361930592),
 (7.0, 0.39220004694577182, 1.1601401418225972),
 (8.0, 0.33407937278574334, 1.2787186359051901),
 (9.0, 0.29664913245254115, 1.4051699922452516),
 (10.0, 0.27615848412695582, 1.5021650739480736)])


# In[18]:

tss,r2_patent_ratio,r1_patent_ratio=zip(*
[(1.0, 1.0768416577739603, 0.79834812559103963),
 (2.0, 1.0266665177125109, 0.98265056472244261),
 (3.0, 0.95808004052684892, 1.1002406281661599),
 (4.0, 0.98113814167827673, 1.0990247561890472),
 (5.0, 0.8410328122658941, 1.2985067172751334),
 (6.0, 0.90205011389521639, 1.3758542141230068),
 (7.0, 0.80742140525682871, 1.4567943652293418),
 (8.0, 1.0180012414649287, 1.4897579143389199),
 (9.0, 0.64970221981591769, 1.6134271792095289),
 (10.0, 0.76241134751773043, 1.8262411347517731)])


# In[19]:

tss,r2_Github_ratio,r1_Github_ratio=zip(*[(1.0, 20.0, 0.47287139538062045),
 (2.0, 18.574736300488805, 0.59171597633136086),
 (3.0, 13.462204270051933, 0.78476630121177138),
 (4.0, 10.030272452068617, 0.90817356205852662),
 (5.0, 8.1626928471248252, 1.1874707807386629),
 (6.0, 6.8494897959183669, 1.5178571428571426),
 (7.0, 5.890652557319223, 1.6754850088183419),
 (8.0, 5.2781065088757391, 2.390532544378698),
 (9.0, 4.6788990825688073, 2.5076452599388377),
 (10.0, 3.5814889336016096, 2.6961770623742454)])


# In[ ]:




# In[ ]:




# ## a paper

# In[21]:

zip(xdisPaper[:10],ydisPaper[:10],yimpPaper[:10])#main #teamszie, DisruptionP, Citation


# In[22]:

zip(xdisPaperlog,ydisPaperlog,yimpPaperlog)#inset #teamszie,DisruptionP, Citation


# ## b patent

# In[48]:

zip(xdisPatent[1:11],ydisPatent[1:11],yimpPatent[1:11])#main #teamszie, DisruptionP, Citation


# In[106]:

zip(xdisPatentlog[1:],ydisPatentlog[1:],yimpPatentlog[1:])#inset #teamszie,DisruptionP, Citation


# ## c github

# In[72]:

zip(xdisGithub[:10],ydisGithub[:10],yimpGithub[:10])#main #teamszie, DisruptionP, Citation


# In[76]:

zip(xdisGithublog[:8],ydisGithublog[:8],yimpGithublog[:8])


# ## d paper

# In[51]:

ratio=5/100.0
tss_paper,r1_paper,r2_paper,r3_paper,r4_paper=np.array(top5Paper).T
zip(tss,r2_paper/ratio,r1_paper/ratio)


# ## e patent

# In[53]:

ratio=5/100.0
tss_patent,r1_patent,r2_patent,r3_patent,r4_patent=np.array(top5Patent).T
zip(tss,r2_patent/ratio,r1_patent/ratio)


# ## f github

# In[ ]:

tss_Github,r1_Github,r2_Github=np.array(top5GithubA).T
tss_Github,r3_Github,r4_Github=np.array(top5GithubB).T


# In[78]:

zip(tss,r2_Github/ratio,r1_Github/ratio)


# In[ ]:




# # export figure 4 data

# In[119]:

a_main = DataFrame({'Team size': xdepPaper[:10], 'Reference age': ydepPaper[:10]                , 'Reference popularity':ypopPaper[:10]})
a_inset = DataFrame({'Team size': xdepPaperlog, 'Reference age': ydepPaperlog                , 'Reference popularity':ypopPaperlog})
b_main = DataFrame({'Team size': xdepPatent[:10], 'Reference age': ydepPatent[:10]                , 'Reference popularity':ypopPatent[:10]})
b_inset = DataFrame({'Team size': xdepPatentlog, 'Reference age': ydepPatentlog                , 'Reference popularity':ypopPatentlog})
c_main = DataFrame({'Team size': xdepGithub[:10], 'Reference age': ydepGithub[:10]                , 'Reference popularity':ypopGithub[:10]})
c_inset = DataFrame({'Team size': xdepGithublog[:6], 'Reference age': ydepGithublog[:6]                , 'Reference popularity':ypopGithublog[:6]})
d = DataFrame({'Team size':tss,'Reference age Ratio': r3_paper/ratio                , 'Reference popularity Ratio':r4_paper/ratio})
e = DataFrame({'Team size':tss,'Reference agen Ratio': r3_patent/ratio                , 'Reference popularity Ratio':r4_patent/ratio})
f = DataFrame({'Team size':range(2,11),'Reference age Ratio': r3_Github/ratio                , 'Reference popularity Ratio':r4_Github/ratio})

xls_path='/Users/lingfeiw/Dropbox/teams/2 submit nature/0 final/Figure4/Figure4.xlsx'
save_xls(['a_main','a_inset','b_main','b_inset','c_main','c_inset','d','e','f'],         [a_main,a_inset,b_main,b_inset,c_main,c_inset,d,e,f], xls_path)


# In[ ]:




# In[ ]:




# ## a paper

# In[31]:

zip(xdepPaper[:10],ydepPaper[:10],ypopPaper[:10])#main #teamszie, Dep, Popularity


# In[34]:

zip(xdepPaperlog,ydepPaperlog,ypopPaperlog)#inset #teamszie, Dep, Popularity


# ## b patent

# In[54]:

zip(xdepPatent[:10],ydepPatent[:10],ypopPatent[:10])#main #teamszie, Dep, Popularity


# In[79]:

zip(xdepPatentlog,ydepPatentlog,ypopPatentlog)#main #teamszie, Dep, Popularity


# # c github

# In[82]:

zip(xdepGithub[:10],ydepGithub[:10],ypopGithub[:10])#main #teamszie, Dep, Popularity


# In[117]:

zip(xdepGithublog[:6],ydepGithublog[:6],ypopGithublog[:6])


# ## d paper

# In[52]:

zip(tss,r3_paper/ratio,r4_paper/ratio) #teamszie, Depth, Popularity


# ## e patent

# In[56]:

zip(tss,r3_patent/ratio,r4_patent/ratio) #teamszie, Depth, Popularity


# ## f github

# In[87]:

zip(range(2,11),r3_Github/ratio,r4_Github/ratio) #teamszie, Depth, Popularity


# In[69]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper,ydisPaper, label="Disruption",color='#117733')
par1.plot(ximpPaper,yimpPaper, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa,ydisPaperCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa,yimpPaperCIb,color='gray',alpha=0.15)

host.set_xlim(1, 10)
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(20,32)
par1.set_yticks([20,23,26,29,32])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPaperlog,ydisPaperlog,linewidth=1,color='#117733')
par1.plot(ximpPaperlog,yimpPaperlog,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(20, 100)
par1.set_yticks([20,60,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[3]:

# papers
W1=defaultdict(lambda:{})
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]


# In[ ]:




# In[ ]:




# In[9]:

n,len(W1)


# In[4]:

Wmp={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperImpactMedian.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,medianImp=line.strip().split('\t')
        Wmp[int(paper)]=float(medianImp)


# In[5]:

#aggregate data by team size
disPaper=defaultdict(lambda:[])
impPaper=defaultdict(lambda:[])
depPaper=defaultdict(lambda:[])
popPaper=defaultdict(lambda:[])
for i in W1:
    if i in Wmp:
        teamsize,impact,disruption,timegap, meanimp=W1[i]
        disPaper[teamsize].append(disruption)
        impPaper[teamsize].append(impact)
        depPaper[teamsize].append(timegap)
        popPaper[teamsize].append(Wmp[i])


# In[7]:

DisruptionPaper=[v[2] for v in W1.values()]
DisruptionPaper=random.sample(DisruptionPaper,10000)
stats.percentileofscore(DisruptionPaper,0)


# In[44]:

# mean
xdisPaper,ydisPaper=np.array(sorted([(k,np.mean(v)) for k,v in disPaper.items()])).T
ximpPaper,yimpPaper=np.array(sorted([(k,np.mean(v)) for k,v in impPaper.items()])).T
xdepPaper,ydepPaper=np.array(sorted([(k,np.mean(v)) for k,v in depPaper.items()])).T
xpopPaper,ypopPaper=np.array(sorted([(k,np.median(v)) for k,v in popPaper.items()])).T

# CI
ydisPaperCIa,ydisPaperCIb=calculateCI(disPaper,'mean',50)
yimpPaperCIa,yimpPaperCIb=calculateCI(impPaper,'mean',50)
ydepPaperCIa,ydepPaperCIb=calculateCI(depPaper,'mean',50)
ypopPaperCIa,ypopPaperCIb=calculateCI(popPaper,'median',50)

#log
xdisPaperlog,ydisPaperlog=log2linearBin(xdisPaper,ydisPaper)
ximpPaperlog,yimpPaperlog=log2linearBin(ximpPaper,yimpPaper)
xdepPaperlog,ydepPaperlog=log2linearBin(xdepPaper,ydepPaper)
xpopPaperlog,ypopPaperlog=log2linearBin(xpopPaper,ypopPaper)

#percentile
ydisPaper=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper]
ydisPaperCIa=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperCIa]
ydisPaperCIb=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperCIb]
ydisPaperlog=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperlog]


# In[10]:

# top 5%
DisruptionPaper=[]
ImpactPaper=[]
TimegapPaper=[]
MeanpopPaper=[]
for ts in range(1,11):
    DisruptionPaper+=disPaper[ts]
    ImpactPaper+=impPaper[ts]
    TimegapPaper+=depPaper[ts]
    MeanpopPaper+=popPaper[ts]
    
rr=95
a1,a2,a3,a4=np.percentile(ImpactPaper,rr),np.percentile(DisruptionPaper,rr),np.percentile(TimegapPaper,rr),np.percentile(MeanpopPaper,rr)
[a1,a2,a3,a4]

top5Paper=[]
for ts in range(1,11):
    ratio1=len([i for i in impPaper[ts] if i>=a1])/float(len(impPaper[ts]))
    ratio2=len([i for i in disPaper[ts] if i>=a2])/float(len(disPaper[ts]))
    ratio3=len([i for i in depPaper[ts] if i>=a3])/float(len(depPaper[ts]))
    ratio4=len([i for i in popPaper[ts] if i>=a4])/float(len(popPaper[ts]))
    top5Paper.append([ts,ratio1,ratio2,ratio3,ratio4])


# In[37]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper,ydisPaper, label="Disruption",color='#117733')
par1.plot(ximpPaper,yimpPaper, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa,ydisPaperCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa,yimpPaperCIb,color='gray',alpha=0.15)

host.set_xlim(1, 10)
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(20,32)
par1.set_yticks([20,23,26,29,32])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPaperlog,ydisPaperlog,linewidth=1,color='#117733')
par1.plot(ximpPaperlog,yimpPaperlog,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(20, 100)
par1.set_yticks([20,60,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[36]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper,ydisPaper, label="Disruption",color='#117733')
par1.plot(ximpPaper,yimpPaper, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa,ydisPaperCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa,yimpPaperCIb,color='gray',alpha=0.15)

host.set_xlim(1, 10)
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(20,32)
par1.set_yticks([20,23,26,29,32])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xticklabels('')
host.set_yticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPaperlog,ydisPaperlog,linewidth=1,color='#117733')
par1.plot(ximpPaperlog,yimpPaperlog,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(20, 100)
par1.set_yticks([20,60,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

subax.set_yticklabels('')
par1.set_yticklabels('')
par1.set_xticklabels('')

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[ ]:




# In[34]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPaper,ydepPaper, label="Disruption",color='#117733')
par1.plot(xpopPaper,ypopPaper, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydepPaperCIa,ydepPaperCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPaperCIa,ypopPaperCIb,color='gray',alpha=0.15)


host.set_xlim(1, 10)
host.set_ylim(7.5, 9.5)
#host.set_yticks([7,9,12])
par1.set_ylim(40,80)
par1.set_yticks([40,50,60,70,80])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepPaperlog,ydepPaperlog,linewidth=1,color='#117733')
par1.plot(xpopPaperlog,ypopPaperlog,linewidth=1,color='#882255')
subax.set_ylim(6, 10)
subax.set_yticks([6,8,10])
par1.set_ylim(40,80)
par1.set_yticks([40,60,80])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[41]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPaper,ydepPaper, label="Disruption",color='#117733')
par1.plot(xpopPaper,ypopPaper, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydepPaperCIa,ydepPaperCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPaperCIa,ypopPaperCIb,color='gray',alpha=0.15)


host.set_xlim(1, 10)
host.set_ylim(7.5, 9.5)
#host.set_yticks([7,9,12])
par1.set_ylim(40,80)
par1.set_yticks([40,50,60,70,80])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepPaperlog,ydepPaperlog,linewidth=1,color='#117733')
par1.plot(xpopPaperlog,ypopPaperlog,linewidth=1,color='#882255')
subax.set_ylim(6, 10)
subax.set_yticks([6,8,10])
par1.set_ylim(40,80)
par1.set_yticks([40,60,80])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.2.pdf')


# In[ ]:




# In[23]:

tss,r1,r2,r3,r4=np.array(top5Paper).T


# In[9]:

tss,r1,r2,r3,r4=np.array(top5Paper).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()


# In[13]:

tss,r1,r2,r3,r4=np.array(top5Paper).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
#plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.tick_params(axis='y', which='both',right='off',left='on')
host.set_yticklabels('')
host.set_xticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=4, which='major')

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.a.pdf')


# In[15]:

tss,r1,r2,r3,r4=np.array(top5Paper).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
#plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
#plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.tick_params(axis='y', which='both',right='off',left='on')
host.set_yticklabels('')
host.set_xticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=4, which='major')

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.b.pdf')


# In[ ]:




# In[2]:

W2={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize, disruptiveness, impact=line.strip().split('\t')
        year=int(date[:4])
        W2[Id]=[year,int(teamsize),int(impact),float(disruptiveness)]
Patent=defaultdict(lambda:{})
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStatTwoNetworks.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        i, year, ts,ie,dise,ia,disa=line
        Patent[i]=[int(year),int(ts),int(ie),float(dise),int(ia),float(disa)]


# In[11]:

cc=Counter([Patent[i][1] for i in Patent])


# In[10]:

sum([cc[i] for i in cc if 1<=i<=10])/float(sum(cc.values()))


# In[12]:

sum([cc[i] for i in cc if 1<=i<=10])/float(sum(cc.values()))


# In[38]:

len(W2)


# In[37]:

m=0
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentNetworkApplicant.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in W2:
            year2=W2[p][0]
            if 2002<=year2<=2009:
                m+=1


# In[39]:

m,len(Patent)


# In[40]:

disPatent=defaultdict(lambda:[])
impPatent=defaultdict(lambda:[])
for i in Patent:
    year,ts, ie,dise,ia,disa=Patent[i]
    if 2002<=year<=2009:
        disPatent[ts].append(disa)
        impPatent[ts].append(ia)
    
depPatent=defaultdict(lambda:[])
popPatent=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentNetworkApplicant.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in W2:
            teamsize=W2[p][1]
            year2=W2[p][0]
            if 2002<=year2<=2009:
                gs=[year2-W2[j][0] for j in line[1:] if j in W2 and W2[j][0]<=year2]
                degrees=[W2[j][2] for j in line[1:] if j in W2]
                if gs:
                    depPatent[teamsize].append(np.mean(gs))
                    popPatent[teamsize].append(np.median(degrees))


# In[41]:

DisruptionPatent=[v[-1] for v in Patent.values()]
#DisruptionPatent=random.sample(DisruptionPatent,10000)
stats.percentileofscore(DisruptionPatent,0)


# In[42]:

xdisPatent,ydisPatent=np.array(sorted([(k,np.mean(v)) for k,v in disPatent.items()])).T
ydisPatent=[stats.percentileofscore(DisruptionPatent,i) for i in ydisPatent]#percentile


# In[43]:

# mean
xdisPatent,ydisPatent=np.array(sorted([(k,np.mean(v)) for k,v in disPatent.items()])).T
ximpPatent,yimpPatent=np.array(sorted([(k,np.mean(v)) for k,v in impPatent.items()])).T
xdepPatent,ydepPatent=np.array(sorted([(k,np.mean(v)) for k,v in depPatent.items()])).T
xpopPatent,ypopPatent=np.array(sorted([(k,np.median(v)) for k,v in popPatent.items()])).T

# CI
ydisPatentCIa,ydisPatentCIb=calculateCI(disPatent,'mean',50)
yimpPatentCIa,yimpPatentCIb=calculateCI(impPatent,'mean',50)
ydepPatentCIa,ydepPatentCIb=calculateCI(depPatent,'mean',50)
ypopPatentCIa,ypopPatentCIb=calculateCI(popPatent,'median',50)
ydisPatent=[stats.percentileofscore(DisruptionPatent,i) for i in ydisPatent]#percentile

#log
xdisPatentlog,ydisPatentlog=log2linearBin(xdisPatent[:-2],ydisPatent[:-2])
ximpPatentlog,yimpPatentlog=log2linearBin(ximpPatent[:-2],yimpPatent[:-2])
xdepPatentlog,ydepPatentlog=log2linearBin(xdepPatent,ydepPatent)
xpopPatentlog,ypopPatentlog=log2linearBin(xpopPatent,ypopPatent)

#percentile
ydisPatentCIa=[stats.percentileofscore(DisruptionPatent,i) for i in ydisPatentCIa]
ydisPatentCIb=[stats.percentileofscore(DisruptionPatent,i) for i in ydisPatentCIb]


# In[45]:

# top 5%
DisruptionPatent=[]
ImpactPatent=[]
TimegapPatent=[]
MeanpopPatent=[]
for ts in range(1,11):
    DisruptionPatent+=disPatent[ts]
    ImpactPatent+=impPatent[ts]
    TimegapPatent+=depPatent[ts]
    MeanpopPatent+=popPatent[ts]
    
rr=95
a1,a2,a3,a4=np.percentile(ImpactPatent,rr),np.percentile(DisruptionPatent,rr),np.percentile(TimegapPatent,rr),np.percentile(MeanpopPatent,rr)

top5Patent=[]
for ts in range(1,11):
    ratio1=len([i for i in impPatent[ts] if i>=a1])/float(len(impPatent[ts]))
    ratio2=len([i for i in disPatent[ts] if i>=a2])/float(len(disPatent[ts]))
    ratio3=len([i for i in depPatent[ts] if i>=a3])/float(len(depPatent[ts]))
    ratio4=len([i for i in popPatent[ts] if i>=a4])/float(len(popPatent[ts]))
    top5Patent.append([ts,ratio1,ratio2,ratio3,ratio4])

[a1,a2,a3,a4]


# In[128]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPatent,ydisPatent, label="Disruption",color='#117733')
par1.plot(ximpPatent,yimpPatent, label="Impact",color='#882255')
host.fill_between(range(1,11), ydisPatentCIa,ydisPatentCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPatentCIa,yimpPatentCIb,color='gray',alpha=0.15)

host.set_xlim(1,10)
host.set_ylim(64,80)
host.set_yticks([64,68,72,76,80])
par1.set_ylim(4,20)
par1.set_yticks([4,8,12,16,20])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPatentlog,ydisPatentlog,linewidth=1,color='#117733')
par1.plot(ximpPatentlog,yimpPatentlog,linewidth=1,color='#882255')
#subax.set_ylim(20,80)
subax.set_yticks([30,60,90])
#par1.set_ylim(20, 80)
par1.set_yticks([1,10,20])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[134]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPatent,ydisPatent, label="Disruption",color='#117733')
par1.plot(ximpPatent,yimpPatent, label="Impact",color='#882255')
host.fill_between(range(1,11), ydisPatentCIa,ydisPatentCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPatentCIa,yimpPatentCIb,color='gray',alpha=0.15)

host.set_xlim(1,10)
host.set_ylim(64,80)
host.set_yticks([64,68,72,76,80])
par1.set_ylim(4,20)
par1.set_yticks([4,8,12,16,20])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPatentlog,ydisPatentlog,linewidth=1,color='#117733')
par1.plot(ximpPatentlog,yimpPatentlog,linewidth=1,color='#882255')
subax.set_ylim(30,90)
subax.set_yticks([30,60,90])
#subax.plot([1,100],[38.6,38.6],linestyle='--',color='#117733')
par1.set_ylim(1, 20)
par1.set_yticks([1,10,20])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)



[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')



plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.4.pdf')


# In[145]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPatent,ydepPatent, label="Disruption",color='#117733')
par1.plot(xpopPatent,ypopPatent, label="Impact",color='#882255')
host.fill_between(range(1,11), ydepPatentCIa,ydepPatentCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPatentCIa,ypopPatentCIb,color='gray',alpha=0.15)

host.set_xlim(1,10)
host.set_ylim(9,11)
#host.set_yticks([64,68,72,76,80])
par1.set_ylim(20,44)
par1.set_yticks([20,26,32,38,44])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepPatentlog,ydepPatentlog,linewidth=1,color='#117733')
par1.plot(xpopPatentlog,ypopPatentlog,linewidth=1,color='#882255')
subax.set_ylim(7,13)
subax.set_yticks([7,10,13])
par1.set_ylim(1, 100)
par1.set_yticks([1,50,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[150]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPatent,ydepPatent, label="Disruption",color='#117733')
par1.plot(xpopPatent,ypopPatent, label="Impact",color='#882255')
host.fill_between(range(1,11), ydepPatentCIa,ydepPatentCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPatentCIa,ypopPatentCIb,color='gray',alpha=0.15)

host.set_xlim(1,10)
host.set_ylim(9,11)
#host.set_yticks([64,68,72,76,80])
par1.set_ylim(20,44)
par1.set_yticks([20,26,32,38,44])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')


host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepPatentlog,ydepPatentlog,linewidth=1,color='#117733')
par1.plot(xpopPatentlog,ypopPatentlog,linewidth=1,color='#882255')
subax.set_ylim(7,13)
subax.set_yticks([7,10,13])
par1.set_ylim(1, 100)
par1.set_yticks([1,50,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')


plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.5.pdf')


# In[26]:


tss,r1,r2,r3,r4=np.array(top5Patent).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
#plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.tick_params(axis='y', which='both',right='off',left='on')
host.set_yticklabels('')
host.set_xticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=4, which='major')

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.6.a.pdf')


# In[27]:


tss,r1,r2,r3,r4=np.array(top5Patent).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
#plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
#plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.tick_params(axis='y', which='both',right='off',left='on')
host.set_yticklabels('')
host.set_xticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=4, which='major')

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.6.b.pdf')


# In[57]:

n=0
W3={}
W4={}
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubStats.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, year, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if 2011<=int(year)<=2014:
            if disruptiveness!='NA':
                W3[int(Id)]=[int(year),int(teamsize),int(impact),float(disruptiveness)]
            W4[int(Id)]=[int(year),int(teamsize),int(impact),disruptiveness]


# In[58]:

len(W3),len(W4)


# In[59]:

n=0
m=0
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubStats.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, year, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if int(impact)>=0:
            m+=1


# In[60]:

m,n


# In[61]:

disGithub=defaultdict(lambda:[])
impGithub=defaultdict(lambda:[])
for i in W3:
    year3,teamsize3,impact3,disruptive3=W3[i]
    if teamsize3>0:
        disGithub[teamsize3].append(disruptive3)
        impGithub[teamsize3].append(impact3)
depGithub=defaultdict(lambda:[])
popGithub=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubCites.txt','r') as f:
    for line in f:
        line=map(int,line.strip().split('\t'))
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        p=line[0]
        cites=line[1:]
        if p in W4 and cites :
            teamsize=W4[p][1]
            yeari=W4[p][0]
            yearjs=[W4[j][0] for j in cites if j in W4]
            degrees=[W4[j][2] for j in cites if j in W4]
            if yearjs:
                depGithub[teamsize].append(np.mean(yeari-np.array(yearjs)))
            if degrees:
                popGithub[teamsize].append(np.mean(degrees))


# In[62]:

DisruptionGithub=[i[-1] for i in W3.values()]
stats.percentileofscore(DisruptionGithub,0)


# In[63]:

# mean
xdisGithub,ydisGithub=np.array(sorted([(k,np.mean(v)) for k,v in disGithub.items()])).T
ximpGithub,yimpGithub=np.array(sorted([(k,np.mean(v)) for k,v in impGithub.items()])).T
xdepGithub,ydepGithub=np.array(sorted([(k,np.mean(v)) for k,v in depGithub.items() if k<100])).T
xpopGithub,ypopGithub=np.array(sorted([(k,np.median(v)) for k,v in popGithub.items() if k<100])).T

'''
# CI
ydisGithubCIa,ydisGithubCIb=calculateCI(disGithub,'mean',50)
yimpGithubCIa,yimpGithubCIb=calculateCI(impGithub,'mean',50)
ydepGithubCIa,ydepGithubCIb=calculateCI(depGithub,'mean',50)
ypopGithubCIa,ypopGithubCIb=calculateCI(popGithub,'median',50)
'''
ydisGithub=[stats.percentileofscore(DisruptionGithub,i) for i in ydisGithub]#percentile

#log
xdisGithublog,ydisGithublog=log2linearBin(xdisGithub,ydisGithub)
ximpGithublog,yimpGithublog=log2linearBin(ximpGithub,yimpGithub)
xdepGithublog,ydepGithublog=log2linearBin(xdepGithub,ydepGithub)
xpopGithublog,ypopGithublog=log2linearBin(xpopGithub,ypopGithub)
'''
#percentile
ydisGithubCIa=[stats.percentileofscore(DisruptionGithub,i) for i in ydisGithubCIa]
ydisGithubCIb=[stats.percentileofscore(DisruptionGithub,i) for i in ydisGithubCIb]
'''


# In[164]:

fig = plt.figure(figsize=(5,5),facecolor='white')

host = host_subplot(111)
par1 = host.twinx()
offset = 60
host.plot(xdisGithub,ydisGithub,marker='',color='#117733',label='Disruption',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(20,80)
host.set_yticks([20,35,50,65,80])
host.plot([1,10],[32,32],linestyle='--',color='#117733')

par1.plot(ximpGithub,yimpGithub,marker='',color='#882255',label='Impact',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(1,9)
par1.set_yticks([1,3,5,7,9])
host.tick_params(axis='x', which='both',bottom='on',top='off')


host.fill_between(range(1,11), ydisGithubCIa,ydisGithubCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpGithubCIa,yimpGithubCIb,color='gray',alpha=0.15)

#[i.set_linewidth(0.4) for i in host.spines.itervalues()]
#[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
#host.tick_params('both', length=2, which='major')
#par1.tick_params('both', length=2, which='major')


plt.legend(loc=2,numpoints=1,fontsize=10,frameon=False)


###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.35,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisGithublog,ydisGithublog,linewidth=1,color='#117733')
subax.plot([1,100],[32,32],linestyle='--',color='#117733')
#par1.plot(xa55,newya55_,linewidth=1,color='#4477AA')
par1.plot(ximpGithublog,yimpGithublog,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(1,30)
par1.set_yticks([1,15,30])

subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

plt.tight_layout()

#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.pdf')


# In[193]:

fig = plt.figure(figsize=(5,5),facecolor='white')

host = host_subplot(111)
plt.subplots_adjust(right=1)
par1 = host.twinx()

host.plot(xdisGithub,ydisGithub,marker='',color='#117733',label='Disruption',alpha=1,linewidth=1)
host.set_xlim(1,10)
host.set_ylim(20,80)
host.set_yticks([20,35,50,65,80])

par1.plot(ximpGithub,yimpGithub,marker='',color='#882255',label='Impact',alpha=1,linewidth=1)
par1.set_xlim(1,10)
par1.set_ylim(1,9)
par1.set_yticks([1,3,5,7,9])
host.tick_params(axis='x', which='both',bottom='on',top='off')


host.fill_between(range(1,11), ydisGithubCIa,ydisGithubCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpGithubCIa,yimpGithubCIb,color='gray',alpha=0.15)

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.set_yticklabels('')
par1.set_yticklabels('')
host.set_xticklabels('')

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')



###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.35,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisGithublog,ydisGithublog,linewidth=1,color='#117733')
#par1.plot(xa55,newya55_,linewidth=1,color='#4477AA')
par1.plot(ximpGithublog,yimpGithublog,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(1,30)
par1.set_yticks([1,15,30])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)


subax.set_yticklabels('')
par1.set_yticklabels('')
subax.set_xticklabels('')

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.7.pdf')


# In[190]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.fill_between(range(1,11), ydepGithubCIa,ydepGithubCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopGithubCIa,ypopGithubCIb,color='gray',alpha=0.15)


host.plot(xdepGithub,ydepGithub, label="Depth",color='#117733')
par1.plot(xpopGithub,ypopGithub, label="Popularity",color='#882255')



host.set_xlim(1, 10)
host.set_ylim(0.2, 1)
host.set_yticks([0.2,0.4,0.6,0.8,1])
par1.set_ylim(4,12)
par1.set_yticks([4,6,8,10,12])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.35,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepGithublog,ydepGithublog,linewidth=1,color='#117733')
par1.plot(xpopGithublog,ypopGithublog,linewidth=1,color='#882255')
subax.set_ylim(0, 1)
subax.set_yticks([0,0.5,1])
par1.set_ylim(4,20)
par1.set_yticks([4,12,20])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

#
plt.tight_layout()


# In[196]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.fill_between(range(1,11), ydepGithubCIa,ydepGithubCIb,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopGithubCIa,ypopGithubCIb,color='gray',alpha=0.15)


host.plot(xdepGithub,ydepGithub, label="Depth",color='#117733')
par1.plot(xpopGithub,ypopGithub, label="Popularity",color='#882255')

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.set_yticklabels('')
par1.set_yticklabels('')
host.set_xticklabels('')


[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xlim(1, 10)
host.set_ylim(0.2, 1)
host.set_yticks([0.2,0.4,0.6,0.8,1])
par1.set_ylim(4,12)
par1.set_yticks([4,6,8,10,12])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.35,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepGithublog,ydepGithublog,linewidth=1,color='#117733')
par1.plot(xpopGithublog,ypopGithublog,linewidth=1,color='#882255')
subax.set_ylim(0, 1)
subax.set_yticks([0,0.5,1])
par1.set_ylim(4,20)
par1.set_yticks([4,12,20])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')


subax.set_yticklabels('')
par1.set_yticklabels('')
subax.set_xticklabels('')

#
plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.8.pdf')


# In[65]:

DisruptionGithub=[]
for ts in range(1,11):
    DisruptionGithub+=disGithub[ts] 

ImpactGithub=[]
for ts in range(1,11):
    ImpactGithub+= impGithub[ts] 
    
rr=95

a1,a2=np.percentile(ImpactGithub,rr),np.percentile(DisruptionGithub,rr)
[a1,a2]


# In[82]:

DisruptionGithub.count(1)/float(len(DisruptionGithub))


# In[66]:

top5GithubA=[]
for ts in range(1,11):
    ratio1=len([i for i in impGithub[ts] if i>a1])/float(len(impGithub[ts]))
    ratio2=len([i for i in disGithub[ts] if i==1])/float(len(disGithub[ts]))
    top5GithubA.append([ts,ratio1,ratio2])


# In[ ]:




# In[91]:

tss,r1,r2=np.array(top5GithubA).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0
host = host_subplot(111)
#par1 = host.twinx()
plt.plot(tss,r2/0.69,color='#117733',label='Disruption = 1')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#par1.set_ylim(0,0)
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,3)
plt.yticks([0,1,2,3])
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.tick_params(axis='y', which='both',right='off',left='on')
#host.set_yticklabels('')
#host.set_xticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=4, which='major')



plt.tight_layout()

#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.9.a.pdf')


# In[67]:

TimegapGithub=[]
for ts in range(1,11):
    TimegapGithub+=depGithub[ts]

MeanpopGithub=[]
for ts in range(1,11):
    MeanpopGithub+=popGithub[ts]

rr1=95
rr2=75
a3,a4=np.percentile(TimegapGithub,rr1),np.percentile(MeanpopGithub,rr2)
a3,a4


# In[68]:

top5GithubB=[]
for ts in range(2,11):
    ratio3=len([i for i in depGithub[ts] if i>=a3])/float(len(depGithub[ts]))
    ratio4=len([i for i in popGithub[ts] if i>=a4])/float(len(popGithub[ts]))
    top5GithubB.append([ts,ratio3,ratio4])


# In[196]:

tss,r3,r4=np.array(top5GithubB).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio1=1-rr1/100.0
ratio2=1-rr2/100.0
host = host_subplot(111)
#par1 = host.twinx()
plt.plot(tss,r3/ratio1,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r4/ratio2,color='#882255',linestyle='--',label='Top 25% Popularity')
#par1.set_ylim(0,0)
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)

host.tick_params(axis='x', which='both',bottom='on',top='off')
host.tick_params(axis='y', which='both',right='off',left='on')
host.set_yticklabels('')
host.set_xticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=4, which='major')

plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.9.b.pdf')


# In[ ]:




# In[ ]:




# In[ ]:



