
# coding: utf-8

# In[3]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# # keyword probability

# ### 1. Calculate keyword probability

# In[2]:

W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(journal),int(subject),float(disruptive),int(year),int(teamsize),int(impact)]


# In[565]:

len([v for v in W.values() if v[2]>0]),len([v for v in W.values() if v[2]<0]),len(W)


# In[566]:

6397815+16266398


# In[253]:

#  titles keyword probability
A=defaultdict(int)
B=defaultdict(int)
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        t=line[1]
        if p in W:
            t=t.lower().split(' ')
            if W[p][2]>0:
                for j in t:
                    A[j]+=1
            else:
                for j in t:
                    B[j]+=1


# In[564]:

len(W)


# In[ ]:

#mention someone's name


# In[255]:

len(A),len(B)


# In[260]:

a=sum(A.values())+0.0
b=sum(B.values())+0.0
A1=dict((k,v/a) for k,v in A.items())
B1=dict((k,v/b) for k,v in B.items())


# In[272]:

np.percentile(A.values(),99),np.percentile(B.values(),99)


# In[469]:

# export probability
d=[]
for i in A1:
    if i in B1:
        d.append([i,A1[i]/B1[i]])
d=sorted(d,key=lambda x:-x[1])
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015_keyword_compare.txt','w') as f:
    for a,b in d:
        f.write(a+'\t'+str(b)+'\n')   


# In[512]:

# abstract keyword probabilities
#  titles keyword probability
C=defaultdict(int)
D=defaultdict(int)
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        line=line.strip().split('\t')
        if len(line)==2:
            p=int(line[0])
            s=line[1]
            if p in W:
                t=s.lower().split(' ')
                if W[p][2]>0:
                    for j in t:
                        C[j]+=1
                else:
                    for j in t:
                        D[j]+=1 


# In[517]:

len(C),len(D)


# In[514]:

c=sum(C.values())+0.0
d=sum(D.values())+0.0
C1=dict((k,v/c) for k,v in C.items())
D1=dict((k,v/d) for k,v in D.items())


# In[527]:

# export probability
d=[]
for i in C1:
    if i in D1:
        d.append([i,C1[i]/D1[i]])
d=sorted(d,key=lambda x:-x[1])
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_keyword_compare.txt','w') as f:
    for a,b in d:
        if a and b:
            f.write(a+'\t'+str(b)+'\n')  


# ### 2. read probability data

# In[54]:

P1={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015_keyword_compare.txt','rb') as f:
    for line in f:
        s,r=line.strip().split('\t')
        P1[s]=float(str(np.round(float(r),2)))
P2={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_keyword_compare.txt','rb') as f:
    for line in f:
        s,r=line.strip().split('\t')
        P2[s]=float(str(np.round(float(r),2)))


# In[34]:

len(P1),len(P2)


# In[35]:

#1. easy vs hard to disrupt 
#'application','algorithm','test','theoretical','evaluation','measuring','classification','structure','definition
v=['technique','method','device','tool','estimation','measure','assessment',   'test','pattern','mechanism','hypothesis','model','theory']
[(i,P1[i],P2[i]) for i in v]


# In[40]:

i='analysis'
(i,P1[i],P2[i]) 


# In[55]:

i='advance'
(i,P1[i],P2[i]) 


# In[44]:

i='change'
(i,P1[i],P2[i]) 


# In[53]:

i='consistent'
(i,P1[i],P2[i]) 


# In[153]:

i='demonstrate'
(i,P1[i],P2[i]) 


# In[154]:

2-0.61


# In[86]:

i='endorse'
(i,P1[i],P2[i]) 


# In[87]:

2-0.43


# In[69]:

1/0.61


# In[70]:

1/np.array([0.96,0.96,0.89,0.72,0.66,0.64])


# In[ ]:




# In[ ]:




# In[55]:

i='when'
(i,P1[i],P2[i]) 


# In[57]:

i='where'
(i,P1[i],P2[i]) 


# In[155]:

0.39*61.379/0.29


# In[58]:

i='how'
(i,P1[i],P2[i]) 


# In[77]:

i='is'
(i,P1[i],P2[i]) 


# In[78]:

i='are'
(i,P1[i],P2[i]) 


# In[106]:

i='for'
(i,P1[i],P2[i]) 


# In[98]:

'slowly'


# In[58]:

len(ds),len(D),len(W)


# In[85]:

0.56*133.367/0.63


# In[165]:

v=['across','within','along','during','after','from']
for i in v:
    print(i,P1[i],2-P1[i],(1-P1[i])*61.379/0.29,P2[i])


# In[562]:

#2. adjactive claims
# 'induction','deduction','results','functions','differentiation','boundary','transfer','long-term',,'features'
#'efficient','partial','outcome','express','primary','find','enhance','increase','decrease',

v=['use','introduce','cause','correlate','confirm','associate','interact']
[(i,P1[i],P2[i]) for i in v]


# In[6]:

#3. Expressions
#'does','for','other','under','on','where','when','are','is','long-term'
v= ['why','who','what','how','between','is','are','within','not']
[(i,P1[i],P2[i]) for i in v]


# In[455]:

#4. False claims
# 'novel' and 'development'/'solution'/'problem'/improved are reversed
#v= ['highly','development','solution','problem','improved','based','novel']
#sorted([(i,float(str(np.round(A1[i]/B1[i],2)))) for i in v],key=lambda x:-x[1])


# # citation in title and abstract

# In[4]:

W=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            W.add(int(Id))


# In[3]:

AU={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/authorlist1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#427
        line=line.strip().split('\t')
        p=int(line[0])
        if p in W:
            AU[p]=set([j.split(',')[0].lower() for j in line[1:]])


# In[4]:

len(AU)


# In[5]:

'''
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_refnames.txt', "w") as f1:
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
        for line in f:
            n+=1
            if n%10000==0: 
                flushPrint(n/10000)#3140
            line=map(int,line.strip().split('\t'))
            p=line[0]
            if p in W and len(line)<100:
                s=list(set([k for j in line[1:] if j in AU for k in AU[j]]))
                if s:
                    f1.write(str(p)+'\t'+'\t'.join(s)+'\n') 
'''


# ### citation in title 

# In[17]:

# read title data
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(journal),int(subject),float(disruptive),int(year),int(teamsize),int(impact)]


# In[4]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[3]:

'''
n=0
Title={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        t=line[1]
        if p in W:
            Title[p]=t.lower()
 
len(Title)#24174022
 
N={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_refnames.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#236
        line=line.strip().split('\t')
        p=int(line[0])
        if p in Title:
            t=Title[p].lower().split(' ')
            v=set(t).intersection(line[1:])
            if v:
                N[p]=v

len(N)#148303
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015_NamesIn.txt','wb') as f:
    for p in N:
        f.write(str(p)+'\t'+'\t'.join(N[p])+'\n')
 
'''


# ### citation in abstract

# In[12]:

'''
A={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        if n/100000>260:
            line=line.strip().split('\t')
            if len(line)==2: 
                p,a=line
                p=int(p)
                if p in W and a!='None':
                    t=set(line[1].lower().split(' '))
                    v=t-stop_words
                    if v:
                        A[p]=v
#round1:<=260 #len(A)#7656270
#round2:>260  #len(A)#7753435

with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_NamesInB.txt', "w") as f1:
#M={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_refnames.txt','rb') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)#236
            line=line.strip().split('\t')
            p=int(line[0])
            if p in A:
                v=set(A[p]).intersection(line[1:])
                if v:
                    #M[p]=v
                    f1.write(str(p)+'\t'+'\t'.join(list(v))+'\n')
M={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_NamesInA.txt', "r") as f:
    for line in f:
        line=line.strip().split('\t')
        M[int(line[0])]=line[1:]
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_NamesInB.txt', "r") as f:
    for line in f:
        line=line.strip().split('\t')
        M[int(line[0])]=line[1:]
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_NamesIn.txt', "w") as f:
    for p in M:
        f.write(str(p)+'\t'+'\t'.join(M[p])+'\n')
'''


# In[10]:

N={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015_NamesIn.txt', "r") as f:
    for line in f:
        line=line.strip().split('\t')
        N[int(line[0])]=line[1:]
M={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015_NamesIn.txt', "r") as f:
    for line in f:
        line=line.strip().split('\t')
        M[int(line[0])]=line[1:]


# In[7]:

Npaper=len(W)+0.0
Ntitle=len(N)+0.0
Nabstract=len(M)+0.0
Ntitle,Nabstract,Npaper


# In[8]:

Ntitle/Npaper,Nabstract/Npaper


# In[41]:

np.mean([W[i][2] for i in N if i in W]),np.median([W[i][2] for i in N if i in W])


# In[42]:

np.mean([W[i][2] for i in M if i in W]),np.median([W[i][2] for i in M if i in W])


# In[21]:

stats.percentileofscore(ds, -0.0049)


# In[22]:

stats.percentileofscore(ds, -0.004563)


# In[50]:

stats.percentileofscore(ds, -0.001)


# In[51]:

stats.percentileofscore(ds, 0.001)


# In[52]:

100-77


# In[ ]:

stats.percentileofscore(ds, -0.004563)


# In[30]:

len([i for i in N if i in W and W[i][2]>0]),len([i for i in N if i in W and W[i][2]==0]),len([i for i in N if i in W and W[i][2]<0])


# In[24]:

len([i for i in N if i in W])


# In[28]:

19771/148303.0,7247/148303.0,121285/148303.0


# In[43]:

len([i for i in M if i in W and W[i][2]>0]),len([i for i in M if i in W and W[i][2]==0]),len([i for i in M if i in W and W[i][2]<0])


# In[44]:

88821/Nabstract,33355/Nabstract,605078/Nabstract


# In[38]:

len([i for i in ds if i>0])/float(len(ds)),len([i for i in ds if i==0])/float(len(ds)),len([i for i in ds if i<0])/float(len(ds))


# In[40]:

np.mean(ds),np.median(ds)


# In[ ]:




# In[20]:

# all paper disruption 
n=0
D={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/teamPerformance1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,n1,n2,n3=map(int,line.strip().split('\t'))
        if n1+n2>0:
            D[Id]=(n1-n2+0.0)/(n1+n2+n3+0.0)
ds=D.values()


# In[ ]:




# In[ ]:




# In[23]:

NdisPapers=len([i for i in W if W[i][2]>0])+0.0
NdevPapers=len([i for i in W if W[i][2]<0])+0.0
NdisTitle=len([i for i in W if W[i][2]>0 and i in N])+0.0
NdevTitle=len([i for i in W if W[i][2]<0 and i in N])+0.0
NdisAbtract=len([i for i in W if W[i][2]>0 and i in M])+0.0
NdevAbtract=len([i for i in W if W[i][2]<0 and i in M])+0.0


# In[26]:

NdisTitle/NdisPapers,NdevTitle/NdevPapers


# In[28]:

0.00745616823097529/0.0030902737887857027


# In[29]:

NdisAbtract/NdisPapers,NdevAbtract/NdevPapers


# # Survey Names and Questions

# In[35]:

E=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#141
        name,uni,email=line.strip().split('\t')
        es=email.split('__')
        us=uni.split('__')
        if len(es)<10 and len(us)<10:
            e=es[0].split('_')[0]
            if 'uchicago' in e or 'northwestern' in e:
                E[e].append(name)


# In[36]:

# get years
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        Y[int(ndoi)]=int(year)


# In[37]:

len(E)


# In[38]:

E.items()[:3]


# In[39]:

F={}
for e in E:
    for j in E[e]:
        F[j]=e


# In[40]:

F.items()[:3]


# In[41]:

P=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        s=line[0]
        if s in F:
            P[F[s]]+=map(int,line[1:])


# In[42]:

P.items()[:3]


# In[43]:

# selecting active scholars
Q={}
for i in P:
    v=P[i]
    if len(v)>=3 and Y[sorted(v)[-1]]>=2014:
        Q[i]=v


# In[44]:

len(P),len(Q)


# In[45]:

# the fields of scholars
X=defaultdict(lambda:[])
for i in Q:
    v=P[i]
    z=[W[j][1] for j in v if j in W]
    if z:
        f=Counter(z).most_common(1)[0][0]
        X[f].append(i)
Y={}
for f in X:
    for i in X[f]:
        Y[i]=f
    


# In[46]:

len(Y)


# In[49]:

# selecting the top journal and more cited paper
# the citation of journals
JI=defaultdict(int)
for i in W:
    JI[W[i][0]]+=W[i][-1]


# In[50]:

len(JI)


# In[52]:

J=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperJournal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=map(int,line.strip().split('\t'))
        J[line[0]]=line[1]


# In[62]:

C=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperCitation1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        C[int(line[0])]=len(line[1:])


# In[72]:

n=0
Title={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        Title[p]=line[1].lower()


# In[108]:

# 
G={}
H={}
for i in Q:
    d=[[JI[J[k]],C[k],k] for k in Q[i] if k in J and k in C]
    if d:
        bestJournalPaper=sorted(d, key=lambda x: (-x[0], -x[1]))[0][-1]
        mostPopPaper=sorted(d, key=lambda x: (-x[1], -x[0]))[0][-1]
        G[i]=bestJournalPaper
        H[i]=mostPopPaper


# In[114]:

iG = {v: k for k, v in G.iteritems()}
iH = {v: k for k, v in H.iteritems()}


# In[115]:

GR={}
HR={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in iG:
            GR[iG[p]]=line[1:]
        if p in iH:
            HR[iH[p]]=line[1:]


# In[118]:

len(G),len(H),len(GR),len(HR)


# In[152]:

d=[[len(GR[k]),len(HR[k])] for k in GR if k in HR]
np.mean(d,axis=0)# GR more selective refs


# In[162]:

Z={}
for k in GR:
    r=sorted([(W[j][2],j) for j in GR[k] if j in W])
    if len(r)>=2:
        d1,a=r[0]
        d2,b=r[-1]
        if d1<0 and d2>0:
            Z[k]=[a,b]


# In[172]:

Z1={}
for k in HR:
    r=sorted([(W[j][2],j) for j in HR[k] if j in W])
    if len(r)>=2:
        d1,a=r[0]
        d2,b=r[-1]
        if d1<0 and d2>0:
            Z1[k]=[a,b]


# In[173]:

len(Z),len(Z1)


# In[174]:

D1=[]
for i in Z1:
    a,b=Z1[i]
    D1.append([i,a,Title[a],W[a][2],b,Title[b],W[b][2]])


# In[169]:

D=[]
for i in Z:
    a,b=Z[i]
    D.append([i,a,Title[a],W[a][2],b,Title[b],W[b][2]])


# In[214]:

np.mean([v[6]-v[3] for v in D1]),np.mean([v[6]-v[3] for v in D])


# In[213]:

from scipy.stats import gaussian_kde
#
density = gaussian_kde([v[6]-v[3] for v in D1])
xs = np.linspace(-1,1,200)
density.covariance_factor = lambda : .1
density._compute_covariance()
plt.plot(xs,density(xs),label='mostPopPaper')
#
density = gaussian_kde([v[6]-v[3] for v in D])
xs = np.linspace(-1,1,200)
density.covariance_factor = lambda : .1
density._compute_covariance()
plt.plot(xs,density(xs),color='g',label='topJournalPaper')
#
plt.legend(loc=2)
plt.xlabel('Disrupting D - Developing D')
plt.ylabel('Kernel Density')


# In[171]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/DisruptionSurveyBestPaper.txt','wb') as f:
    for v in D:
        f.write('\t'.join(map(str,v))+'\n')


# In[175]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/DisruptionSurveyPopPaper.txt','wb') as f:
    for v in D1:
        f.write('\t'.join(map(str,v))+'\n')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[91]:

Q1=set([j for v in Q.values() for j in v])
len(Q1)


# In[114]:

Q2={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in Q1:
            Q2[p]=line[1:]


# In[115]:

len(Q2)


# In[218]:

np.percentile([i[-1] for i in W.values()],99)


# In[182]:

np.percentile([i[2] for i in W.values() if i[-1]>=214],99)


# In[183]:

np.percentile([i[2] for i in W.values() if i[-1]>=214],1)


# In[216]:

Two={}
for i in Q:
    if i in Y and Y[i]==2:
        v=Q[i]
        a=[]
        for j in v:
            if j in Q2:
                    a+=Q2[j]
        c=Counter(a)
        vs=sorted([(W[k][2],k) for k,v in c.items() if v>=3 and k in W and W[k][-1]>=214])
        if len(vs)>=2 and vs[0][0]<0 and vs[-1][0]>0:
            Two[i]=[vs[0][1],vs[-1][1]]


# In[217]:

len(Two)


# In[221]:

i =random.choice(Two.keys())
a,b=Two[i]
print (W[b][2],W[b][3],W[b][-1],Title[b].lower(),
              W[a][2],W[a][3],W[a][-1],Title[a].lower())


# In[68]:

fm={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}


# In[73]:

sorted([(len(v),fm[k],k) for k,v in X.items()],reverse=True)


# In[77]:

X[2]


# In[81]:

v=Q['y-nie@northwestern.edu']


# In[82]:

sorted([[W[i][-1],Title[i].lower()] for i in v if i in W],reverse=True)[:3]


# # 0. The Experiment of Brain Uzzi

# In[3]:

# jevans@uchicago.edu
B=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#141
        name,uni,email=line.strip().split('\t')
        es=email.split('__')
        us=uni.split('__')
        e=es[0].split('_')[0]
        if 'uzzi@northwestern.edu' in e:
            B.add(name)


# In[3]:

B1=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#141
        name,uni,email=line.strip().split('\t')
        es=email.split('__')
        us=uni.split('__')
        e=es[0].split('_')[0]
        if 'uzzi@kellogg.northwestern.edu' in e:
            B1.add(name)


# In[6]:

B1


# In[12]:

Uzzi={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        i=line[0]
        if i.split('+')[0]=='UZZI, B':
            Uzzi[i]=map(int,line[1:])


# In[14]:

Uzzi


# In[ ]:




# In[21]:

upaper=set([])
for i in Uzzi:
    for j in Uzzi[i]:
        if j in Title:
            upaper.add(j)
len(upaper)


# In[ ]:




# In[6]:

Uzzi=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        i=line[0]
        if i =='UZZI, B+0':
            Uzzi=set(map(int,line[1:]))
            break


# In[33]:

C={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        i = line[0]
        refs=line[1:]
        if i in upaper:
            C[i]=refs


# In[34]:

C_=defaultdict(lambda:set([]))
for i in C:
    for j in C[i]:
        C_[j].add(i)
C_=dict(C_)
len(C_)


# In[16]:

n=0
Title={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        t=line[1]
        if p in W:
            Title[p]=t.lower()


# In[37]:

len(C_),len(C)


# In[41]:

W[27306864]


# In[27]:

Title[7287465],Title[25796095],Title[27306864],Title[23638776]


# In[35]:

Title[22399745],Title[34578414],Title[33153910],Title[36356497],Title[28156144]


# In[40]:

sorted([(W[k][2],len(v),Title[k]) for k,v in C_.items() if k in W ])[:10]


# In[ ]:




# In[ ]:




# In[ ]:




# In[26]:

sorted([(len(v),W[k][2],k) for k,v in C_.items() if k in W],reverse=True)


# In[ ]:




# In[ ]:




# # 1. The Experiment of James

# In[7]:

# jevans@uchicago.edu
J=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#141
        name,uni,email=line.strip().split('\t')
        es=email.split('__')
        us=uni.split('__')
        e=es[0].split('_')[0]
        if 'jevans@uchicago.edu' in e:
            J.add(name)


# In[10]:

J


# In[8]:

# the paper of James 
James=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        i=line[0]
        if i in J:
            James+=map(int,line[1:])
James=set(James)


# In[9]:

James


# In[153]:

# the reference of the papers by James
C={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        i = line[0]
        refs=line[1:]
        if i in James:
            C[i]=refs


# In[204]:

C_=defaultdict(lambda:set([]))
for i in C:
    for j in C[i]:
        C_[j].add(i)
C_=dict(C_)


# In[161]:

# focal paper: unique set of refs 
F=set([i for j in C.values() for i in j])


# In[167]:

len(C),sum(map(len,C.values())),len(F)


# In[221]:

len([i for i in F if i in W])


# In[217]:

sorted([(W[i],Title[i].lower(),[Title[j].lower() for j in C_[i]]) for i in F if i in W])[:2]


# In[218]:

sorted([(W[i],Title[i].lower(),[Title[j].lower() for j in C_[i]]) for i in F if i in W])[-2:]


# # 2. The experiment of Dashun
# 

# In[ ]:

#41864029


# In[212]:

F1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        i = line[0]
        refs=line[1:]
        if i == 41864029:
            F1=refs
            break


# In[222]:

len(F1)


# In[219]:

sorted([(W[i],Title[i].lower()) for i in F1 if i in W])[:2]


# In[220]:

sorted([(W[i],Title[i].lower()) for i in F1 if i in W])[-2:]


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# ###  local disruption 

# In[170]:

# the reference of focal papers
R={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        i = line[0]
        if i in F:
            R[i]=line[1:]


# In[178]:

len(R),sum(map(len,R.values()))


# In[179]:

# unique set of refs
Z=set([i for j in R.values() for i in j])
len(Z)


# In[175]:

#finding focal paper by ref id, one ref id may link to many focal papers
R_=defaultdict(lambda:set([]))
for i in R:
    for j in R[i]:
        R_[j].add(i)
R_=dict(R_)


# In[176]:

len(R),len(F),len(Z),len(R_)


# In[192]:

# calculate local disruption 
D=defaultdict(lambda:[0,0,0])#n_dis,n_dev,n_ref
n=0
for i in C:
    ref=C[i]
    for f in ref:
        if f in R:
            if set(R[f]).intersection(ref):
                D[f][1]+=1
            else:
                D[f][0]+=1


# In[ ]:




# In[14]:




# In[15]:

len(UC),len(NW)


# In[19]:

UC1=defaultdict(lambda:[])
for k,v in UC.items():
    UC1[v].append(k)
NW1=defaultdict(lambda:[])
for k,v in NW.items():
    NW1[v].append(k)


# In[20]:

len(UC1),len(NW1)


# In[24]:




# In[25]:

len(A),len(B)


# In[29]:




# In[33]:

i='kmandal@uchicago.edu'
Y[sorted(A[i])[-1]]


# In[42]:

len(A1),len(B1)


# In[65]:

sorted([(len(v),k) for k,v in A1.items()],reverse=True)[230]


# In[69]:

i='jbergels@uchicago.edu'
V0=set(A1[i])


# In[70]:




# In[113]:

sum(map(len,R0.values()))


# In[86]:




# In[87]:




# In[91]:




# In[88]:

len(R1)


# In[90]:




# In[92]:

len(K1)


# In[93]:




# In[95]:

DD={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954 and int(Id) in R1:
            DD[int(Id)]=float(disruptive)


# In[ ]:




# In[ ]:




# In[ ]:




# In[104]:

DS={}
for i in R1:
    if i in DD and i in D:
        d0=DD[i]
        n1,n2,n3=D[i]
        d1=(n1-n2)/(n1+n2+n3+0.0)
        DS[i]=[d0,d1]


# In[105]:

x,y=np.array(DS.values()).T


# In[110]:

plt.plot(x,y,'bo')
plt.xlabel('global disruption')
plt.ylabel('local disruption')
plt.xlim(-0.5,1.1)
plt.ylim(-1.1,1.1)
plt.title('Joy Bergelson from UofC')


# In[117]:

sorted([(v[0],k)for k,v in DS.items()])[-3:]


# In[131]:

sorted([(v[0],k)for k,v in DS.items()])[:4]


# In[75]:

len(K),len(Z)


# In[119]:




# In[132]:

Title[24608970].lower()


# In[130]:

Title[16117572].lower()


# In[128]:

Title[17797692].lower()


# In[ ]:




# In[ ]:




# In[121]:

Title[1653708].lower()


# In[122]:

Title[6066710].lower()


# In[123]:

Title[13843373].lower()


# In[ ]:




# In[57]:

sum(map(len,A1.values())),np.median(map(len,A1.values()))


# In[58]:

sum(map(len,B1.values())),np.median(map(len,B1.values()))


# In[ ]:



