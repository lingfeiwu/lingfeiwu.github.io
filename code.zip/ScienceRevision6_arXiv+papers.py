
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
from openpyxl import load_workbook
from scipy import stats
import matplotlib.patches as patches
from os import listdir
from itertools import combinations
import matplotlib.gridspec as gridspec
import re

import sys
from collections import defaultdict
import numpy as np
import pylab as plt
import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
import json

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%s' % d)
    sys.stdout.flush()
    
def OLSRegressFit(x,y):
    xx = sm.add_constant(x, prepend=True)
    res = sm.OLS(y,xx).fit()
    constant, beta = res.params
    r2 = res.rsquared
    return beta,r2


# In[2]:

W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
                
                


# In[4]:

# papers
TT={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        TT[re.sub('[^A-Za-z0-9]+', ' ', line[1]).strip().lower()]=p


# In[6]:

PS={}
ap='/Users/lingfeiw/Documents/bigdata/arxiv2003/hep-th-abs/'
for year in range(1992,2004):
    flushPrint(year)
    path=ap+str(year)+'/'
    ps = [ f for f in listdir(path)]
    for i in ps:
        d=[]
        with open (path+i,'r') as f:
            for line in f:
                try:
                    if 'Title' in line:
                        title=line.strip().split(":")[1].strip()
                        title=re.sub('[^A-Za-z0-9]+', ' ', title).strip().lower()
                        if title in TT:
                            d.append(TT[title])
                    #if 'Authors' in line:
                    #    au=line.strip().split(":")[1].strip()
                    #    nau=len(au.split(','))+1
                    #    d.append(nau)
                    if 'Comments' in line:
                        if 'figure' in line:
                            d.append(line.strip().split(":")[1].strip())
                except:
                    pass
        if len(d)==2:
            PS[d[0]]=d[1]


# In[17]:

PS.items()[:5]


# In[7]:

PS3={}
for n in PS:
    s=PS[n]
    lst=[re.sub('[^A-Za-z0-9]+', ' ', i).strip().lower() for i in s.split(' ')]
    nf=''
    if 'figure' in lst and lst[lst.index('figure')-1]=='no':
        PS3[n]=0
    else:
        if 'figures' in lst and lst[lst.index('figures')-1]=='no':
            PS3[n]=0
        if 'figure' in lst:
            if lst[lst.index('figure')-1].isdigit():
                nf=lst[lst.index('figure')-1]
            else:
                if lst[lst.index('figure')-2].isdigit():
                    nf=lst[lst.index('figure')-2]
        else:
            if 'figures' in lst:
                if lst[lst.index('figures')-1].isdigit():
                    nf=lst[lst.index('figures')-1]
                else:
                    if lst[lst.index('figures')-2].isdigit():
                        nf=lst[lst.index('figures')-2]
        if nf.isdigit():
            PS3[n]=int(nf)


# In[8]:

len(PS),len(PS3)


# In[22]:

PS3.items()[:5]


# In[122]:

Wmp={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperImpactMedian.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,medianImp=line.strip().split('\t')
        Wmp[int(paper)]=float(medianImp)


# In[21]:

Counter([W[i][0] for i in PS3 if i in W])


# In[29]:

np.mean([W[i][0] for i in PS3 if i in W and PS3[i]==0])


# In[31]:

np.mean([W[i][0] for i in PS3 if i in W and 1<=PS3[i]<=3])


# In[32]:

np.mean([W[i][0] for i in PS3 if i in W and PS3[i]>3])


# In[ ]:




# In[129]:

DisruptionPaper=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            DisruptionPaper.append(float(disruptive))
DisruptionPaper=random.sample(DisruptionPaper,10000)
stats.percentileofscore(DisruptionPaper,0)


# In[10]:

a=0
b=0
for i in PS3:
    nf=PS3[i]
    if nf==0:
        a+=1
    if nf>0:
        b+=1
a,b


# In[ ]:




# In[210]:

#aggregate data by team size
disPaper1=defaultdict(lambda:defaultdict(lambda:[]))
impPaper1=defaultdict(lambda:defaultdict(lambda:[]))
depPaper1=defaultdict(lambda:defaultdict(lambda:[]))
popPaper1=defaultdict(lambda:defaultdict(lambda:[]))
for i in PS3:
    nf=PS3[i]
    if nf==0:
        n=0
    if 1<=nf<=3:
        n=1
    if nf>3:
        n=2
    if i in Wmp and i in W:
        teamsize,impact,disruption,timegap, meanimp1=W[i]
        disPaper1[n][teamsize].append(disruption)
        impPaper1[n][teamsize].append(impact) 
        depPaper1[n][teamsize].append(timegap)
        popPaper1[n][teamsize].append(Wmp[i])


# In[285]:

mp={0:'No figure',1:'1-3 figures',2:'>4 figures'}
cs={0:'SteelBlue',1:'ForestGreen',2:'Orange'}
fig = plt.figure(figsize=(10, 12),facecolor='white')
ax = fig.add_subplot(321)
for n in [0,1,2]:
    xdisPaper1,ydisPaper1=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1[n].items()])).T
    ydisPaper1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper1]
    plt.plot(xdisPaper1,ydisPaper1,color=cs[n],label=mp[n],linewidth=2)
plt.xlim(1,5)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.legend(loc=2,numpoints=1,fontsize=12,frameon=False)
ax.set_xticks(range(1,6))
#
ax = fig.add_subplot(322)
for n in [0,1,2]:
    ximpPaper1,yimpPaper1=np.array(sorted([(k,np.mean(v)) for k,v in impPaper1[n].items()])).T
    plt.plot(ximpPaper1,yimpPaper1,color=cs[n],label=mp[n],linewidth=2)
plt.xlim(1,5)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel('Citations',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.legend(loc=2,numpoints=1,fontsize=12,frameon=False)
ax.set_xticks(range(1,6))
#
ax = fig.add_subplot(323)
for n in [0,1,2]:
    xdepPaper1,ydepPaper1=np.array(sorted([(k,np.mean(v)) for k,v in depPaper1[n].items()])).T
    plt.plot(xdepPaper1,ydepPaper1,color=cs[n],label=mp[n],linewidth=2)
plt.xlim(1,5)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel('Reference age',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.legend(loc=2,numpoints=1,fontsize=12,frameon=False)
ax.set_xticks(range(1,6))
#
ax = fig.add_subplot(324)
for n in [0,1,2]:
    xpopPaper1,ypopPaper1=np.array(sorted([(k,np.median(v)) for k,v in popPaper1[n].items()])).T
    plt.plot(xpopPaper1,ypopPaper1,color=cs[n],label=mp[n],linewidth=2)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.legend(loc=2,numpoints=1,fontsize=12,frameon=False)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel('Reference popularity',fontsize=20)
ax.set_xticks(range(1,6))
plt.xlim(1,5)
#
ax = fig.add_subplot(325)
x,y=np.array(sorted(Counter([W[i][0] for i in PS3 if i in W]).items())).T
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel('Frequency',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.fill_between(x,y,color='SteelBlue',alpha=0.2)
plt.plot(x,y,color='RoyalBlue')
plt.xlim(1,10)
#
ax = fig.add_subplot(326)
ax = fig.add_subplot(326)
x,y=np.array(sorted(Counter(PS3.values()).items())).T
plt.xlabel('N of figures',fontsize=20)
plt.ylabel('Frequency',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.fill_between(x,y,color='Chocolate',alpha=0.2)
plt.plot(x,y,color='Orange')
plt.xlim(0,20)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/arXiv.pdf')


# In[286]:

len(PS3)


# In[ ]:



