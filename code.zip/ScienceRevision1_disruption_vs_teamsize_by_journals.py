
# coding: utf-8

# In[3]:

get_ipython().magic(u'matplotlib inline')
import sys
from scipy import stats
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

def log2linearBin(x,y):
    x=[np.round(i,0) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(np.round(np.exp2(i),0),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(sorted(newlist)).T
    return nx,ny

def log2linearBinInt(x,y):
    x=[int(i) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(int(np.exp2(i)),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(newlist).T
    return nx,ny

# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in sorted(dic.keys()):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b

def DiffusionWeightAverage(threshold,data):#[value,samplesize] in data
    smoothData=[data[0]]
    for n,j in enumerate(data[1:]):
        value,sampleSize=j
        if sampleSize<threshold:
            lastValue,lastSampleSize=smoothData[n-1]
            value=np.average([lastValue,value], weights=[lastSampleSize, sampleSize])
        smoothData.append([value,sampleSize])
    return smoothData

def OLSRegressFit(x,y):
    xx = sm.add_constant(x, prepend=True)
    res = sm.OLS(y,xx).fit()
    constant, beta = res.params
    return beta


# In[21]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>=3 and int(year)>=1954:
            subject=int(subject)
            if subject not in [7,8,9,11]:
                if subject ==2:
                    subject=13
                W1[int(Id)]=[int(teamsize),float(disruptive)]
            
PaperToSubject={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperSubject.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        PaperToSubject[line[0]]=line[1:]
        
n=0
PaperToJournal={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperJournal.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        PaperToJournal[line[0]]=line[1]
        
SubjectData=defaultdict(lambda:defaultdict(lambda:[]))
for p in PaperToSubject:
    if p in W1:
        ts,dis=W1[p]
        for s in PaperToSubject[p]:
            SubjectData[s][ts].append(dis)
            
JournalData=defaultdict(lambda:defaultdict(lambda:[]))
for p in PaperToJournal:
    if p in W1:
        ts,dis=W1[p]
        j=PaperToJournal[p]
        JournalData[j][ts].append(dis)
        
SubjectofJournals=defaultdict(lambda:set([]))
n=0
for p in PaperToSubject:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if p in PaperToJournal:
        j=PaperToJournal[p]
        for s in PaperToSubject[p]:
            if j not in SubjectofJournals[s]:
                SubjectofJournals[s].add(j)
        


# In[5]:

# team size distribution across subfields

SubjectDist=defaultdict(lambda:defaultdict(lambda:0))
n=0
for p in PaperToSubject:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if p in W1:
        ts,dis=W1[p]
        for s in PaperToSubject[p]:
            SubjectDist[s][ts]+=1


# In[19]:

tss=[]
for s in SubjectDist:
    if len(SubjectDist[s])>=7:
        x,y=np.array(sorted(SubjectDist[s].items())).T
        y=y/float(y.sum())
        size=sum(x*y)
        tss.append([size,s])
tss=sorted(tss)


# In[22]:

ss=zip(*tss)[1]
len(ss)


# In[27]:

fig = plt.figure(figsize=(10, 5),facecolor='white')
ax = fig.add_subplot(121)
cmap = cm.get_cmap('rainbow',len(ss))
for s in ss:
    if len(SubjectDist[s])>=7:
        x,y=np.array(sorted(SubjectDist[s].items())).T
        y=y/float(y.sum())
        plt.plot(x,y,color=cmap(ss.index(s)),alpha=0.3)
plt.xlim(1,10)
plt.xlabel('Team size',size=20)
plt.ylabel('Probability',size=20)
#
ax = fig.add_subplot(122)
for s in SubjectDist:
    if len(SubjectDist[s])>=7:
        x,y=np.array(sorted(SubjectDist[s].items())).T
        y=y/float(y.sum())
        plt.plot(x,y,color=cmap(ss.index(s)),alpha=0.3)
plt.xscale('log')
plt.yscale('log')
plt.xlabel('Team size',size=20)
plt.ylabel('Probability',size=20)
plt.ylim(10**-6,1)
#
plt.tight_layout()


# In[ ]:




# In[ ]:




# In[22]:

JournalName={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        JournalName[int(line[0])]=line[1]

SubjectName={}
NameSubject={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/subject.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        SubjectName[int(line[0])]=line[1]
        NameSubject[line[1]]=int(line[0])
        
FieldName={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}
        
SubjectToField={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/fields.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        SubjectToField[int(line[0])]=line[1]
        
FieldOfSubject=defaultdict(lambda:set([]))
for s in SubjectToField:
    f = SubjectToField[s]
    FieldOfSubject[f].add(s)


# In[23]:

Disruptive=[v[-1] for v in W1.values()]
drss=random.sample([v[-1] for v in W1.values()],1000)
stats.percentileofscore(drss, 0) 


# # by Subject

# In[24]:

disSubject={}
for s in SubjectData:
    ds=[]
    for k in range(1,11):
        #if len(SubjectData[s][k])>=1000:#enough data points at each team size
        if len(SubjectData[s][k])>=3:
            md=np.mean(SubjectData[s][k])
            md=stats.percentileofscore(drss, md)
            ds.append([k,md,len(SubjectData[s][k])])
    if len(ds)==10:#enough data points at all team sizes
        disSubject[s]=ds


# In[25]:

len(disSubject)


# In[10]:

names=['Immunology','Physical Geography',
'Engineering, Civil','Anesthesiology','Agronomy','Mathematics, Interdisciplinary Applications',
'Polymer Science','Crystallography','Biomedical Social Sciences','Economics','Computer Science, Artificial Intelligence']

FieldColors={'Physical sciences':'#39B2A3','Biology':'#800000','Medicine':'#FF1400',    'Environmental and earth sciences':'#FF7D00',    'Chemistry':'#C69C6D','Agriculture':'#79BA3A','Social sciences':'#0070B5',    'Engineering':'#ABC7D6','Computer and information technology':'#B3B3B3',
             'Business and management':'k','Mathematics':'#773000'}


# In[11]:

FieldColors1={'Physical sciences':'#800000','Biology':'#FF1400','Medicine':'#FF7D00',    'Environmental and earth sciences':'#C69C6D',    'Chemistry':'#79BA3A','Agriculture':'#39B2A3','Social sciences':'#0070B5',    'Engineering':'#ABC7D6','Computer and information technology':'#B3B3B3'}


# In[8]:

s=NameSubject['Mathematics, Interdisciplinary Applications']
for j in SubjectofJournals[s]:
    if random.random()<0.1:
        print JournalName[j].lower()


# In[10]:

len(SubjectData)


# In[27]:

# smooth exmaple
#
fig = plt.figure(figsize=(5, 15),facecolor='white')
ax = fig.add_subplot(311)
subjectNumber=205
data=disSubject[subjectNumber]
x,y,z=np.array(data).T
threshold=sum(z)*0.01
smoothData=DiffusionWeightAverage(threshold,zip(y,z))
y1,z1=np.array(smoothData).T
plt.plot(x,y,linestyle='--',color='RoyalBlue',label='No smoothing')
plt.scatter(x,y,s=z/50.0,alpha=0.3)
plt.plot(x,y1,'r-',label='1% tail smoothing')
#plt.scatter(x,y1,s=z/50.0,color='r',alpha=0.3)
plt.xlim(0,10)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption percentile',fontsize=20)
#plt.text(2,86,'Artificial Intelligence',fontsize=14)
plt.legend(loc=3,frameon=False)
plt.yticks([80,82,84,86,88,90])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(312)
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    if f in FieldColors1:
        c=FieldColors1[f]
        data=disSubject[s]
        x,y,z=np.array(data).T
        threshold=sum(z)*0.0
        smoothData=DiffusionWeightAverage(threshold,zip(y,z))
        y1,z1=np.array(smoothData).T
        plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
                 linewidth=2,color=c)        
plt.xlabel('team size',fontsize=20)
plt.text(2,25,'1% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(313)
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    if f in FieldColors1:
        c=FieldColors1[f]
        data=disSubject[s]
        x,y,z=np.array(data).T
        threshold=sum(z)*0.2
        smoothData=DiffusionWeightAverage(threshold,zip(y,z))
        y1,z1=np.array(smoothData).T
        plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
                 linewidth=2,color=c)        
plt.xlabel('team size',fontsize=20)
plt.text(2,25,'20% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_Smooth.pdf')


# In[ ]:




# In[28]:

# smooth exmaple
#
fig = plt.figure(figsize=(5, 10),facecolor='white')
ax = fig.add_subplot(311)
subjectNumber=205
data=disSubject[subjectNumber]
x,y,z=np.array(data).T
threshold=sum(z)*0.01
smoothData=DiffusionWeightAverage(threshold,zip(y,z))
y1,z1=np.array(smoothData).T
plt.plot(x,y,linestyle='--',color='RoyalBlue',label='No smoothing')
plt.scatter(x,y,s=z/50.0,alpha=0.3)
plt.plot(x,y1,'r-',label='1% tail smoothing')
#plt.scatter(x,y1,s=z/50.0,color='r',alpha=0.3)
plt.xlim(0,10)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption percentile',fontsize=20)
#plt.text(2,86,'Artificial Intelligence',fontsize=14)
plt.legend(loc=3,frameon=False)
plt.yticks([80,82,84,86,88,90])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(312)
n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.01
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.xlabel('team size',fontsize=20)
plt.text(2,25,'1% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(313)
n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.2
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.xlabel('team size',fontsize=20)
plt.text(2,25,'20% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_Smooth.pdf')


# In[ ]:




# In[16]:

# smooth exmaple
#
fig = plt.figure(figsize=(10, 10),facecolor='white')
ax = fig.add_subplot(221)
subjectNumber=205
data=disSubject[subjectNumber]
x,y,z=np.array(data).T
threshold=sum(z)*0.01
smoothData=DiffusionWeightAverage(threshold,zip(y,z))
y1,z1=np.array(smoothData).T
plt.plot(x,y,'b--',label='No smoothing')
plt.scatter(x,y,s=z/50.0,alpha=0.3)
plt.plot(x,y1,'r-',label='1% tail smoothing')
plt.scatter(x,y1,s=z/50.0,color='r',alpha=0.3)
plt.xlim(0,10)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption percentile',fontsize=20)
plt.text(2,86,'Artificial Intelligence',fontsize=14)
plt.legend(loc=3,frameon=False)
plt.yticks([81,83,85,87])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(222)
n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    #smoothData=DiffusionWeightAverage(1000,zip(y,z))
    #y1,z1=np.array(smoothData).T
    plt.plot(x,y,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption percentile',fontsize=20)
plt.text(2,25,'No smoothing',fontsize=14)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(223)
n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.01
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.xlabel('team size',fontsize=20)
plt.text(2,25,'1% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(224)
n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.2
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.xlabel('team size',fontsize=20)
plt.text(2,25,'20% tail smoothing',fontsize=14)
plt.ylabel('Disruption percentile',fontsize=20)
plt.yticks([20,40,60,80,100])
plt.xticks([2,4,6,8,10])
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/smooth.pdf')


# In[274]:

fig = plt.figure(figsize=(5,5),facecolor='white')
ax = fig.add_subplot(111)
cmap = cm.get_cmap('jet_r',10)

n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.01
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.tick_params(axis='both', which='major', labelsize=14)

ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.set_xticklabels('')
ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/bySubject.pdf')


# In[296]:

for i in names:
    s=NameSubject[i]
    v=[]
    for ts in SubjectData[s]:
        v+=SubjectData[s][ts]
    print i,np.round(stats.percentileofscore(drss, np.mean(v)))


# In[309]:

fig = plt.figure(figsize=(15,3),facecolor='white')
ax = fig.add_subplot(111)
cmap = cm.get_cmap('jet_r',10)

n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=disSubject[s]
    x,y,z=np.array(data).T
    threshold=sum(z)*0.01
    smoothData=DiffusionWeightAverage(threshold,zip(y,z))
    y1,z1=np.array(smoothData).T
    plt.plot(x,y1,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.tick_params(axis='both', which='major', labelsize=14)

for i in range(10):
    for j in range(9):
        plt.plot([i+j/10.0,i+j/10.0],[20,100],'k-')

ax.set_xlim(1,10)
ax.set_ylim(20,100)
ax.set_yticks([20,40,60,80,100])
plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)
plt.tight_layout()


# In[ ]:




# In[ ]:




# # by journal

# In[11]:

disSubjectJournal={}
for sub in SubjectofJournals:
    flushPrint(sub)
    dis={}
    for j in SubjectofJournals[sub]:
        ds=[]
        for k in range(1,11):
            if len(JournalData[j][k])>=3:
                md=np.mean(JournalData[j][k])
                md=stats.percentileofscore(drss, md)
                ds.append([k,md,len(JournalData[j][k])])
        if len(ds)==10:#enough data points at all team sizes
            dis[j]=ds
    if dis:
        disSubjectJournal[sub]=dis


# In[12]:

len(disSubjectJournal)


# In[18]:

sum([len(disSubjectJournal[i]) for i in disSubjectJournal])


# In[ ]:




# In[15]:

for k,v in FieldColors.items():
    subs=FieldOfSubject[k]
    sortedSubs=zip(*sorted([[len(SubjectofJournals[s]),s] for s in subs                             if s in disSubjectJournal])[::-1])[1]
    print k,len(sortedSubs)


# In[16]:

len(disSubjectJournal)


# ### Nagtive slope at journal level

# In[12]:

journalPositiveBeta={}
journalNegativeBeta={}
journalRdata={}
for sub in disSubjectJournal:
    for j in disSubjectJournal[sub]:
        paperN=sum(map(len,JournalData[j].values()))
        if paperN>=3000:
            data=disSubjectJournal[sub][j]
            x,y,z=np.array(data).T
            co,pvalue=pearsonr(x,y)
            journalRdata[j]=[x,y]
            if pvalue<0.05:
                if co>0:
                    journalPositiveBeta[j]=co
                else:
                    journalNegativeBeta[j]=co


# In[59]:

#all data
a=len(journalPositiveBeta)
b=len(journalNegativeBeta)
a,b,b/(a+b+0.0)


# In[63]:

#paperN>1000
a=len(journalPositiveBeta)
b=len(journalNegativeBeta)
a,b,b/(a+b+0.0)


# In[71]:

#paperN>3000
a=len(journalPositiveBeta)
b=len(journalNegativeBeta)
a,b,b/(a+b+0.0)


# In[ ]:




# In[ ]:




# In[17]:

import re 
from operator import itemgetter

s='Audiology & Speech-Language Pathology'

def split(s):
    l=len(s)
    ids=np.array([i for i, letter in enumerate(s) if letter == ' '])
    ls=np.abs(ids-l/2)
    minl=min(enumerate(ls), key=itemgetter(1))[0]
    return ids[minl]


# In[2]:

f='biology'
subs=FieldOfSubject[f]
sortedSubs=zip(*sorted([[len(SubjectofJournals[s]),s] for s in subs if s in disSubjectJournal])[::-1])[1]


# In[ ]:




# In[98]:

#f='Multidisciplinary Sciences' #colorf='purple'
#colorf=FieldColors[f]
subs=FieldOfSubject[f]
sortedSubs=zip(*sorted([[len(SubjectofJournals[s]),s] for s in subs if s in disSubjectJournal])[::-1])[1]
plotdata={}
for sub in sortedSubs:
    bs=[]
    for j in disSubjectJournal[sub]:
        data=disSubjectJournal[sub][j]
        x,y,z=np.array(data).T
        threshold=sum(z)*0.2
        smoothData=DiffusionWeightAverage(threshold,zip(y,z))
        y1,z1=np.array(smoothData).T
        beta=OLSRegressFit(x,y1)
        size=sum(map(len,JournalData[j].values()))
        bs.append([beta,size,[x,y1]])
    plotdata[sub]=bs

fig = plt.figure(figsize=(12,12),facecolor='white')
axs={}
for i in range(32):
    ax = fig.add_subplot(8,4,i+1)
    #ax.tick_params(axis='both', which='major', labelsize=14)
    axs[i]=ax
#for i in range(32): #medcine 1
#for i in range(32,len(sortedSubs)):#medcine 2
for i in range(len(sortedSubs)):
    sub=sortedSubs[i]
    bs=plotdata[sub]
    #ax=axs[i-32] #medcine 2
    ax=axs[i]
    title=SubjectName[sub]
    if len(title)>25:
        index=split(title)
        title = title[:index]+' \n '+title[index:]
        ax.set_title(title,fontsize=12)
    else:
        title=' \n '+title
        ax.set_title(title,fontsize=12)
    ax.set_ylim(20,100)
    ax.set_xlim(1,10)
    ax.set_yticks([20,40,60,80,100])
    ax.set_yticklabels([20,40,60,80,100], rotation=45,va='baseline')
    ax.set_xticks([2,4,6,8,10])
    ax.plot([1,10],[70,70],color='gray',linestyle='--')
    maxbeta=max(np.abs([i[0] for i in bs]))
    for beta, size,dd in sorted(bs,key=lambda x:-x[0]):#more negative beta comes later
        xs,ys=dd
        a=np.abs(beta)/maxbeta
        b=np.log(size)/13.2
        k=a*b
        #if len(bs)<5:
        #    k=0.3
        ax.plot(xs,ys,color=colorf,alpha=k+0.1,linewidth=k)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/'+f+'.pdf')


# In[ ]:




# In[528]:

for  i in sortedSubs[32:]:
    print SubjectName[i]


# In[547]:

len('Psychology, Multidisciplinary')


# In[545]:

Abbreviate


# In[ ]:




# In[ ]:




# # sleeping beauty 

# In[590]:

S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[593]:

#aggregate data by team size
slepSubjectData=defaultdict(lambda:defaultdict(lambda:[]))
for p in S1:
    if p in W1 and p in PaperToSubject:
        ts,dis=W1[p]
        sle=S1[p]
        for s in PaperToSubject[p]:
            slepSubjectData[s][ts].append(sle)


# In[599]:

sleepSample=random.sample(S1.values(),1000)


# In[604]:

slepSubject={}
for s in SubjectData:
    ds=[]
    for k in range(1,11):
        if len(slepSubjectData[s][k])>=3:
            md=np.mean(slepSubjectData[s][k])
            md=stats.percentileofscore(sleepSample, md)
            ds.append([k,md,len(slepSubjectData[s][k])])
    if len(ds)==10:#enough data points at all team sizes
        slepSubject[s]=ds


# In[606]:

names


# In[608]:

fig = plt.figure(figsize=(5,5),facecolor='white')
ax = fig.add_subplot(111)
cmap = cm.get_cmap('jet_r',10)

n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=slepSubject[s]
    x,y,z=np.array(data).T
    plt.plot(x,y,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.tick_params(axis='both', which='major', labelsize=14)

ax.set_xlim(1,10)
ax.set_ylim(40,100)
ax.set_yticks([40,60,80,100])
#plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
#ax.set_xticklabels('')
#ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/bySubject.pdf')


# In[609]:

fig = plt.figure(figsize=(5,5),facecolor='white')
ax = fig.add_subplot(111)
cmap = cm.get_cmap('jet_r',10)

n=0
for i in names:
    s=NameSubject[i]
    f=SubjectToField[s]
    c=FieldColors[f]
    data=slepSubject[s]
    x,y,z=np.array(data).T
    plt.plot(x,y,linestyle='-',alpha=(1-n/11.0)*0.7,marker='',
             linewidth=2,color=c)        
    n+=1
plt.tick_params(axis='both', which='major', labelsize=14)

ax.set_xlim(1,10)
ax.set_ylim(40,100)
ax.set_yticks([40,60,80,100])
#plt.plot([1,10],[70.6,70.6],'k--',alpha=0.3)


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.set_xticklabels('')
ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/slepBeauty.pdf')


# In[610]:

for i in names:
    s=NameSubject[i]
    v=[]
    for ts in slepSubjectData[s]:
        v+=slepSubjectData[s][ts]
    print i,np.round(stats.percentileofscore(sleepSample, np.mean(v)))


# In[ ]:




# In[ ]:




# In[ ]:




# In[209]:




# In[221]:

#mean
xslePaper,yslePaper=np.array(sorted([(k,np.mean(v)) for k,v in slePaper.items()])).T


# In[214]:

# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,11):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b

def log2linearBin(x,y):
    x=[np.round(i,0) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(np.round(np.exp2(i),0),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(sorted(newlist)).T
    return nx,ny


# In[217]:

sleepSample=random.sample(S1.values(),10000)


# In[223]:

# CI
yslePaperCIa,yslePaperCIb=calculateCI(slePaper,'mean',50)

#log
xslePaperlog,yslePaperlog=log2linearBin(xslePaper,yslePaper)


# In[230]:

plt.plot(xslePaper,yslePaper)


# In[228]:

#percentile
yslePaper1=[stats.percentileofscore(sleepSample,i) for i in yslePaper]
yslePaperCIa1=[stats.percentileofscore(sleepSample,i) for i in yslePaperCIa]
yslePaperCIb1=[stats.percentileofscore(sleepSample,i) for i in yslePaperCIb]
yslePaperlog1=[stats.percentileofscore(sleepSample,i) for i in yslePaperlog]


# In[237]:

fig = plt.figure(figsize=(5,5),facecolor='white')
plt.plot(xslePaper,yslePaper1)
plt.ylim(60,100)
plt.yticks([60,70,80,90,100])
plt.xlim(1,10)
plt.fill_between(range(1,11), yslePaperCIa1,yslePaperCIb1,color='gray',alpha=0.15)



# In[262]:

fig = plt.figure(figsize=(5,5),facecolor='white')
ax = fig.add_subplot(111)
plt.plot(xslePaper,yslePaper1,color='RoyalBlue')
plt.ylim(60,100)
plt.yticks([60,70,80,90,100])
plt.xlim(1,10)
plt.fill_between(range(1,11), yslePaperCIa1,yslePaperCIb1,color='gray',alpha=0.7)

ax.tick_params(axis='x', which='both',bottom='on',top='off')

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.set_xticklabels('')
ax.set_yticklabels('')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig3.3.1.new.pdf')


# In[ ]:




# In[ ]:



