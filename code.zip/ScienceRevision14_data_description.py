
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# # WoS data

# In[ ]:




# In[2]:

# number of papers
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436


# In[3]:

n


# In[8]:

# get years
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        doi,ndoi,year=line.strip().split('\t')
        Y[int(ndoi)]=int(year)


# In[9]:

len(Y)


# In[24]:

#number of papers cited
n=0
C=defaultdict(int)
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        for j in line[1:]:
            C[j]+=1


# In[25]:

len(C)


# In[26]:

28607001/43661387.0


# In[13]:

# directed acyclic graph
n=0
m=0# number of citations
a=0# number of citations to future
b=0# number of citations of same year
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        m+=len(line)-1
        p=line[0]
        yi=Y[p]
        for j in line[1:]:
            yj=Y[j]
            if yj>yi:
                a+=1
            if yj==yi:
                b+=1


# In[14]:

n,m,a,b


# In[23]:

100*43724/615697434.0


# In[21]:

11847128/615697434.0


# In[58]:

# dongbo Chinese scholar data
d=[]
w=[]
p=[]
with open('/Users/lingfeiw/Dropbox/truth.csv','rb') as f:
    for line in f:
        line=line.strip().split(',')
        idp=line[0].split('"')[1]
        ids=line[3].split('"')[1]
        if idp.isdigit():
            d.append(int(idp))
        if ids.isdigit():
            w.append(int(ids))


# In[59]:

len(set(d))


# In[60]:

len(set(w))


# In[46]:

line


# In[50]:

line[3].split('"')[1]


# In[ ]:



