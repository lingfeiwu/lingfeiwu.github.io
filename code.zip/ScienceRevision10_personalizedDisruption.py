
# coding: utf-8

# In[12]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    


# In[87]:

#institutions of papers
Z={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/authorlistOrg1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#65
        line=line.strip().split('\t')
        idx=int(line[0])
        v=[i.lower() for i in line[1:]]
        names=[j.split(',')[0] for j in v[0::2]]
        institutions=v[1::2]
        Z[idx]=dict(zip(names,institutions))        


# In[117]:

#emails of papers
E={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/authorlistemail1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#65
        line=line.strip().split('\t')
        idx=int(line[0])
        emails=line[1:][1::2]
        if [j for j in emails if j!='?']:
            names=[j.split(',')[0].lower() for j in line[1:][0::2]]
            E[idx]=dict(zip(names,emails))    


# In[75]:

#institutions of authors
U=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        a=line[0]
        i=a.split(',')[0].lower()
        v=map(int,line[1:])
        for j in v:
            if j in Z and i in Z[j]:
                u=Z[j][i]
                U[a][u]+=1


# In[133]:

#emails of authors
UE=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        a=line[0]
        i=a.split(',')[0].lower()
        v=map(int,line[1:])
        for j in v:
            if j in E and i in E[j]:
                e=E[j][i]
                if e!='?':
                    UE[a][e]+=1


# In[138]:

UE=dict(UE)
U=dict(U)


# In[139]:

UE['LOPEZ, MR+3'],U['LOPEZ, MR+3']


# In[144]:

users=set([])
for i in U:
    if i not in users:
        users.add(i)
for i in UE:
    if i not in users:
        users.add(i)


# In[145]:

len(UE),len(U),len(users)


# In[164]:

# export institutions and emails
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorInstEmail.txt', "wb") as f:
    for i in users:
        if i in U:
            vs='__'.join([a+'_'+str(b) for a,b in sorted(U[i].items(),key=lambda x:-x[1])])
        else:
            vs='None'
        if i in UE:
            es='__'.join([a+'_'+str(b) for a,b in sorted(UE[i].items(),key=lambda x:-x[1])])
        else:
            es='None'
        f.write(str(i)+'\t'+vs+'\t'+ es + '\n')


# In[ ]:



