
# coding: utf-8

# In[99]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax


# In[2]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(teamsize),float(disruptive)]


# In[6]:

# papers
R=defaultdict(lambda:[0,0])#no mention 'resource' vs mention resource
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in W:
                m=W[p][0]
                if 'resource' in line[1].lower():
                    R[m][1]+=1
                else:
                    R[m][0]+=1


# In[8]:

def log2linearBin(x,y):
    x=[np.round(i,0) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(np.round(np.exp2(i),0),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(sorted(newlist)).T
    return nx,ny


# In[9]:

x,y=np.array(sorted([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in R.items()])).T


# In[11]:

x1,y1=log2linearBin(x,y)


# In[19]:

plt.plot(x1,y1)
plt.xscale('log')
plt.xlim(1,100)
plt.ylim(0,0.03)


# In[34]:

# papers
R=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#523
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in W:
                m=W[p][0]
                if 'resource' in line[1].lower():
                    R.add(p)


# In[37]:

W1={}# nonresource articles
W2={}# resource articles
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            if int(Id) in R:
                W2[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
            else:
                W1[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
                
                


# In[38]:

len(W1),len(W2)


# In[55]:

154734/(24010715+154734+0.0)


# In[ ]:




# In[1]:

24010715+154734


# In[39]:

DisruptionPaper=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            DisruptionPaper.append(float(disruptive))
DisruptionPaper=random.sample(DisruptionPaper,10000)


# In[40]:

from scipy import stats


# In[41]:

stats.percentileofscore(DisruptionPaper,0)


# In[42]:

#aggregate data by team size
disPaper1=defaultdict(lambda:[])
impPaper1=defaultdict(lambda:[])
for i in W1:
    teamsize,impact,disruption,timegap, meanimp1=W1[i]
    disPaper1[teamsize].append(disruption)
    impPaper1[teamsize].append(impact)
        


# In[44]:

#aggregate data by team size
disPaper2=defaultdict(lambda:[])
impPaper2=defaultdict(lambda:[])
for i in W2:
    teamsize,impact,disruption,timegap, meanimp1=W2[i]
    disPaper2[teamsize].append(disruption)
    impPaper2[teamsize].append(impact)


# In[45]:

xdisPaper1,ydisPaper1=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1.items()])).T
ydisPaper1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper1]
ximpPaper1,yimpPaper1=np.array(sorted([(k,np.mean(v)) for k,v in impPaper1.items()])).T
xdisPaper2,ydisPaper2=np.array(sorted([(k,np.mean(v)) for k,v in disPaper2.items()])).T
ydisPaper2=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper2]
ximpPaper2,yimpPaper2=np.array(sorted([(k,np.mean(v)) for k,v in impPaper2.items()])).T


# In[55]:

fig = plt.figure(figsize=(12,5))
ax = fig.add_subplot(121)
plt.plot(x,y,marker='o',color='SteelBlue')
plt.xlim(1,30)
plt.ylim(0,0.03)
plt.yticks(np.arange(0, 0.04, 0.01))
plt.xlabel('team size',size=18)
plt.ylabel(" 'resource' mention probability",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
subax = add_subplot_axes(ax,[0.1,0.7,0.3,0.3])
subax.plot(x1,y1,marker='^',color='RoyalBlue')
plt.xscale('log')
plt.xlim(1,100)
plt.ylim(0,0.03)
subax.tick_params(axis='both', which='major', labelsize=12)
plt.yticks(np.arange(0, 0.04, 0.01))

#
#plt.show()

ax = fig.add_subplot(122)
plt.plot(xdisPaper1,ydisPaper1,marker='o', label="Without mentioning 'resource'",color='RoyalBlue')
plt.plot(xdisPaper2,ydisPaper2,marker='s', label="mentioning 'resource'",color='#117733')
ax.set_xlim(1, 30)
ax.set_yticks([20,40,60,80,100])
ax.tick_params(axis='both', which='major', labelsize=12)
ax.tick_params(axis='both', which='major', labelsize=12)
plt.legend(loc=3,numpoints=1)
plt.xlabel('team size',size=18)
plt.ylabel("Disruption percentile",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)

plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures5/resource.pdf')


# # multidisciplinary journals

# In[56]:

W1={}# nonresource articles
N={}
S={}
P={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            if int(subject)==11:
                W1[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
            if int(journal)==22:#nature
                N[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
            if int(journal)==432:#science
                S[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]                
            if int(journal)==77:#pnas
                P[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]                  


# In[57]:

disPaperW1=defaultdict(lambda:[])
disPaperN=defaultdict(lambda:[])
disPaperS=defaultdict(lambda:[])
disPaperP=defaultdict(lambda:[])
for i in W1:
    teamsize,impact,disruption,timegap, meanimp1=W1[i]
    disPaper1[teamsize].append(disruption)
for i in N:
    teamsize,impact,disruption,timegap, meanimp1=N[i]
    disPaperN[teamsize].append(disruption)
for i in S:
    teamsize,impact,disruption,timegap, meanimp1=S[i]
    disPaperS[teamsize].append(disruption) 
for i in P:
    teamsize,impact,disruption,timegap, meanimp1=P[i]
    disPaperP[teamsize].append(disruption) 
    
xdisPaper1,ydisPaper1=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1.items()])).T
ydisPaper1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper1]
xdisPaperN,ydisPaperN=np.array(sorted([(k,np.mean(v)) for k,v in disPaperN.items()])).T
ydisPaperN=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperN]
xdisPaperS,ydisPaperS=np.array(sorted([(k,np.mean(v)) for k,v in disPaperS.items()])).T
ydisPaperS=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperS]
xdisPaperP,ydisPaperP=np.array(sorted([(k,np.mean(v)) for k,v in disPaperP.items()])).T
ydisPaperP=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperP]


# In[67]:

fig = plt.figure(figsize=(12,5))
ax = fig.add_subplot(121)
x,y=np.array(TS.items()).T
y=y/float(y.sum())
plt.plot(x,y,marker='^',linestyle='--',label='Population')
x1,y1=np.array(Counter([v[0] for v in W1.values()]).items()).T
y1=y1/float(y1.sum())
plt.plot(x1,y1,'r-',label='Multidisciplinary Sciences')
plt.xlim(1,20)
plt.legend(loc=1,numpoints=1)
plt.xlabel('team size',size=18)
plt.ylabel("Probability",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(122)
plt.plot(xdisPaper1,ydisPaper1,marker='o', label='Multidisciplinary Sciences',color='Orange')
plt.plot(xdisPaperN,ydisPaperN,marker='^', label="Nature",color='#117733')
plt.plot(xdisPaperS,ydisPaperS,marker='s', label="Science",color='RoyalBlue')
plt.plot(xdisPaperP,ydisPaperP,marker='v', label="PNAS",color='pink')
ax.set_xlim(1, 30)
ax.set_yticks([20,40,60,80,100])
ax.tick_params(axis='both', which='major', labelsize=12)
plt.legend(loc=1,numpoints=1)
plt.xlabel('team size',size=18)
plt.ylabel("Disruption percentile",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)

plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures5/multi.png')


# In[68]:

len(N),len(S),len(P)


# In[ ]:

95816, 58524, 99983


# In[58]:

n=0
TS=defaultdict(lambda:0)# population
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            TS[int(teamsize)]+=1     


# In[ ]:




# In[89]:

len(W1)


# In[90]:

536727/(24010715+154734+0.0)


# # do people go back to small teams from big teams

# In[101]:

A=defaultdict(lambda:defaultdict(lambda:{}))
n=0
#with open('/data/lingfei/rawAuthorEmailPaperWOS.txt', "r") as f:
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationOrgEmail2362976.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            #print(n/100000)#154
            flushPrint(n/100000)#154
        line=line.strip().split('\t')
        if len(line)>=11:
            A[line[0]]=map(int,line[1:])


# In[102]:

len(A)


# In[4]:

len(A)


# In[103]:

#1.year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[104]:

T={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/teamsize1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        doi, size=map(int,line.strip().split('\t'))
        if doi in Y and size>=1:
            T[doi]=size


# In[105]:

len(T),len(Y)


# In[106]:

U=random.sample(A.keys(),10)


# In[75]:

import statsmodels.api as sm


# In[76]:

def OLSRegressFit(x,y):
   xx = sm.add_constant(x, prepend=True)
   res = sm.OLS(y,xx).fit()
   constant, beta = res.params
   r2 = res.rsquared
   return [constant, beta, r2]


# In[77]:

len(A)


# In[78]:

BT=defaultdict(lambda:0)
n=0
for name in A:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    ys=[Y[i] for i in A[name] if i in Y]
    if len(np.unique(ys))>=3:
        firstYear=min(ys)
        x,y=np.array(sorted([(Y[i]-firstYear,T[i]) for i in A[name] if i in Y and i in T])).T
        constant, beta, r2=OLSRegressFit(x,y)
        if r2>0.5:
            BT[np.round(beta,1)]+=1


# In[87]:

U


# In[79]:

len(BT)


# In[ ]:




# In[91]:

fig = plt.figure(figsize=(12,5))
ax = fig.add_subplot(121)
cmap = cm.get_cmap('rainbow',10)
for name in U:
    firstYear=min([Y[i] for i in A[name] if i in Y])
    x,y=np.array(sorted([(Y[i]-firstYear,T[i]) for i in A[name] if i in Y and i in T])).T
    D=defaultdict(lambda:[])
    for i,j in zip(x,y):
        D[i].append(j)
    x,y=np.array(sorted([(k,np.mean(v)) for k,v in D.items()])).T
    plt.plot(x,y,marker='o',color=cmap(U.index(name)),linestyle='-')
plt.xlabel('Career age',size=18)
plt.ylabel("Average team size",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(122)
x,y=np.array(sorted(BT.items())).T
y=y/float(y.sum())
plt.plot(x,y)
plt.xlim(-2,2)
plt.plot([0.56,0.56],[0,0.16],'r-',label='mean = 0.56')
plt.fill_between(x,0,y,color='RoyalBlue',alpha=0.1)
plt.ylim(0,0.16)
plt.xlabel('Regression Coefficient',size=18)
plt.ylabel("Probability",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc=2)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures5/mobility.pdf')


# In[84]:

x,y=np.array(BT.items()).T
y=y/float(y.sum())


# In[85]:

sum(x*y)


# # citation depth over time

# In[116]:

# papers
W1=defaultdict(lambda:{})
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize)>0:
            W1[int(Id)]=float(timegap)


# In[121]:

BD=dict((u,min([Y[i] for i in A['PREOBRAJENSKI, AB+0'] if i in Y])) for u in A)#first year of publication for users


# In[122]:

len(BD)


# In[128]:

UT=defaultdict(lambda:defaultdict(lambda:[]))
UM=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for u in A:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)#6
    for p in A[u]:
        if p in Y and p in T and p in W1:
            year=Y[p]
            careerAge=year-BD[u]
            UT[u][careerAge].append(W1[p])
            UM[u][careerAge].append(T[p])


# In[129]:

UT['PREOBRAJENSKI, AB+0']


# In[130]:

UM['PREOBRAJENSKI, AB+0']


# In[135]:

A1=defaultdict(lambda:[])
A2=defaultdict(lambda:[])
for u in UT:
    for k,v in UT[u].items():
        A1[k].append(np.mean(v))
for u in UM:
    for k,v in UM[u].items():
        A2[k].append(np.mean(v))


# In[136]:

xt,yt=np.array(sorted([(k,np.mean(v)) for k,v in A1.items()])).T
xm,ym=np.array(sorted([(k,np.mean(v)) for k,v in A2.items()])).T


# In[140]:

plt.plot(xt,yt,'bo')
#plt.xlim(0,10)


# In[139]:

plt.plot(xm,ym,'go')


# In[ ]:




# In[117]:

sorted([(Y[i],T[i],W1[i]) for i in A['PREOBRAJENSKI, AB+0'] if i in Y and i in T and i in W1])


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# # are people more disruptive over time

# In[81]:

A=defaultdict(lambda:defaultdict(lambda:{}))
n=0
#with open('/data/lingfei/rawAuthorEmailPaperWOS.txt', "r") as f:
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationQX4000000.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            #print(n/100000)#154
            flushPrint(n/100000)#154
        line=line.strip().split('\t')
        #if len(line)>=11:
        A[line[0]]=map(int,line[1:])


# In[82]:

len(A)


# In[83]:

# verify 
U=random.sample(A.keys(),10)


# In[96]:

U[0],A[U[0]]


# In[ ]:




# In[20]:

# papers
W=defaultdict(lambda:{})
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]


# In[24]:

from scipy import stats

DisruptionPaper=[v[2] for v in W.values()]
DisruptionPaper=random.sample(DisruptionPaper,1000)
stats.percentileofscore(DisruptionPaper,0)


# In[34]:

DT={}
n=0
for name in A:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    firstYear=min([Y[i] for i in A[name] if i in Y])
    data=[(Y[i]-firstYear,W[i][2]) for i in A[name] if i in Y and i in W]
    if data:
        x,y=np.array(sorted(data)).T
        D=defaultdict(lambda:[])
        for i,j in zip(x,y):
            D[i].append(j)
        x,y=np.array(sorted([(k,np.mean(v)) for k,v in D.items()])).T
        if len(x)>=3:
            #y=[stats.percentileofscore(DisruptionPaper,i) for i in y]
            DT[name]=[x,y]


# In[77]:

D=defaultdict(lambda:[])
n=0
for name in A:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    ys=[Y[i] for i in A[name] if i in Y]
    if ys:
        firstYear=min(ys)
        data=[(Y[i]-firstYear,W[i][2]) for i in A[name] if i in Y and i in W]
        if data:
            for i,j in data:
                D[i].append(j)


# In[78]:

xd,yd=np.array(sorted([(k,np.mean(v)) for k,v in D.items()])).T
ydd=[stats.percentileofscore(DisruptionPaper,i) for i in yd]


# In[79]:

plt.plot(xd,yd,'bo-')


# In[80]:

plt.plot(xd,ydd,'bo-')


# In[ ]:




# In[ ]:




# In[35]:

len(DT)


# In[36]:

DA=defaultdict(lambda:[])
for name in DT:
    for i,j in zip(x,y):
        DA[i].append(j)
xd,yd=np.array(sorted([(k,np.mean(v)) for k,v in DA.items()])).T


# In[55]:

U=random.sample(DT.keys(),10)


# In[58]:

fig = plt.figure(figsize=(6,5))
ax = fig.add_subplot(111)
cmap = cm.get_cmap('rainbow',11)
for name in U:
    x,y=DT[name]
    plt.plot(x,y,marker='o',color=cmap(U.index(name)),linestyle='-')
plt.xlabel('Career age',size=18)
plt.ylabel("Average disruption",size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.ylim(-0.02,0.02)


# In[33]:

plt.plot(xd,yd,'bo-')


# In[41]:

plt.plot(xd,yd,'bo-')


# In[69]:

# orcid data
A1=defaultdict(lambda:defaultdict(lambda:{}))
n=0
#with open('/data/lingfei/rawAuthorEmailPaperWOS.txt', "r") as f:
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/ORCIDmatchedScholars.txt', "r") as f:
    for line in f:
        n+=1
        if n%100000==0:
            #print(n/100000)#154
            flushPrint(n/100000)#154
        line=line.strip().split('\t')
        #if len(line)>=11:
        A1[line[0]]=map(int,line[1:])


# In[71]:

D1=defaultdict(lambda:[])
n=0
for name in A1.keys()[:10000]:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    firstYear=min([Y[i] for i in A1[name] if i in Y])
    data=[(Y[i]-firstYear,W[i][2]) for i in A1[name] if i in Y and i in W]
    if data:
        for i,j in data:
            D1[i].append(j)


# In[72]:

xd1,yd1=np.array(sorted([(k,np.mean(v)) for k,v in D1.items()])).T
ydd1=[stats.percentileofscore(DisruptionPaper,i) for i in yd1]


# In[73]:

plt.plot(xd1,yd1,'bo-')


# In[74]:

plt.plot(xd1,ydd1,'bo-')


# In[ ]:



