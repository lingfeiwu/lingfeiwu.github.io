
# coding: utf-8

# In[2]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()

def Beauty(startyear,dic):
    data=deepcopy(dic)
    if startyear not in data:
        data[startyear]=0
    t,c=np.array([(k-startyear,v) for k,v in data.items() if k>=startyear]).T
    cm=max(c)
    tm=(t[c==cm])[0]
    c0=c[0]
    lt=t*(cm-c0+0.0)/tm + c0
    c1 = deepcopy(c)
    c1[c1 == 0] = 1
    bi = sum(((lt-c)/c1)[:tm+1])
    return bi

def diff_months(d1,d2): return 12*(int(d2[:4])-int(d1[:4]))+(int(d2[-2:])-int(d1[-2:]))
def BeautyGithub(startyear,dic):
    data=deepcopy(dic)
    if startyear not in data:
        data[startyear]=0
    t,c=np.array(sorted([(diff_months(startyear,k),v) for k,v in data.items() if k>=startyear])).T
    cm=max(c)
    tm=(t[c==cm])[0]
    c0=c[0]
    lt=t*(cm-c0+0.0)/tm + c0
    c1 = deepcopy(c)
    c1[c1 == 0] = 1
    bi = sum(((lt-c)/c1)[:tm+1])
    return bi


# ### Selecting most influential papers

# In[5]:

I1=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        I1.append(int(impact))


# In[13]:

np.percentile(I1,99)


# In[33]:

I2=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize,  disruptiveness, impact=line.strip().split('\t')
        I2.append(int(impact))


# In[16]:

np.percentile(I2,99)


# In[6]:

I3=defaultdict(lambda:0)
n=0
with open('/Users/lingfeiw/Documents/bigdata/Github_Small/ForkEvent.csv', "rb") as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        line= line.strip().split(',')
        actor,repo,date=line
        repo=int(repo)
        I3[repo]+=1


# In[105]:

np.percentile(I3.values(),98.5)


# ### Papers

# In[2]:

Y1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        doi,ndoi,year=line.strip().split('\t')
        Y1[int(ndoi)]=int(year)


# In[3]:

X1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        #if int(impact)>=197:
        #if random.random()<0.05:
        X1[int(Id)]=[int(year),int(teamsize)]


# In[4]:

C1=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        year=Y1[line[0]]
        ref = line[1:]
        for j in ref:
            if j in X1:
                C1[j][year]+=1


# In[ ]:

len(C1)


# In[ ]:




# In[8]:

B1={}
n=0
for i in C1:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    if i in Y1:
        syear=Y1[i]
        dic=C1[i]
        bi=Beauty(syear,dic)
        if bi>-10**10 and bi<10**10:
            B1[i]=bi


# In[9]:

len(Y1),len(X1),len(C1),len(B1)


# In[26]:

len(Y1),len(X1),len(C1),len(B1)


# In[10]:

with open('/Users/lingfeiw/Documents/research/teamscience/sleepbeauty/paperRandom2per.txt','wb') as f:
    for i in B1:
        year=X1[i][0]
        teamsize=X1[i][1]
        bi=B1[i]
        f.write(str(i)+'\t'+str(year)+'\t'+str(teamsize)+'\t'+str(bi)+'\n')


# ### Patents

# In[3]:

Y1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/allpatentID.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, title=line.strip().split('\t')
        Y1[Id]=int(date[:4])


# In[5]:

C1=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentNetworkApplicant.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in Y1:
            year=Y1[p]
            ref = line[1:]
            for j in ref:
                C1[j][year]+=1


# In[11]:

X1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize,  disruptiveness, impact=line.strip().split('\t')
        X1[Id]=[int(year),int(teamsize)]


# In[9]:

B1={}
n=0
for i in C1:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    if i in Y1:
        syear=Y1[i]
        dic=C1[i]
        bi=Beauty(syear,dic)
        if bi>-10**10 and bi<10**10:
            B1[i]=bi


# In[12]:

with open('/Users/lingfeiw/Documents/research/teamscience/sleepbeauty/patent.txt','wb') as f:
    for i in B1:
        if i in X1:
            year=X1[i][0]
            teamsize=X1[i][1]
            bi=B1[i]
            f.write(str(i)+'\t'+str(year)+'\t'+str(teamsize)+'\t'+str(bi)+'\n')


# In[13]:

PP=defaultdict(lambda:[])
for i in B1:
    if i in X1:
        teamsize=X1[i][1]
        bi=B1[i]
        PP[teamsize].append(bi)


# In[14]:

x,y=np.array(sorted([(k,np.mean(v)) for k,v in PP.items()])).T


# In[26]:

plt.plot(x,y,'bo-')
plt.xlim(1,10)
plt.ylim(3,7)
plt.xlabel('team size')
plt.ylabel('sleep beauty index')
plt.title('Patent')


# ### Repositories

# In[27]:

Y1={}
n=0
with open('/Users/lingfeiw/Documents/bigdata/Github_Small/CreateEvent.csv', "rb") as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        actor,repo,date=line.strip().split(',')
        repo=int(repo)
        if repo not in Y1:
            Y1[repo]=date[:7]
        else:
            if date[:7]<Y1[repo]:
                Y1[repo]=date[:7]


# In[35]:

C1=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/bigdata/Github_Small/ForkEvent.csv', "rb") as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        line= line.strip().split(',')
        actor,repo,date=line
        repo=int(repo)
        if I3[repo]>=80:
            C1[repo][date[:7]]+=1


# In[36]:

B1={}
n=0
for i in C1:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    if i in Y1:
        syear=Y1[i]
        dic=C1[i]
        bi=BeautyGithub(syear,dic)
        if bi>-10**10 and bi<10**10:
            B1[i]=bi


# In[37]:

len(Y1),len(C1),len(B1)


# In[30]:

S={}
f = open('/Users/lingfeiw/Documents/bigdata/Github_Small/Repo_final.txt', "rb")
n=0
for line in f:
    n+=1
    if n%1000000==0:
        flushPrint(n/1000000)
    repoID, repoName, language, teamSize, NofPushes, repoFinalSize = line.strip().split('\t')
    repoID=int(repoID)
    if repoID in B1:
        S[repoID]=int(teamSize)


# In[20]:

with open('/Users/lingfeiw/Documents/research/teamscience/sleepbeauty/repoTop1per.txt','wb') as f:
    for i in B1:
        if i in W4:
            year=W4[i][0]
            teamsize=W4[i][1]
            bi=B1[i]
            f.write(str(i)+'\t'+str(year)+'\t'+str(teamsize)+'\t'+str(bi)+'\n')


# In[38]:

bb=defaultdict(lambda:[])
for i in B1:
    year=Y1[i]
    teamsize=S[i]
    bi=B1[i]
    bb[teamsize].append(bi)


# In[40]:

x,y=np.array(sorted([(i,np.mean(bb[i])) for i in bb])).T
plt.plot(x,y,'bo-')
plt.xlim(1,10)
plt.ylim(0,50)


# In[34]:

plt.plot(x,y,'bo-')
plt.xlim(1,30)
plt.ylim(0,50)


# In[ ]:



