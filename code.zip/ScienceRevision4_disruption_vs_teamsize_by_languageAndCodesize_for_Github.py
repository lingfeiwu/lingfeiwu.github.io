
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from scipy import stats
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    


# In[2]:

n=0
W3={}
W4={}
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubStats.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, year, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if 2011<=int(year)<=2014:
            if disruptiveness!='NA':
                W3[int(Id)]=[int(year),int(teamsize),int(impact),float(disruptiveness)]
            W4[int(Id)]=[int(year),int(teamsize),int(impact),disruptiveness]


# In[3]:

len(W3),len(W4)


# In[4]:

DisruptionGithub=[i[-1] for i in W3.values()]
stats.percentileofscore(DisruptionGithub,0)


# In[5]:

S={}
L={}
f = open('/Users/lingfeiw/Documents/bigdata/Github_Small/Repo_final.txt', "rb")
n=0
for line in f:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    repoID, repoName, language, teamSize, NofPushes, repoFinalSize = line.strip().split('\t')
    repoID=int(repoID)
    if repoID in W3:
        L[repoID]=language
        if repoFinalSize and int(repoFinalSize)>0:
            S[repoID]=4*int(repoFinalSize)/4


# In[6]:

len(S),len(L)


# In[7]:

sorted(Counter(L.values()).items(),key=lambda x:-x[1])[:11]


# In[8]:

topL=['JavaScript','Ruby','Java','Python','PHP','C++','C']


# In[9]:

disGithubL=defaultdict(lambda:defaultdict(lambda:[]))
for i in W3:
    year3,teamsize3,impact3,disruptive3=W3[i]
    if teamsize3>0 and i in L and L[i] in topL:
        disGithubL[L[i]][teamsize3].append(disruptive3)
disGithubS=defaultdict(lambda:defaultdict(lambda:[]))
for i in W3:
    year3,teamsize3,impact3,disruptive3=W3[i]
    if teamsize3>0 and i in S:
        scale=S[i]
        if scale<200:
            s=1
        if 200<=scale<1024:
            s=2
        if 1024<=scale<10240:
            s=3
        if scale>10240:
            s=4
        disGithubS[s][teamsize3].append(disruptive3)


# In[11]:

ydisGithub=[67.992565055762071,
 35.944237918215613,
 35.304832713754649,
 34.724907063197023,
 34.156133828996282,
 33.486988847583646,
 30.773234200743495,
 25.78066914498141,
 24.096654275092938,
 22.750929368029741]


# In[18]:

cmap = cm.get_cmap('rainbow',len(topL))
fig = plt.figure(figsize=(10, 5),facecolor='white')
ax = fig.add_subplot(121)
n=0
for l in topL:
    x,y=np.array(sorted([(k,np.mean(v)) for k,v in disGithubL[l].items()])).T
    y=[stats.percentileofscore(DisruptionGithub,i) for i in y]
    plt.plot(x,y,color=cmap(n),label=str(l),linewidth=2)
    n+=1
plt.xlim(1,10)
plt.plot(range(1,11),ydisGithub,'k--',linewidth=2,label='Population average')
plt.legend(loc=1,frameon=False)
plt.ylim(10,80)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(122)
sm={1:'< 200KB',2:'200KB - 1MB',3:'1MB - 10MB',4:'> 10MB'}
cmap = cm.get_cmap('Accent',len(disGithubS))
n=0
for l in disGithubS:
    x,y=np.array(sorted([(k,np.mean(v)) for k,v in disGithubS[l].items()])).T
    y=[stats.percentileofscore(DisruptionGithub,i) for i in y]
    plt.plot(x,y,color=cmap(n),label=sm[l],linewidth=2)
    n+=1
plt.xlim(1,10)
plt.plot(range(1,11),ydisGithub,'k--',linewidth=2,label='Population average')
plt.legend(loc=1,frameon=False)
plt.ylim(10,80)
plt.xlabel('team size',fontsize=20)
plt.ylabel('Disruption Percentile',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/GitHubControl.pdf')


# In[ ]:




# In[ ]:



