
# coding: utf-8

# In[274]:

get_ipython().magic(u'matplotlib inline')
import sys
from scipy import stats
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax



def log2linearBin(x,y):
    x=np.log2(x)
    a=[]
    q=sorted(zip([int(i) for i in x],y))
    tag = ''
    d=[]
    for i in q:
        x1,y1 = i
        if x1 == tag: 
            d.append(y1)
        else:   
            if tag:   
                a.append([tag,np.mean(d)])
            tag = x1
            d = []
    a.append([tag,np.mean(d)])
    nx,ny = np.array(a).T
    return 2**nx,ny


# In[38]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W1[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
Z1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperNovelty1901_2014.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,novelty = line.strip().split('\t')
        Z1[int(paper)]=float(novelty)
        
S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[53]:

#aggregate data by team size
dep=defaultdict(lambda:[])
pop=defaultdict(lambda:[])
bre=defaultdict(lambda:[])
dis=defaultdict(lambda:[])
imp=defaultdict(lambda:[])
sle=defaultdict(lambda:[])
for i in W1:
    if i in S1 and i in Z1:
        teamsize,impact,disruptiveness,timegap, meanimp=W1[i]
        dep[teamsize].append(timegap)
        pop[teamsize].append(meanimp)
        dis[teamsize].append(disruptiveness)
        imp[teamsize].append(impact)
        sle[teamsize].append(S1[i])
        bre[teamsize].append(Z1[i])


# In[54]:

Teamsize,Impact,Disruptiveness,Timegap,Meanimp=np.array(W1.values()).T
Sleep=S1.values()
Bread=Z1.values()


# In[114]:

# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,17):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<10000:
            m=10000
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(random.sample(data,m)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(random.sample(data,m)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    return ci


# In[57]:

# calculate mean
xdep,ydep=np.array(sorted([(k,np.mean(v)) for k,v in dep.items()])).T
xpop,ypop=np.array(sorted([(k,np.median(v)) for k,v in pop.items()])).T
xbre,ybre=np.array(sorted([(k,np.mean(v)) for k,v in bre.items()])).T
xdis,ydis=np.array(sorted([(k,np.mean(v)) for k,v in dis.items()])).T
ximp,yimp=np.array(sorted([(k,np.mean(v)) for k,v in imp.items()])).T
xsle,ysle=np.array(sorted([(k,np.mean(v)) for k,v in sle.items()])).T


# In[115]:

#bootstrap CI
depCI=calculateCI(dep,'mean',30)
popCI=calculateCI(pop,'median',30)
breCI=calculateCI(bre,'mean',30)
disCI=calculateCI(dis,'mean',30)
impCI=calculateCI(imp,'mean',30)
sleCI=calculateCI(sle,'mean',30)


# In[116]:

#
ydepCI1,ydepCI2=np.array(depCI).T
ypopCI1,ypopCI2=np.array(popCI).T
ybreCI1,ybreCI2=np.array(breCI).T
ydisCI1,ydisCI2=np.array(disCI).T
yimpCI1,yimpCI2=np.array(impCI).T
ysleCI1,ysleCI2=np.array(sleCI).T
#
ybre_=[stats.percentileofscore(Bread,i) for i in ybre[:16]]
ybreCI1_=[stats.percentileofscore(Bread,i) for i in ybreCI1]
ybreCI2_=[stats.percentileofscore(Bread,i) for i in ybreCI2]
ydis_=[stats.percentileofscore(Disruptiveness,i) for i in ydis[:16]]
ydisCI1_=[stats.percentileofscore(Disruptiveness,i) for i in ydisCI1]
ydisCI2_=[stats.percentileofscore(Disruptiveness,i) for i in ydisCI2]
ysle_=[stats.percentileofscore(Sleep,i) for i in ysle[:16]]
ysleCI1_=[stats.percentileofscore(Sleep,i) for i in ysleCI1]
ysleCI2_=[stats.percentileofscore(Sleep,i) for i in ysleCI2]


# In[117]:

stats.percentileofscore(Disruptiveness,0)


# In[286]:

### create figure
fig = plt.figure(figsize=(5, 4),facecolor='white')

#------------main figure 121-------------------

host = host_subplot(111,axes_class=AA.Axes)
plt.subplots_adjust(right=0.75)

par1 = host.twinx()
par2 = host.twinx()

offset = 60
new_fixed_axis = par2.get_grid_helper().new_fixed_axis
par2.axis["right"] = new_fixed_axis(loc="right",axes=par2,offset=(offset, 0))
par2.axis["right"].toggle(all=True)

host.set_xlim(1, 16)


host.set_xlabel("Team size",fontsize =24)
host.set_ylabel("Depth",fontsize=24)
par1.set_ylabel("Popularity",fontsize=24)
par2.set_ylabel("Breadth",size=50)

host.fill_between(range(1,17), ydepCI1,ydepCI2,color='gray',alpha=0.15)
par1.fill_between(range(1,17), ypopCI1,ypopCI2,color='gray',alpha=0.15)
par2.fill_between(range(1,17), 100-np.array(ybreCI1_),100-np.array(ybreCI2_),                  color='gray',alpha=0.1)
p1, = host.plot(xdep,ydep, label="Depth",color='#117733')
p2, = par1.plot(xpop,ypop, label="Popularity",color='#882255')
p3, = par2.plot(range(1,17),100-np.array(ybre_), label="Breadth",color='#4477AA')

host.set_ylim(7, 12)
host.set_yticks([7,9,12])
par1.set_ylim(80,380)
par1.set_yticks([80,210,380])
par2.set_ylim(15, 35)
par2.set_yticks([15,24,35])
#host.legend()

host.axis["left"].label.set_color(p1.get_color())
par1.axis["right"].label.set_color(p2.get_color())
par2.axis["right"].label.set_color(p3.get_color())
par2.axis["right"].label.set_fontsize(14)
par1.axis["right"].label.set_fontsize(14)
host.axis["bottom"].label.set_fontsize(14)
host.axis["left"].label.set_fontsize(14)

###-----------------------------------------------inset---------------

#------------inset 121-------------------
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.1.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[285]:

fig = plt.figure(figsize=(5, 4),facecolor='white')

#------------main figure 121-------------------

host = host_subplot(111, axes_class=AA.Axes)
plt.subplots_adjust(right=0.75)

par1 = host.twinx()
par2 = host.twinx()

offset = 60
new_fixed_axis = par2.get_grid_helper().new_fixed_axis
par2.axis["right"] = new_fixed_axis(loc="right",axes=par2,offset=(offset, 0))
par2.axis["right"].toggle(all=True)
host.set_xlim(1, 16)
host.set_xlabel("Team size")
host.set_ylabel("Disruption")
par1.set_ylabel("Impact")
par2.set_ylabel("Potential")

host.fill_between(range(1,17), ydisCI1_,ydisCI2_,color='gray',alpha=0.15)
par2.fill_between(range(1,17), ysleCI1_,ysleCI2_,color='gray',alpha=0.15)
par1.fill_between(range(1,17), yimpCI1,yimpCI2,color='gray',alpha=0.15)
host.plot([1,16],[70,70],color='#117733',linestyle='--')
p1, = host.plot(range(1,17),ydis_, label="Disruption",color='#117733')
p2, = par1.plot(ximp,yimp, label="Impact",color='#882255')
p3, = par2.plot(range(1,17),ysle_, label="Potential",color='#4477AA')
#par2.plot([1,16],[21.75,21.75],color='#4477AA',linestyle='--')

host.set_ylim(25,100)
host.set_yticks([25,60,100])
par1.set_ylim(20, 65)
par1.set_yticks([20,40,65])
par2.set_ylim(50, 100)
par2.set_yticks([50,72,100])

#host.legend()
host.axis["left"].label.set_color(p1.get_color())
par1.axis["right"].label.set_color(p2.get_color())
par2.axis["right"].label.set_color(p3.get_color())
par2.axis["right"].label.set_fontsize(14)
par1.axis["right"].label.set_fontsize(14)
host.axis["bottom"].label.set_fontsize(14)
host.axis["left"].label.set_fontsize(14)

subax = add_subplot_axes(host,[0.2,0.7,0.3,0.3])

#------------inset 121-------------------
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.3.pdf')


# In[148]:

xa11,ya11=log2linearBin(xdep[:100],ydep[:100])
xa22,ya22=log2linearBin(xpop[:100],ypop[:100])
xa33,ya33=log2linearBin(xbre[:100],ybre[:100])
xa44,ya44=log2linearBin(xdis[:100],ydis[:100])
xa55,ya55=log2linearBin(xsle[:100],ysle[:100])
xa66,ya66=log2linearBin(ximp[:100],yimp[:100])


# In[149]:

ya33_=[stats.percentileofscore(Bread,i) for i in ya33]


# In[167]:

ya55_=[stats.percentileofscore(Sleep,i) for i in ya55]


# In[168]:

ya44_=[stats.percentileofscore(Disruptiveness,i) for i in ya44]


# In[165]:


fig = plt.figure(figsize=(5, 4),facecolor='white')
#ax = fig.add_subplot(121)
host = host_subplot(111, axes_class=AA.Axes)
plt.subplots_adjust(right=0.75)
par1 = host.twinx()
par2 = host.twinx()
offset = 60
new_fixed_axis = par2.get_grid_helper().new_fixed_axis
par2.axis["right"] = new_fixed_axis(loc="right",
                                    axes=par2,
                                    offset=(offset, 0))
par2.axis["right"].toggle(all=True)
host.set_xlim(1, 100)
host.set_xscale('log')


p1, = host.plot(xa11,ya11, linewidth=2,color='#117733')
p2, = par1.plot(xa22,ya22,linewidth=2,color='#882255')
p3, = par2.plot(xa33,100-np.array(ya33_), linewidth=2,color='#4477AA')

host.set_ylim(6.5,9.5)
host.set_yticks([6.5,8,9.5])
par1.set_ylim(100, 230)
par1.set_yticks([100,165,230])
par2.set_ylim(5,23)
par2.set_yticks([5,14,23])
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.4.pdf')


# In[377]:

fig = plt.figure(figsize=(5, 4),facecolor='white')

#------------main figure 121-------------------

host = host_subplot(111, axes_class=AA.Axes)
plt.subplots_adjust(right=0.75)

par1 = host.twinx()
par2 = host.twinx()

offset = 60
new_fixed_axis = par2.get_grid_helper().new_fixed_axis
par2.axis["right"] = new_fixed_axis(loc="right",
                                    axes=par2,
                                    offset=(offset, 0))

par2.axis["right"].toggle(all=True)

host.set_xlim(1, 100)
host.set_xscale('log')


p1, = host.plot(xa44,ya44_,linewidth=2,color='#117733')
p2, = par1.plot(xa55,ya55_,linewidth=2,color='#4477AA')
p3, = par2.plot(xa66,ya66,linewidth=2,color='#882255')

host.set_ylim(20,80)
host.set_yticks([20,50,80])
par1.set_ylim(60, 85)
par1.set_yticks([60,72,85])
par2.set_ylim(20, 80)
par2.set_yticks([20,50,80])

#host.legend()
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.2.pdf')
#------------inset 121-------------------



# In[235]:

np.percentile(Impact,90),np.percentile(Disruptiveness,90),np.percentile(Timegap,90),np.percentile(Meanimp,90),np.percentile(Sleep,90),np.percentile(Bread,10)


# In[242]:

# no time window
A=defaultdict(lambda:[0,0])#all papers, top 5% impact 
B=defaultdict(lambda:[0,0])#all papers, top 5% disruptive
C=defaultdict(lambda:[0,0])#all papers, top 5% depth
D=defaultdict(lambda:[0,0])#all papers, top 5% popularity
E=defaultdict(lambda:[0,0])#all papers, top 5% potential
F=defaultdict(lambda:[0,0])#all papers, top 5% breadth
for i in W1:
    if i in S1 and i in Z1:
        teamsize,impact,disruptiveness,timegap, meanimp=W1[i]
        sleep=S1[i]
        breadth=Z1[i]
        #if 1<=teamsize<=16:
        A[teamsize][0]+=1
        B[teamsize][0]+=1
        C[teamsize][0]+=1
        D[teamsize][0]+=1
        E[teamsize][0]+=1
        F[teamsize][0]+=1
        if impact >=53:
            A[teamsize][1]+=1
        if disruptiveness>=0.0094:
            B[teamsize][1]+=1
        if timegap>=15:
            C[teamsize][1]+=1
        if meanimp>=660:
            D[teamsize][1]+=1
        if sleep >=11.3:
            E[teamsize][1]+=1
        if breadth<=-14.8:
            F[teamsize][1]+=1


# In[244]:

xa1,ya1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in A.items()]).T
xb1,yb1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in B.items()]).T
xc1,yc1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in C.items()]).T
xd1,yd1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in D.items()]).T
xe1,ye1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in E.items()]).T
xf1,yf1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in F.items()]).T


# In[474]:

fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------

host = host_subplot(111)
plt.plot(xc1,yc1,color='#117733',label='Top 10% Depth')
plt.plot(xd1,yd1,color='#882255',label='Top 10% Popularity')
plt.plot(xf1,yf1,color='#4477AA',label='Top 10% Breadth')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[0.1,0.1],color='gray',linestyle='--')
plt.xlim(1,16)
plt.ylim(0,0.2)
plt.legend(loc=2,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.3.pdf')


# In[473]:

fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------

host = host_subplot(111)
plt.plot(xb1,yb1,color='#117733',label='Top 10% Disruption')
plt.plot(xa1,ya1,color='#882255',label='Top 10% Impact')
plt.plot(xe1,ye1,color='#4477AA',label='Top 10% Potential')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[0.1,0.1],color='gray',linestyle='--')
plt.xlim(1,16)
plt.ylim(0,0.2)
plt.legend(loc=2,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.4.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[410]:

def yTransform(yOldMin,yOldMax,yNewMin,yNewMax,ys):
    return (yOldMax-yOldMin)*(ys-yNewMin)/(yNewMax-yNewMin)+yOldMin

newysle_=yTransform(20,65,50,100,np.array(ysle_))
newysleCI1_=yTransform(20,65,50,100,np.array(ysleCI1_))
newysleCI2_=yTransform(20,65,50,100,np.array(ysleCI2_))
newya55_=yTransform(20,80,60,85,np.array(ya55_))
newybre_=yTransform(80,380,15,35,100-np.array(ybre_))
newybreCI1_=yTransform(80,380,15,35,100-np.array(ybreCI1_))
newybreCI2_=yTransform(80,380,15,35,100-np.array(ybreCI2_))
newya33_=yTransform(100,230,5,23,100-np.array(ya33_))


# In[464]:

### create figure
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.fill_between(range(1,17), ydepCI1,ydepCI2,color='gray',alpha=0.15)
par1.fill_between(range(1,17), ypopCI1,ypopCI2,color='gray',alpha=0.15)
par1.fill_between(range(1,17), newybreCI1_,newybreCI2_,color='gray',alpha=0.1)
p1, = host.plot(xdep,ydep, label="Depth",color='#117733')
p2, = par1.plot(xpop,ypop, label="Popularity",color='#882255')
par1.plot(range(1,17),newybre_,color='#4477AA')

host.set_xlim(1, 16)
host.set_ylim(7, 11)
host.set_yticks([7,9,11])
par1.set_ylim(80,350)
par1.set_yticks([80,215,350])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.45,0.7,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')

subax.plot(xa11,ya11, linewidth=1,color='#117733')
par1.plot(xa22,ya22,linewidth=1,color='#882255')
par1.plot(xa33,newya33_,linewidth=1,color='#4477AA')
subax.set_ylim(6.5,9.5)
subax.set_yticks([6.5,8,9.5])
par1.set_ylim(100, 230)
par1.set_yticks([100,165,230])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.1.pdf')


# In[463]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.fill_between(range(1,17), ydisCI1_,ydisCI2_,color='gray',alpha=0.15)
par1.fill_between(range(1,17), newysleCI1_,newysleCI2_,color='gray',alpha=0.15)
par1.fill_between(range(1,17), yimpCI1,yimpCI2,color='gray',alpha=0.15)
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.plot(range(1,17),ydis_, label="Disruption",color='#117733')
par1.plot(ximp,yimp, label="Impact",color='#882255')
par1.plot(range(1,17),newysle_, label="Potential",color='#4477AA')

host.set_xlim(1, 16)
host.set_ylim(25,100)
host.set_yticks([25,60,100])
par1.set_ylim(20, 65)
par1.set_yticks([20,40,65])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.45,0.7,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xa44,ya44_,linewidth=1,color='#117733')
par1.plot(xa55,newya55_,linewidth=1,color='#4477AA')
par1.plot(xa66,ya66,linewidth=1,color='#882255')
subax.set_ylim(20,80)
subax.set_yticks([20,50,80])
par1.set_ylim(20, 80)
par1.set_yticks([20,50,80])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalFigures/Fig2.2.pdf')


# In[ ]:



