
# coding: utf-8

# In[23]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    #sys.stdout.write('%d' % d)
    sys.stdout.write(d)
    sys.stdout.flush()


# In[8]:

WOS={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        WOS[doi]=int(ndoi)
# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(teamsize),float(disruptive)]


# In[9]:

path='/Users/lingfeiw/Documents/research/teamscience/match_wos_final/'
scholars = [ f for f in listdir(path)]

U={}
n=0
for i in scholars:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    data=[]
    with open (path+i,'r') as f:
        for line in f:
            data.append(line.strip())
    name=i.split('.')[0]
    data=[WOS[j] for j in data if j in WOS and WOS[j] in W]
    if data:
        U[name]=data


# In[7]:

papers=[]
for i in U:
    papers+=U[i]
papers=set(papers)
len(papers)


# In[3]:

# papers
Title={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=int(line[0])
        #if p in papers:
        Title[p]=line[1]


# In[24]:

#authors
N={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/authorlist1900_2015.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint('author_'+str(n/100000))#427
        line=line.strip().split('\t')
        N[int(line[0])] = [i.upper() for i in line[1:]]
        
def replaceNone(s):
    if s=='None':
        return '?'
    else:
        return s


# In[ ]:




# In[ ]:

len(Author)


# In[15]:

m=0
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/authororganization1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)   
        line=line.strip().split('\t')
        p=int(line[0])
        if p in Author and len(line)-1==len(Author[p]):
            m+=1


# In[21]:

36882710,Author[36882710],line


# In[16]:

m


# In[17]:


n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/authorlistOrg1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)   


# In[18]:

n


# In[ ]:




# In[5]:

Title[33554432]


# In[6]:

Author[33554432]


# In[14]:

Title[37504371].lower()


# In[11]:

Author[42681709]


# In[ ]:




# In[8]:


# papers
Abstract={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in Title:
                Abstract[p]=Title[p]+' '+line[1]


# In[7]:

len(Title),len(Abstract)


# In[10]:

import gensim


# In[11]:

# sampleing papers across journals
J=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954 and int(Id) in Abstract:
            J[int(journal)].append(int(Id))


# In[145]:

len(J)


# In[12]:

paperSample=[]
samplesize=100000
n=float(sum(map(len,J.values())))
for k,v in J.items():
    w=len(v)/n
    m=int(w*samplesize)
    if m>0:
        rv=random.sample(v,m)
        paperSample+=rv
paperSample=set(paperSample)

train_corpus=[]
n=0
for i in paperSample:
    if i in Abstract:
        ab=Abstract[i]
        if len(ab)>10:
            new=gensim.models.doc2vec.TaggedDocument(gensim.utils.simple_preprocess(ab), [n])
            train_corpus.append(new)
            n+=1
n


# In[13]:

model = gensim.models.doc2vec.Doc2Vec(size=100, min_count=2, iter=20, workers=4)
model.build_vocab(train_corpus)
get_ipython().magic(u'time model.train(train_corpus, total_examples=model.corpus_count, epochs=model.iter)')


# In[14]:

len(model.wv.vocab)


# In[15]:

model.most_similar('photon',topn=20)#size=100


# In[19]:

len(train_corpus)/100


# In[24]:

ranks = []
second_ranks = []
n=0
#for doc_id in range(len(train_corpus)):
for doc_id in range(1000):
    n+=1
    if n%100==0:
        flushPrint(n/100)
    inferred_vector = model.infer_vector(train_corpus[doc_id].words)
    sims = model.docvecs.most_similar([inferred_vector], topn=len(model.docvecs))
    rank = [docid for docid, sim in sims].index(doc_id)
    ranks.append(rank)
    second_ranks.append(sims[1])


# In[29]:

collections.Counter(ranks).items()[:3]


# In[ ]:




# In[37]:

len(train_corpus)


# In[85]:

#i=30545500
#i=28903886
#i=random.sample(Abstract.keys(),1)[0]
#Abstract[i]
' '.join(train_corpus[11].words)


# In[144]:

doc_id=500
print('Document ({}): «{}»\n'.format(doc_id, ' '.join(train_corpus[doc_id].words)))
print(u'SIMILAR/DISSIMILAR DOCS PER MODEL %s:\n' % model)
inferred_vector = model.infer_vector(train_corpus[doc_id].words)
sims = model.docvecs.most_similar([inferred_vector], topn=len(model.docvecs))
for label, index in [('MOST', 1), ('MEDIAN', len(sims)//2), ('LEAST', len(sims) - 6)]:
    print(u'%s %s: «%s»\n' % (label, sims[index], ' '.join(train_corpus[sims[index][0]].words)))


# In[63]:

#model.random.seed(0)
inferred_vector = model.infer_vector(gensim.utils.simple_preprocess(Abstract[i]))
#inferred_vector = model.infer_vector(train_corpus[6624].words)
sims = model.docvecs.most_similar([inferred_vector], topn=len(model.docvecs))
#rank = [docid for docid, sim in sims].index(doc_id)


# In[68]:

k=1
sims[k],' '.join(train_corpus[sims[k][0]].words)


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[6]:

# fitting all papers
vectors={}
n=0
for i in Abstract:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    model.random.seed(0)
    vc=model.infer_vector(gensim.utils.simple_preprocess(Abstract[i]))
    vectors[i]=vc


# In[5]:

len(vectors)


# In[155]:

'''
f = open('/Users/lingfeiw/Documents/research/teamscience/team/abstractVector2million.txt', "wb")
for i in vectors:
    f.write(str(i)+'\t'+'\t'.join(map(str,vectors[i])) + '\n')
f.close()
'''


# In[2]:

vectors={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstractVector2million.txt', "rb") as f:
    for line in f:
        n+=1
        if n%10000==0:
            flushPrint(n/10000)
        line=line.strip().split('\t')
        vectors[int(line[0])]=map(float,line[1:])

        


# In[8]:

# disruption vs team size
fd=defaultdict(lambda:defaultdict(lambda:[]))
for i in U:
    for p in U[i]:
        mp,dp=W[p]
        #if 1<=mp<=10:
        fd[i][mp].append(dp)
n=0
FD={}
for i in fd:
    ls=[(k,np.mean(v)) for k,v in fd[i].items() if 1<=k<=10]
    if len(ls)>0:
        x,y=np.array((sorted(ls))).T
        FD[i]=[x,y]


# In[9]:

len(fd),len(FD)


# In[10]:

# disruption vs 100 content variables (vectors)
fdv=defaultdict(lambda:defaultdict(lambda:[]))
for i in U:
    for p in U[i]:
        if p in vectors:
            mp,dp=W[p]
            #if 1<=mp<=10:
            fdv[i][mp].append(vectors[p])
n=0
FDV={}
for i in fdv:
    ls=[(k,np.mean(v,axis=0)) for k,v in fdv[i].items() if 1<=k<=10]
    if len(ls)>0:
        x,y=zip(*sorted(ls))
        FDV[i]=[x,y]


# In[11]:

len(fdv)


# In[12]:

# fixed and random model data
RDatanewX=[]
RDatanewY=[]
#RDatanewX_=[]
FDatanewX=[]
FDatanewY=[]
for i in FD:
    if i in FDV:
        x,y=FD[i]
        mx=x-np.mean(x)
        my=y-np.mean(y)
        x_,zs=FDV[i]
        for a,b,c in zip(x,zs,y):
            RDatanewX.append([a]+list(b))
            #RDatanewX_.append([a]+[0.1]*len(b))
            RDatanewY.append(c)
        for a,b,c in zip(mx,zs,my):
            FDatanewX.append([a]+list(b))
            #RDatanewX_.append([a]+[0.1]*len(b))
            FDatanewY.append(c)
        #FDatanew+=zip(x-np.mean(x),y-np.mean(y))
RDatanewX=np.array(RDatanewX).T
FDatanewX=np.array(FDatanewX).T
#RDatanewX_=np.array(RDatanewX_).T
#xr,yr=np.array(RDatanew).T
#xf,yf=np.array(FDatanew).T


# In[34]:

# test the correlation between team size and vectors
from scipy.stats.stats import pearsonr


# In[41]:

PR=[]
for i in range(1,len(RDatanewX)):
    c,p=pearsonr(RDatanewX[0],RDatanewX[i])
    PR.append([i,c,p])


# In[50]:

max(zip(*PR)[1]),min(zip(*PR)[1])


# In[ ]:




# In[13]:

y = [1,2,3,4,3,4,5,4,5,5,4,5,4,5,4,5,6,5,4,5,4,3,4]

x = [
     [4,2,3,4,5,4,5,6,7,4,8,9,8,8,6,6,5,5,5,5,5,5,5],
     [4,1,2,3,4,5,6,7,5,8,7,8,7,8,7,8,7,7,7,7,7,6,5],
     [4,1,2,5,6,7,8,9,7,8,7,8,7,7,7,7,7,7,6,6,4,4,4]
     ]

def reg_m(y, x):
    ones = np.ones(len(x[0]))
    X = sm.add_constant(np.column_stack((x[0], ones)))
    for ele in x[1:]:
        X = sm.add_constant(np.column_stack((ele, X)))
    results = sm.OLS(y, X).fit()
    return results


# In[14]:

sumR=reg_m(RDatanewY, RDatanewX)
sumF=reg_m(FDatanewY, FDatanewX)


# In[15]:

sumR.rsquared_adj,sumF.rsquared_adj


# In[35]:

sumR.rsquared_adj,sumF.rsquared_adj


# In[1]:

df.to_clipboard()


# In[ ]:




# In[174]:

sumR.summary()


# In[175]:

sumF.summary()


# In[16]:

paras={}
for i,j in enumerate(zip(sumR.params,sumF.params,sumR.pvalues,sumF.pvalues)):
    paras[i]=j


# In[17]:

paras[100]


# In[182]:

paras[100]


# In[155]:

for i in paras:
    if paras[i][-1]<0.05 and paras[i][-2]<0.05 and paras[i][0]>0:
        print (i,np.round(paras[i][0],4),np.round(paras[i][1],4))
        


# In[168]:

posV=[i for i in paras if paras[i][-1]<0.05 and paras[i][-2]<0.05 and paras[i][0]>0][:-1]
negV=[i for i in paras if paras[i][-1]<0.05 and paras[i][-2]<0.05 and paras[i][0]<0][:-1]


# In[170]:

posV,negV


# In[156]:

for i in paras:
    if paras[i][-1]<0.05 and paras[i][-2]<0.05 and paras[i][0]<0:
        print (i,np.round(paras[i][0],4),np.round(paras[i][1],4))
        


# In[ ]:




# # analyzing vectors

# In[3]:

vt=np.array(vectors.values()).T


# In[4]:

dist={}
for i in range(len(vt)):
    data=vt[i]
    (mu, sigma) = norm.fit(data)
    xs=np.linspace(min(data),max(data),100)
    ys = mlab.normpdf(xs, mu, sigma)
    dist[i]=[xs,ys]


# In[5]:

from itertools import izip

def pairwise(iterable):
    "s -> (s0, s1), (s2, s3), (s4, s5), ..."
    a = iter(iterable)
    return izip(a, a)


# In[12]:

# user moving in content space
Uc={}
n=0
for user in U:
    n+=1
    if n%1000==0:
        flushPrint(n/1000)
    vs=[vectors[p] for p in U[user] if p in vectors]
    if len(vs)>1:
        A_sparse = sparse.csr_matrix(vs)
        similarities = cosine_similarity(A_sparse)
        Uc[user]=[np.mean(similarities),np.std(similarities)]


# In[11]:

from sklearn.metrics.pairwise import cosine_similarity
from scipy import sparse


# In[286]:

Us={}
n=0
for user in U:
    n+=1
    if n%1000==0:
        flushPrint(n/1000)
    papers=[p for p in U[user] if p in vectors]
    dss=[W[p][1] for p in papers if p in W]
    if dss:
        Us[user]=np.mean(dss)


# In[366]:

# papers
WI={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            WI[int(Id)]=int(impact)


# In[367]:

Ui={}
n=0
for user in U:
    n+=1
    if n%1000==0:
        flushPrint(n/1000)
    papers=[p for p in U[user] if p in vectors]
    dss=[WI[p] for p in papers if p in WI]
    if dss:
        Ui[user]=np.mean(dss)


# In[391]:

x1,y1,z1,i1=np.array([(Uc[u][0],Uc[u][1],Us[u],Ui[u]) for u in Uc if u in Ud and u in Ui]).T


# In[392]:

di=defaultdict(lambda:[])
ds=defaultdict(lambda:[])
for u in Uc:
    if u in Ud:
        mean,sd=Uc[u]
        if mean>0:
            di[np.round(mean,1)].append(Ui[u])
            ds[np.round(mean,1)].append(Us[u])
            


# In[393]:

x1,y1=np.array(sorted([ (k,np.mean(v)) for k,v in di.items()])).T
x2,y2=np.array(sorted([ (k,np.mean(v)) for k,v in ds.items()])).T


# In[387]:

# distribution of average cosine
ave,std=np.array(Uc.values()).T


# In[400]:

fig = plt.figure(figsize=(8, 8),facecolor='white')
ax = fig.add_subplot(221)
for i in dist:
    x,y=dist[i]
    cR,cF,pR,pF=paras[i]
    if pR<0.05 and pF<0.05 and cR>0:
        plt.plot(x, y, 'g-',alpha=0.3)
    if pR<0.05 and pF<0.05 and cR<0:
        plt.plot(x, y, 'r-',alpha=0.3)
    #else:
    #    plt.plot(x, y, 'b-',alpha=0.3)
plt.xlim(-2,2)
#
ax = fig.add_subplot(222)
plt.hist(ave)
ax = fig.add_subplot(223)
plt.plot(x1,y1,'ro-')
plt.ylabel('impact')
plt.xlabel('similarity')
plt.xlim(0.2,0.8)
ax = fig.add_subplot(224)
plt.plot(x2,y2,'bo-')
plt.ylabel('disruption')
plt.xlabel('similarity')
plt.xlim(0.2,0.8)
#
plt.tight_layout()


# In[389]:

len(ave)


# In[396]:

plt.plot(x1,y1,'ro-')
plt.ylabel('impact')
plt.xlabel('similarity')
plt.xlim(0.2,0.8)


# In[397]:

plt.plot(x2,y2,'bo-')
plt.ylabel('disruption')
plt.xlabel('similarity')
plt.xlim(0.2,0.8)


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[362]:

plt.plot(x1,z1,'b.',alpha=0.3)
plt.plot(x,y,'ro-')
plt.ylabel('disruption')
plt.xlabel('similarity')
#plt.ylim(-0.004,0.01)


# In[363]:

plt.plot(y1,z1,'g.',alpha=0.3)
plt.plot(k,t,'ro-')
plt.ylabel('disruption')
plt.xlabel('similarity')


# In[ ]:




# In[ ]:




# In[263]:

tP=[]
bP=[]
n=0
for i in vectors:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    vs=vectors[i]
    #cs=[vs[j] for j in posV]
    if vs[68]>2.5:
        tP.append(i)
    if vs[68]<-2.5:
        bP.append(i)
len(tP),len(bP)


# In[264]:

for i in tP[:7]:
    print (Abstract[i])
    print ('____________')


# In[265]:

for i in bP:
    print (Abstract[i])
    print ('____________')


# In[ ]:




# In[ ]:




# In[191]:

PaperToSubject={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperSubject.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        PaperToSubject[line[0]]=line[1:]
        
n=0
PaperToJournal={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperJournal.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        PaperToJournal[line[0]]=line[1]


# In[192]:

SubjectToField={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/fields.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        SubjectToField[int(line[0])]=line[1]


# In[208]:

fs=defaultdict(lambda:0)
for i in topPos:
    try:
        fs[SubjectToField[PaperToSubject[i][0]]]+=1
    except:
        pass


# In[209]:

fs


# In[ ]:




# In[196]:

JournalName={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        JournalName[int(line[0])]=line[1]

SubjectName={}
NameSubject={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/subject.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        SubjectName[int(line[0])]=line[1]
        NameSubject[line[1]]=int(line[0])
        
FieldName={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and information technology',
5:'Engineering',
6:'Environmental and earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}
        
SubjectToField={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/fields.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        SubjectToField[int(line[0])]=line[1]
        
FieldOfSubject=defaultdict(lambda:set([]))
for s in SubjectToField:
    f = SubjectToField[s]
    FieldOfSubject[f].add(s)


# In[ ]:



