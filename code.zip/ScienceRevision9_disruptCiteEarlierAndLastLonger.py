
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
from openpyxl import load_workbook
from mpl_toolkits.axes_grid1 import host_subplot
from scipy import stats
#WOS:A19641683C00003	2720466

def flushPrint(www):
    sys.stdout.write('\r')
    sys.stdout.write('%s' % www)
    sys.stdout.flush()
    
# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,11):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b


# In[2]:

# papers
W1=defaultdict(lambda:{})
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]


# In[30]:

DisruptionPaper=[v[2] for v in W1.values()]


# In[43]:

ds=random.sample(DisruptionPaper,100)
stats.percentileofscore(ds,0)


# In[45]:

S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[3]:

Wmp={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperImpactMedian.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,medianImp=line.strip().split('\t')
        Wmp[int(paper)]=float(medianImp)


# In[5]:

#aggregate data by team size
#popPaper=defaultdict(lambda:[])
depPaper=defaultdict(lambda:[])
#slbPaper=defaultdict(lambda:[])
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)#241
    #if i in S1 and i in Wmp:
    teamsize,impact,disruption,timegap,meanimp=W1[i]
    #s=stats.percentileofscore(ds,disruption)
    #s=int(np.round(s/10))
    s=np.round(disruption,1)
    depPaper[s].append(timegap)
    #slbPaper[s].append(S1[i])
    #popPaper[s].append(Wmp[i])


# In[7]:

xdepPaper,ydepPaper=np.array(sorted([(k,np.mean(v))                                      for k,v in depPaper.items() if len(v)>0])).T


# In[94]:

'''
xslbPaper,yslbPaper=np.array(sorted([(k,np.mean(v)) \
                                     for k,v in slbPaper.items()if len(v)>0])).T
xpopPaper,ypopPaper=np.array(sorted([(k,np.median(v)) \
                                     for k,v in popPaper.items()if len(v)>0])).T
'''


# In[13]:

fig = plt.figure(figsize=(6, 5),facecolor='white')
ax = fig.add_subplot(111)
plt.plot(xdepPaper,ydepPaper,linewidth=1,marker='o',color='#117733')
plt.xlabel('Disruption',fontsize=20)
plt.ylabel('Reference age',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/disruptCiteEarlier.pdf')


# In[ ]:



