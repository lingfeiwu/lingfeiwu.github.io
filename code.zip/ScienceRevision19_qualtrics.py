
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# In[2]:

import re, urllib2
import numpy as np
from bs4 import BeautifulSoup


# In[3]:

Address = 'https://www.dropbox.com/sh/y9ec7x5opyly8q9/AAAtvTmYNhTLokTuISnpgspha?dl=0'


# In[6]:

html = urllib2.urlopen(Address).read()
soup = BeautifulSoup(html)


# In[17]:


with open(r'/Users/lingfeiw/Documents/test.htm', "r") as f:
    page = f.read()
soup = BeautifulSoup(page)


# In[14]:

links = soup.findAll("downloadTestUrl")
links 


# In[8]:


t = set([ link["href"] for link in links if link.has_attr('href')])


# In[ ]:




# In[ ]:




# In[19]:

from imgurpython import ImgurClient


# In[20]:

client_id = 'YOUR CLIENT ID'
client_secret = 'YOUR CLIENT SECRET'
client = ImgurClient(client_id, client_secret)


# In[ ]:



