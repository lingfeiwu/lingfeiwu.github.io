
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    


# In[187]:

#1.year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[192]:

n=0
m=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if line[:2]>=1954:
            m+=1


# In[193]:

n=0
k=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if Y[p]>=1954:
            k+=len(line[1:])


# In[194]:

m,k


# # prepare paper 2 authors

# In[8]:

'''
#institutions of authors
B=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        a=line[0]
        v=map(int,line[1:])
        for j in v:
            B[j].append(a)
            
# export institutions and emails
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/authorListNameDis.txt', "wb") as f:
    for i in B:
        f.write(str(i)+'\t'+'\t'.join(B[i]) + '\n')
'''


# # remove self cites from Ref

# In[4]:

n=0
R={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:#314
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        R[line[0]]=line[1:]


# In[5]:

len(R)


# In[39]:

#remove self-cite
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/orcid/disambiguationFinalFinalFinal.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#818
        line=line.strip().split('\t')
        u=line[0]
        v=map(int,line[1:])
        v=sorted([i for i in v if i in R])
        if v:
            for k,i in enumerate(v):
                sc=set(v[:k]).intersection(R[i])
                for j in sc:
                    R[i].remove(j)


# In[41]:

with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "wb") as f:
    for i in R:
        f.write(str(i)+'\t'+'\t'.join(map(str,R[i])) + '\n')


# In[45]:

R[378466]


# # compare n citations before and after the removal of self-citations

# In[2]:

n=0
A=defaultdict(lambda:0)
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        for j in line[1:]:
            A[j]+=1


# In[3]:

n=0
a=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        a+=len(line)-1


# In[5]:

n=0
B=defaultdict(lambda:0)
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        for j in line[1:]:
            B[j]+=1


# In[7]:

n=0
b=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015_nonSelfCite.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        b+=len(line)-1


# In[8]:

len(A),len(B),a,b


# In[12]:

(a-b+0.0)/a


# In[16]:

28607001/42045077 


# In[ ]:




# In[13]:

p=defaultdict(lambda:0)
n=0
for i in A:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in B:
        c=(A[i]-B[i])/float(A[i])
        p[np.round(c,1)]+=1


# In[15]:

1-float(p[0])/sum(p.values())#no self-citation


# In[30]:

sum(p.values())


# In[38]:

x,y=np.array(sorted(p.items())).T
y=y/float(y.sum())


# In[51]:

sum(x*y)/sum(x)


# In[18]:

T={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            T[int(Id)]=int(teamsize)


# In[19]:

p1=defaultdict(lambda:[])
p2=defaultdict(lambda:[])
n=0
for i in A:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in B and i in T:
        c=(A[i]-B[i])/float(A[i])
        m=T[i]
        p1[A[i]].append(c)
        p2[m].append(c)


# In[20]:

x1,y1=np.array(sorted([(k,np.mean(v)) for k,v in p1.items()])).T
x2,y2=np.array(sorted([(k,np.mean(v)) for k,v in p2.items()])).T


# In[42]:

fig = plt.figure(figsize=(12, 8),facecolor='white')
ax = fig.add_subplot(231)
#
plt.plot(x,y,'bo-')
plt.xlabel('Self-citation fraction',fontsize=16)
plt.ylabel('Probability',fontsize=16)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(232)
plt.plot(x1,y1,'bo-')
plt.xlabel('Citations',fontsize=16)
plt.ylabel('Self-citation fraction',fontsize=16)
plt.xlim(1,30)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(233)
plt.plot(x2,y2,'go-')
plt.xlabel('Team size',fontsize=16)
plt.ylabel('Self-citation fraction',fontsize=16)
plt.xlim(1,20)
plt.ylim(0,0.3)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(234)
plt.plot(x1,y1,'bo-')
plt.xlabel('Citations',fontsize=16)
plt.ylabel('Self-citation fraction',fontsize=16)
plt.xlim(1,1000)
plt.xscale('log')
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(235)
plt.plot(x1,y1,'bo-')
plt.xlabel('Citations',fontsize=16)
plt.ylabel('Self-citation fraction',fontsize=16)
plt.xlim(1,1000)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(236)
plt.plot(x2,y2,'go-')
plt.xlabel('Team size',fontsize=16)
plt.ylabel('Self-citation fraction',fontsize=16)
plt.xlim(1,100)
plt.ylim(0,0.5)
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/selfcite.pdf')


# In[ ]:




# In[186]:




# In[ ]:



