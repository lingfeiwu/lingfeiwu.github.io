
# coding: utf-8

# In[2]:

get_ipython().magic(u'matplotlib inline')
import sys
from scipy import stats
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
from matplotlib import collections  as mc
import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()
    
def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

def log2linearBin(x,y):
    x=[np.round(i,0) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(np.round(np.exp2(i),0),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(sorted(newlist)).T
    return nx,ny

def log2linearBinInt(x,y):
    x=[int(i) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(int(np.exp2(i)),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(newlist).T
    return nx,ny

# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in sorted(dic.keys()):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b


# In[22]:

m=np.array(range(1,11))
plt.plot(m,33*(2.4*m**-0.05-1.0)/(2.4*m**-0.05-2.0))
#plt.plot(m,1.0/(m**-0.05-2))


# In[2]:

hexcols = ['#332288', '#88CCEE', '#44AA99', '#117733', '#999933', '#DDCC77', 
           '#CC6677', '#882255', '#AA4499', '#661100', '#6699CC', '#AA4466',
           '#4477AA']
fig = plt.figure(figsize=(4, 6),facecolor='white')
for i in range(len(hexcols)):
    plt.plot(1,i,marker='s',markersize=12,color=hexcols[i])
    plt.text(1.02,i,hexcols[i],fontsize=10)
plt.ylim(-1,14)
plt.xlim(0.98,1.05)
plt.show()


# # The decline of small teams

# In[4]:

n=0
m=0
W1={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        W1[int(Id)]=[int(year),int(teamsize),int(impact)]
        if int(year)==2010:
            m+=1


# In[5]:

m


# In[14]:

n=0
W1={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        W1[int(Id)]=[int(year),int(teamsize),int(impact)]
W2={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize,  disruptiveness, impact=line.strip().split('\t')
        W2[Id]=[int(date[:4]),int(teamsize),int(impact)]


# In[75]:

n=0
W3={}
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubStats.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, year, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if int(impact)>0 and int(teamsize)>=1:
            W3[int(Id)]=[int(year),int(teamsize),int(impact)]


# In[70]:

K3=defaultdict(lambda:defaultdict(lambda:0))
n=0
for i in W3:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    year,ts,im=W3[i]
    if year in [2011,2012,2013,2014]:
        K3[year][ts]+=1


# In[74]:

gts=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/github/GitHubStats.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, year, teamsize,  disruptiveness, impact=line.strip().split('\t')
        year=int(year)
        teamsize=int(teamsize)
        if int(impact)>0 and 2011<=year<=2014 and 1<=int(teamsize):
            gts[year].append(teamsize)
gxm,gym=np.array(sorted([(k,np.mean(v)) for k,v in gts.items()])).T
gx,gys=np.array(sorted([(k,(v.count(1)+v.count(2)+v.count(3)+0.0)/len(v)) for k,v in gts.items()])).T
gyl=1-gys


# In[82]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(12, 4),facecolor='white')
ax = fig.add_subplot(131)
n=0
for year in [2011,2012,2013,2014]:
    n+=1
    x,y=np.array(K3[year].items()).T
    y=y/float(y.sum())
    plt.plot(x,y,color=cmap(n),alpha=n/4.0,linewidth=2,label=str(year))
ax.legend(loc=1,numpoints=1,fontsize=14,frameon=False)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.title('Software',fontsize=24)
plt.yscale('log')
plt.xlim(1,10)
plt.ylim(0.001,1)
ax.tick_params(axis='both', which='major', labelsize=14)

#
#
ax = fig.add_subplot(132)
plt.plot(gxm,gym,color='#AA4466',marker='',linewidth=2,linestyle='-')
#plt.xlabel('year',fontsize=20)
plt.ylabel(r'$<m>$',fontsize=20)
plt.title('Software',fontsize=24)
plt.xlim(2011,2014)
plt.xticks([2011,2012,2013,2014],rotation=45)
ax.set_xticklabels(map(str,[2011,2012,2013,2014]))
ax.tick_params(axis='both', which='major', labelsize=14)
#
#
ax = fig.add_subplot(133)
#
#
plt.plot(gx,gys,color=hexcols[0],linewidth=2,label='m <=3')
plt.plot(gx,gyl,color=hexcols[5],linewidth=2,label='m >3')
plt.xlabel('year',fontsize=20)
plt.ylabel('Percentage',fontsize=20)
plt.legend(loc='center left',fontsize=14,numpoints=1,frameon=False)
plt.title('Software',fontsize=24)
plt.xlim(2011,2014)
plt.xticks([2011,2012,2013,2014],rotation=45)
ax.set_xticklabels(map(str,[2011,2012,2013,2014]))
ax.tick_params(axis='both', which='major', labelsize=14)


#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S1.Software.pdf')


# In[4]:

K1=defaultdict(lambda:defaultdict(lambda:0))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    year,ts,im=W1[i]
    if year in [1954,1964,1974,1984,1994,2004,2014]:
        K1[year][ts]+=1
K2=defaultdict(lambda:defaultdict(lambda:0))
n=0
for i in W2:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    year,ts,im=W2[i]
    if year in [1976,1984,1994,2004,2014]:
        K2[year][ts]+=1


# In[8]:

pts=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize,  disruptiveness, impact=line.strip().split('\t')
        year=int(date[:4])
        pts[year].append(int(teamsize))
pxm,pym=np.array(sorted([(k,np.mean(v)) for k,v in pts.items()])).T
px,pys=np.array(sorted([(k,(v.count(1)+v.count(2)+v.count(3)+0.0)/len(v)) for k,v in pts.items()])).T
pyl=1-pys

bts=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        year=int(year)
        bts[year].append(int(teamsize))
bxm,bym=np.array(sorted([(k,np.mean(v)) for k,v in bts.items()])).T
bx,bys=np.array(sorted([(k,(v.count(1)+v.count(2)+v.count(3)+0.0)/len(v)) for k,v in bts.items()])).T
byl=1-bys


# In[ ]:




# In[722]:

cmap = cm.get_cmap('rainbow',7)
fig = plt.figure(figsize=(12, 8),facecolor='white')
ax = fig.add_subplot(231)
n=0
for year in [1954,1964,1974,1984,1994,2004,2014]:
    n+=1
    x,y=np.array(K1[year].items()).T
    y=y/float(y.sum())
    plt.plot(x,y,color=cmap(n),alpha=n/7.0,linewidth=2,label=str(year))
ax.legend(loc=1,numpoints=1,fontsize=14,frameon=False)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.title('Articles',fontsize=24)
plt.xlim(1,10)
plt.ylim(0,0.6)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(234)
cmap = cm.get_cmap('rainbow',5)
n=0
for year in [1976,1984,1994,2004,2014]:
    n+=1
    x,y=np.array(sorted(K2[year].items())).T
    y=y/float(y.sum())
    plt.plot(x,y,color=cmap(n),alpha=n/5.0,linewidth=2,label=str(year))
ax.legend(loc=1,numpoints=1,fontsize=14,frameon=False)
plt.xlabel('team size '+r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xlim(1,10)
plt.ylim(0,0.6)
plt.title('Patents',fontsize=24)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(235)
plt.plot(pxm,pym,color='#AA4466',marker='',linewidth=2,linestyle='-')
#plt.xlabel('year',fontsize=20)
plt.ylabel(r'$<m>$',fontsize=20)
plt.title('Patents',fontsize=24)
plt.xticks(np.arange(1975, 2015+1, 10),rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(232)
plt.plot(bxm,bym,color='#AA4466',marker='',linewidth=2,linestyle='-')
#plt.xlabel('year',fontsize=20)
plt.ylabel(r'$<m>$',fontsize=20)
plt.title('Articles',fontsize=24)
plt.xlim(1955,2015)
plt.ylim(2.0,5.5)
plt.xticks(np.arange(1955, 2015+1, 10),rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(236)
plt.plot(px,pys,color=hexcols[0],linewidth=2,label='m <=3')
plt.plot(px,pyl,color=hexcols[5],linewidth=2,label='m >3')
#plt.xlabel('year',fontsize=20)
plt.ylabel('Percentage',fontsize=20)
plt.title('Patents',fontsize=24)
plt.legend(loc='center left',fontsize=14,numpoints=1,frameon=False)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xticks(np.arange(1975, 2015+1, 10),rotation=45)
#
ax = fig.add_subplot(233)
#
#
plt.plot(bx,bys,color=hexcols[0],linewidth=2,label='m <=3')
plt.plot(bx,byl,color=hexcols[5],linewidth=2,label='m >3')
#plt.xlabel('year',fontsize=20)
plt.ylabel('Percentage',fontsize=20)
plt.legend(loc='center left',fontsize=14,numpoints=1,frameon=False)
plt.title('Articles',fontsize=24)
plt.xlim(1955,2015)
plt.xticks(np.arange(1955, 2015+1, 10),rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)


#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S1.pdf')


# # Teamsize moderates citation dynamics

# In[29]:

t2010=defaultdict(lambda:defaultdict(lambda:0))
k2010=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference2005_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#116
        line=map(int,line.strip().split('\t'))
        p = line[0]
        cites = line[1:]
        if p in W1 and W1[p][0]==2010:
            ts=W1[p][1]
            if 1<=ts<=10:
                for j in cites:
                    if j in W1:
                        gap=2010-W1[j][0]
                        if gap>0:
                            t2010[ts][gap]+=1
                            if gap ==5:
                                imp=W1[j][2]
                                if imp>=1:
                                    k2010[ts][imp]+=1


# In[ ]:




# In[30]:

t1981=defaultdict(lambda:defaultdict(lambda:0))
k1981=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2000.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        p = line[0]
        cites = line[1:]
        if p in W1 and W1[p][0]==1981:
            ts=W1[p][1]
            if 1<=ts<=10:
                for j in cites:
                    if j in W1:
                        gap=1981-W1[j][0]
                        if gap>0:
                            t1981[ts][gap]+=1
                            if gap ==5:
                                imp=W1[j][2]
                                if imp>=1:
                                    k1981[ts][imp]+=1


# In[31]:

def OLSRegressFit(x,y):
   xx = sm.add_constant(x, prepend=True)
   res = sm.OLS(y,xx).fit()
   constant, beta = res.params
   r2 = res.rsquared
   return [constant,beta]


# In[13]:

len(t2010)


# In[32]:

ps={}
for ts in range(1,11):
    x,y=np.array(t2010[ts].items()).T
    y=y/float(y.sum())
    constant,beta=OLSRegressFit(x,np.log(y))
    mean=sum(x*y)
    ps[ts]=constant,beta,mean


# In[33]:

constant1,beta1=OLSRegressFit(np.log(range(1,11)),np.log([-ps[ts][1] for ts in range(1,11)]))
constant1,beta1


# In[34]:

ts=1
x1,y1=np.array(sorted(k2010[ts].items())).T
y1=y1/float(y1.sum())
ts=5
x5,y5=np.array(sorted(k2010[ts].items())).T
y5=y5/float(y5.sum())
ts=10
x10,y10=np.array(sorted(k2010[ts].items())).T
y10=y10/float(y10.sum())

import powerlaw

kps=[]
for ts in range(1,11):
    data=[]
    for k,v in k2010[ts].items():
        data+=[k]*v
    mk=np.mean(data)
    results = powerlaw.Fit(data,xmin=500)
    alpha=results.power_law.alpha
    kps.append([ts,alpha,mk])

ak,bk,ck=np.array(kps).T
constant2,beta2=OLSRegressFit(np.log(ak),np.log(bk))


# In[35]:

beta1,beta2


# In[36]:

np.exp(constant2)


# In[39]:

-constant1


# In[736]:

fig = plt.figure(figsize=(12, 8),facecolor='white')
ax = fig.add_subplot(231)
cmap = {5:'orange',10:'ForestGreen',1:'RoyalBlue'}
for ts in [1,5,10]:
    x,y=np.array(t2010[ts].items()).T
    y=y/float(y.sum())
    constant,beta,et=ps[ts]
    xs=np.linspace(1,110)
    plt.scatter(x,y,facecolor='none',edgecolor=cmap[ts],alpha=1)
    plt.plot(xs,np.exp(constant+beta*xs),color=cmap[ts],label='m='+str(ts))
plt.yscale('log')
ax.legend(loc=1,scatterpoints=1,fontsize=14,frameon=False)
plt.xlabel('Reference Age in Years '+r'$t$',fontsize=16)
plt.ylabel(r'$P(t)$',fontsize=16)
#plt.title('',fontsize=24)
plt.xlim(1,110)
plt.ylim(10**-7,1)
plt.ylim(0,0.15)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(232)
plt.plot(range(1,11),[-ps[ts][1] for ts in range(1,11)],         marker='o',color='Chocolate',linestyle='')
plt.plot(np.linspace(1,10,100),np.exp(constant1)*np.linspace(1,10,100)**beta1,'r-')
plt.xlim(1,10)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$\lambda$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(233)
plt.plot(range(1,11),[ps[ts][2] for ts in range(1,11)],         marker='s',color='SteelBlue',linestyle='')
plt.plot(np.linspace(1,10,100),np.exp(-constant1)*np.linspace(1,10,100)**-beta1,'r-')
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$<t>$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(234)
plt.scatter(x1,y1,edgecolor='RoyalBlue',facecolor='none')
plt.scatter(x5,y5,edgecolor='Orange',facecolor='none')
plt.scatter(x10,y10,edgecolor='ForestGreen',facecolor='none')
xs=np.linspace(50,500,100)
plt.plot(xs,2*np.exp(2.3)*xs**-2.4,color='RoyalBlue',label='m=1')
plt.plot(xs,3*np.exp(2)*xs**-2.3,color='orange',label='m=5')
plt.plot(xs,4*np.exp(1.7)*xs**-2.2,color='ForestGreen',label='m=10')
plt.xscale('log')
plt.yscale('log')
plt.xlim(1,10**4)
plt.ylim(10**-5,0.1)
ax.legend(loc=1,scatterpoints=1,fontsize=14,frameon=False)
plt.xlabel('Reference Popularity '+r'$k$',fontsize=16)
plt.ylabel(r'$P(k)$',fontsize=16)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(235)
plt.plot(ak,bk,marker='o',color='purple',linestyle='')
ms=np.linspace(1,10)
alpha=np.exp(constant2)*ms**beta2
plt.plot(ms,alpha,'r-')
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$\alpha$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(236)
plt.plot(ak,ck,'g^')
plt.plot(ms,33*(alpha-1)/(alpha-2),'r-')
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$<k>$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S2.pdf')


# # Robustness of disruption and impact 

# ### with time window

# # Long term impact

# In[2]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(teamsize)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(teamsize),int(impact),float(disruptive)]


# In[3]:

drss=[v[-1] for v in W1.values()]
trss=[v[1] for v in W1.values()]


# In[4]:

ds10,ds55,ds65,ds90=np.percentile(drss,10),np.percentile(drss,55),np.percentile(drss,65),np.percentile(drss,90)
ds10,ds55,ds65,ds90


# In[5]:

ts10,ts50,ts90=np.percentile(trss,10),np.percentile(trss,50),np.percentile(trss,90)
ts10,ts50,ts90


# In[6]:

Dis1=set([])
Dis2=set([])
Dis3=set([])
Team1=set([])
Team2=set([])
Team3=set([])
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    year,ts,im,disr=W1[i]
    if 200<=im<=300:
        if disr<ds10:
            Dis1.add(i)
        if ds55<=disr<=ds65:
            Dis2.add(i)
        if disr>ds90:
            Dis3.add(i)
        if ts==1:
            Team1.add(i)
        if ts==5:#3
            Team2.add(i)
        if ts==10:#7
            Team3.add(i)


# In[7]:

seeds=set(list(Dis1)+list(Dis2)+list(Dis3)+list(Team1)+list(Team2)+list(Team3))


# In[8]:

Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        doi,ndoi,year=line.strip().split('\t')
        Y[int(ndoi)]=int(year)


# In[9]:

dis1=defaultdict(lambda:defaultdict(lambda:0))
dis2=defaultdict(lambda:defaultdict(lambda:0))
dis3=defaultdict(lambda:defaultdict(lambda:0))
team1=defaultdict(lambda:defaultdict(lambda:0))
team2=defaultdict(lambda:defaultdict(lambda:0))
team3=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=map(int,line.strip().split('\t'))
        paper=line[0]
        if paper in Y:
            year=Y[paper]
            cites=line[1:]
            for j in cites:
                if j in seeds:
                    yearj=Y[j]
                    deltayear=year-yearj
                    if j in Dis1:
                        dis1[j][deltayear]+=1
                    if j in Dis2:
                        dis2[j][deltayear]+=1
                    if j in Dis3:
                        dis3[j][deltayear]+=1
                    if j in Team1:
                        team1[j][deltayear]+=1
                    if j in Team2:
                        team2[j][deltayear]+=1
                    if j in Team3:
                        team3[j][deltayear]+=1


# In[10]:

def ra(x,N): return np.convolve(x, np.ones((N,))/N, mode='valid')

def normdata(Dis):
    M=[]
    for i in Dis:
        if len(Dis[i])>1:
            ys=[]
            for j in range(101):
                if j in Dis[i]:
                    ys.append(Dis[i][j])
                else:
                    ys.append(0)
            ys=np.array(ys)/(float(sum(ys))+0.01)
            M.append(ys)
    a,b = np.mean(M,axis=0),np.std(M,axis=0)
    a=ra(a,5)
    b=ra(b,5)
    return a,b


# In[11]:

x1,y1=normdata(dis1)
x2,y2=normdata(dis2)
x3,y3=normdata(dis3)
x4,y4=normdata(team1)
x5,y5=normdata(team2)
x6,y6=normdata(team3)


# In[64]:

fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(121)
plt.plot(x4,label='Team size = 1',linewidth=2,color='ForestGreen')
plt.fill_between(range(97),x4-y4/2,x4+y4/2,alpha=0.05,color='ForestGreen')
plt.plot(x5,label='Team size = 5',linewidth=2,color='RoyalBlue')
plt.fill_between(range(97),x5-y5/2,x5+y5/2,alpha=0.05,color='RoyalBlue')
plt.plot(x6,label='Team size = 10',linewidth=2,color='Orange')
plt.fill_between(range(97),x6-y6/2,x6+y6/2,alpha=0.05,color='Orange')
plt.ylim(0,0.13)
plt.legend(loc=1,fontsize=14,frameon=False)
plt.xlabel('Age',fontsize=18)
plt.ylabel('Citations',fontsize=18)
plt.xlim(0,50)
plt.xticks(np.arange(0, 51, 10))
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/smallTeamLonger.pdf')


# In[30]:

S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[32]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(subject),int(year),int(teamsize),float(timegap),float(meanimp),float(impact),float(disruptive)]


# In[ ]:

sleepSample=random.sample(S1.values(),100000)


# In[169]:

SlepField=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in S1:
        subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
        sleep=S1[i]
        if subject not in [7,8,9,11] and impact>=5:
            if subject ==2:
                subject=13
            SlepField[subject][teamsize].append(sleep)


# In[171]:

slepField={}
for subject in SlepField:
    slepField[subject]=zip(*sorted([(k,np.median(v)) for k,v in SlepField[subject].items()]))
slepField1={}
for subject in slepField:
    x,y=slepField[subject]
    ys=[stats.percentileofscore(sleepSample, i) for i in y]
    slepField1[subject]=[x,ys]


# In[137]:

SlepFieldD=defaultdict(lambda:defaultdict(lambda:[]))
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in S1:
        subject, year,teamsize,timegap,meanimp,impact,disruptive=W1[i]
        sleep=S1[i]
        if subject not in [7,8,9,11] and impact>=5:
            if subject ==2:
                subject=13
            d=np.round(disruptive,1)
            SlepFieldD[subject][d].append(sleep)


# In[184]:

slepFieldD={}
for subject in SlepFieldD:
    slepFieldD[subject]=zip(*sorted([(k,np.median(v)) for                                      k,v in SlepFieldD[subject].items() if len(v)>=10]))

slepField1D={}
for subject in slepFieldD:
    if slepFieldD[subject]:
        x,y=slepFieldD[subject]
        ys=[stats.percentileofscore(sleepSample, i) for i in y]
        slepField1D[subject]=[x,ys]


# In[152]:

fd={
0:'Agriculture',
1:'Biology',
2:'Business and management',
3:'Chemistry',
4:'Computer and \n information technology',
5:'Engineering',
6:'Environmental and \n earth sciences',
7:'Humanities',
8:'Law',
9:'Mathematics',
10:'Medicine',
11:'Multidisciplinary Sciences',
12:'Physical sciences',
13:'Social sciences'}
cs={12:'#800000',1:'#FF1400',10:'#FF7D00',    6:'#C69C6D',    3:'#79BA3A',0:'#39B2A3',13:'#0070B5',    5:'#ABC7D6',4:'#B3B3B3'}


# In[180]:


fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(121)
cmap1 = cm.get_cmap('rainbow',9)
#cmap2 = cm.get_cmap('jet_r',len(slepField)+1)
n=0
for subject in [12,1,13,10,3,0,6,5,4][::-1]:
    x,y=slepField1[subject]
    n+=1
    plt.plot(x,y,color=cs[subject],linewidth=2,label=fd[subject])

plt.ylim(20,80)
#plt.legend(loc=1,fontsize=8,frameon=False)
handles, labels = ax.get_legend_handles_labels()
ax.legend(reversed(handles), reversed(labels), loc=3,fontsize=8,frameon=False)  # reverse to keep order consistent
plt.xlabel('Team size',fontsize=18)
plt.ylabel('Sleeping Beauty Index Percentile',fontsize=18)
plt.xlim(1,10)
#plt.xticks(np.arange(0, 51, 10))
ax.tick_params(axis='both', which='major', labelsize=14)

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/smallTeamLonger2.pdf')


# In[185]:


fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(121)
cmap1 = cm.get_cmap('rainbow',9)
#cmap2 = cm.get_cmap('jet_r',len(slepField)+1)
n=0
for subject in [12,1,10,6,3,0,13,5,4][::-1]:
    x,y=slepField1D[subject]
    n+=1
    plt.plot(x,y,color=cs[subject],linewidth=2,label=fd[subject])
    
plt.ylim(40,100)
#plt.legend(loc=1,fontsize=8,frameon=False)
handles, labels = ax.get_legend_handles_labels()
ax.legend(reversed(handles), reversed(labels), loc=4,fontsize=8,frameon=False)  # reverse to keep order consistent
plt.xlabel('Disruption',fontsize=18)
plt.ylabel('Sleeping Beauty Index Percentile',fontsize=18)
#plt.xlim(1,10)
#plt.xticks(np.arange(0, 51, 10))
ax.tick_params(axis='both', which='major', labelsize=14)

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/disruptTeamLonger.pdf')


# In[ ]:




# In[ ]:




# In[67]:

fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(122)
plt.plot(x3,label='Disrupting',linewidth=2,color='ForestGreen')
plt.fill_between(range(97),x3-y3/2,x3+y3/2,alpha=0.05,color='ForestGreen')
plt.plot(x2,label='Average',linewidth=2,color='RoyalBlue')
plt.fill_between(range(97),x2-y2/2,x2+y2/2,alpha=0.05,color='RoyalBlue')
plt.plot(x1,label='Developing',linewidth=2,color='Orange')
plt.fill_between(range(97),x1-y1/2,x1+y1/2,alpha=0.05,color='Orange')
plt.ylim(0,0.12)
plt.legend(loc=1,fontsize=14,frameon=False)
plt.xlabel('Age',fontsize=18)
plt.ylabel('Citations',fontsize=18)
plt.xlim(0,50)
plt.xticks(np.arange(0, 51, 10))
ax.tick_params(axis='both', which='major', labelsize=14)

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/disruptiveTeamLonger.pdf')


# In[84]:

fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(122)
plt.plot(x3,label='Top 10% DP',linewidth=2)
plt.fill_between(range(97),x3-y3/2,x3+y3/2,alpha=0.05,color='blue')
plt.plot(x2,label='Middle 10% DP',linewidth=2)
plt.fill_between(range(97),x2-y2/2,x2+y2/2,alpha=0.05,color='green')
plt.plot(x1,label='Bottom 10% DP',linewidth=2)
plt.fill_between(range(97),x1-y1/2,x1+y1/2,alpha=0.05,color='red')
plt.ylim(0,0.12)
plt.legend(loc=1,fontsize=14,frameon=False)
plt.xlabel('Years since publication',fontsize=20)
plt.ylabel('Yearly citation',fontsize=20)
plt.xlim(0,50)
plt.xticks(np.arange(0, 51, 10))
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(121)
plt.plot(x4,label='m=1',linewidth=2)
plt.fill_between(range(97),x4-y4/2,x4+y4/2,alpha=0.05,color='blue')
plt.plot(x5,label='m=3',linewidth=2)
plt.fill_between(range(97),x5-y5/2,x5+y5/2,alpha=0.05,color='green')
plt.plot(x6,label='m=7',linewidth=2,color='red')
plt.fill_between(range(97),x6-y6/2,x6+y6/2,alpha=0.05,color='red')
plt.ylim(0,0.12)
plt.legend(loc=1,fontsize=14,frameon=False)
plt.xlabel('Years since publication',fontsize=20)
plt.ylabel('Yearly citation',fontsize=20)
plt.xlim(0,50)
plt.xticks(np.arange(0, 51, 10))
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S7.pdf')


# # Patent comparison

# In[86]:

#patents
W2={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStat.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id, date, teamsize,  disruptiveness, impact=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W2[Id]=[int(date[:4]),int(teamsize),int(impact),float(disruptiveness)]
Patent={}
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentStatTwoNetworks.txt','rb') as f:
    for line in f:
        line=line.strip().split('\t')
        i, year, ts,ie,dise,ia,disa=line
        Patent[i]=[int(year),int(ts),int(ie),float(dise),int(ia),float(disa)]


# In[88]:

DDE=defaultdict(lambda:[])
IIE=defaultdict(lambda:[])
DDA=defaultdict(lambda:[])
IIA=defaultdict(lambda:[])


n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentNetworkExaminer.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in W2:
            teamsize=W2[p][1]
            year2=W2[p][0]
            if 1<=teamsize<=10 and year2 ==2009:
                gs=[year2-W2[j][0] for j in line[1:] if j in W2 and W2[j][0]<=year2]
                degrees=[W2[j][2] for j in line[1:] if j in W2]
                if gs:
                    DDE[teamsize].append(np.mean(gs))
                    IIE[teamsize].append(np.mean(degrees))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/patent/patentNetworkApplicant.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=line[0]
        if p in W2:
            teamsize=W2[p][1]
            year2=W2[p][0]
            if 1<=teamsize<=10 and year2 ==2009:
                gs=[year2-W2[j][0] for j in line[1:] if j in W2 and W2[j][0]<=year2]
                degrees=[W2[j][2] for j in line[1:] if j in W2]
                if gs:
                    DDA[teamsize].append(np.mean(gs))
                    IIA[teamsize].append(np.mean(degrees))


# In[90]:

xdde,ydde=zip(*sorted([(k,np.mean(v)) for k,v in DDE.items()]))
xiie,yiie=zip(*sorted([(k,np.median(v)) for k,v in IIE.items()]))
xdda,ydda=zip(*sorted([(k,np.mean(v)) for k,v in DDA.items()]))
xiia,yiia=zip(*sorted([(k,np.median(v)) for k,v in IIA.items()]))

DisPatentE=defaultdict(lambda:[])
ImpPatentE=defaultdict(lambda:[])
DisPatentA=defaultdict(lambda:[])
ImpPatentA=defaultdict(lambda:[])

for i in Patent:
    year, ts, ie,dise,ia,disa=Patent[i]
    if 1<=ts<=10:
        DisPatentE[ts].append(dise)
        ImpPatentE[ts].append(ie)
        DisPatentA[ts].append(disa)
        ImpPatentA[ts].append(ia)

xdisPatentE,ydisPatentE=zip(*sorted([(k,np.mean(v)) for k,v in DisPatentE.items()]))
ximpPatentE,yimpPatentE=zip(*sorted([(k,np.mean(v)) for k,v in ImpPatentE.items()]))
xdisPatentA,ydisPatentA=zip(*sorted([(k,np.mean(v)) for k,v in DisPatentA.items()]))
ximpPatentA,yimpPatentA=zip(*sorted([(k,np.mean(v)) for k,v in ImpPatentA.items()]))


# In[92]:

fig = plt.figure(figsize=(16,4),facecolor='white')
host = fig.add_subplot(141)
host.plot(xdisPatentE,ydisPatentE,marker='',color='orange',linewidth=2,linestyle='--',label='Examiner')
host.plot(xdisPatentA,ydisPatentA,marker='',color='orange',linewidth=2,label='Applicant')
host.legend(loc='center',fontsize=14,frameon=False)
#host.set_ylim(7,13)
host.set_xlabel('team size',fontsize=20)
host.set_ylabel('Disruption',fontsize=20)
host.tick_params(axis='both', which='major', labelsize=14)
#
host = fig.add_subplot(142)
host.plot(ximpPatentE,yimpPatentE,marker='',color='SteelBlue',linewidth=2,linestyle='--',label='Examiner')
host.plot(ximpPatentA,yimpPatentA,marker='',color='SteelBlue',linewidth=2,label='Applicant')
host.legend(loc=2,fontsize=14,frameon=False)
host.set_xlabel('team size',fontsize=20)
host.set_ylabel('Citations',fontsize=20)
host.set_ylim(4,14)
host.tick_params(axis='both', which='major', labelsize=14)
#

host = fig.add_subplot(143)
host.plot(xdde,ydde,marker='',color='orange',linewidth=2,linestyle='--',label='Examiner')
host.plot(xdda,ydda,marker='',color='orange',linewidth=2,label='Applicant')
host.legend(loc=1,fontsize=14,frameon=False)
host.set_ylim(7,13)
host.set_xlabel('team size',fontsize=20)
host.set_ylabel('<Reference Age>',fontsize=20)
host.tick_params(axis='both', which='major', labelsize=14)
#
host = fig.add_subplot(144)
host.plot(xiie,yiie,marker='',color='SteelBlue',linewidth=2,linestyle='--',label='Examiner')
host.plot(xiia,yiia,marker='',color='SteelBlue',linewidth=2,label='Applicant')
host.legend(loc='center',fontsize=14,frameon=False)
host.set_xlabel('team size',fontsize=20)
host.set_ylabel('<Reference Popularity>',fontsize=20)
#host.set_ylim(7,13)
host.tick_params(axis='both', which='major', labelsize=14)

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S8.pdf')


# # D distribution over time

# In[28]:

K=defaultdict(lambda:defaultdict(lambda:[]))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        m=int(teamsize)
        y=int(year)
        if 1<=m<=10 and int(impact)>0 and 1954<=y<2004:
            if 1954<=y<1964:
                y=1954
            if 1964<=y<1974:
                y=1964
            if 1974<=y<1984:
                y=1974
            if 1984<=y<1994:
                y=1984
            if 1994<=y<2004:
                y=1994
            K[y][m].append(float(disruptive))


# In[29]:

K.keys()


# In[37]:

fig = plt.figure(figsize=(5, 6),facecolor='white')
ax = fig.add_subplot(111)
cmap = cm.get_cmap('rainbow_r',5)
n=0
for year in [1954,1964,1974,1984,1994]:
    x,y=zip(*sorted([(k,np.mean(v)) for k,v in K[year].items()]))
    plt.plot(x,y,color=cmap(n),linewidth=2,label=str(year))
    n+=1
plt.xlim(1,10)
#plt.ylim(8,14)
plt.ylim(-0.005,0.025)
plt.plot([1,10],[0,0],'k--')
plt.legend(loc=1,ncol=1,fontsize=10,frameon=False)
plt.xlabel('Team size',fontsize=20)
plt.ylabel('Disruption',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
plt.xticks([2,4,6,8,10])
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_Time.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[3]:

n=0
s=set([1954,1964,1974,1984,1994,2004,2014])
K1=defaultdict(lambda:defaultdict(lambda:0))
K2=defaultdict(lambda:defaultdict(lambda:0))
K3=defaultdict(lambda:[])
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=        line.strip().split('\t')
        if int(year) in s:
            K3[int(year)].append(float(disruptive))
        if int(year) in [1954,1964,1974,1984,1994,2004,2014]:
            dis=float(disruptive)
            dis1=np.round(dis,3)
            dis2=np.round(dis,4)
            K1[int(year)][dis1]+=1
            K2[int(year)][dis2]+=1


# In[11]:

# papers
m=0
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954 and int(year)==1970:
            m+=1


# In[12]:

m


# In[2]:

# papers
W1=defaultdict(lambda:{})
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            W1[int(year)][int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]


# In[24]:

#aggregate data by team size
disPaper=defaultdict(lambda:defaultdict(lambda:[]))
for year in W1:
    for i in W1[year]:
        teamsize,impact,disruption,timegap, meanimp=W1[year][i]
        disPaper[year][teamsize].append(disruption)


# In[4]:

def ra(x,N): return np.convolve(x, np.ones((N,))/N, mode='valid')


# In[5]:

data=[]
for j in [1954,1964,1974,1984,1994,2004,2014]:
    #print j,sum([k*v for k,v in K1[j].items()])/sum(K1[j].values())
    l=[]
    for k,v in K2[j].items():
        l+=[k]*v
    data.append([j,np.mean(l),np.subtract(*np.percentile(l, [75, 25]))])
xd,yd,zd=np.array(data).T


# In[36]:

cmap = cm.get_cmap('rainbow',8)
fig = plt.figure(figsize=(8, 8),facecolor='white')
ax = fig.add_subplot(221)
n=0
for year in [1954,1964,1974,1984,1994,2004,2014]:
    n+=1
    x,y=np.array(sorted(K1[year].items())).T
    y=y/float(y.sum())
    y1=ra(y,10)
    plt.plot(x[:len(y1)],y1,color=cmap(n),marker='',alpha=n/7.0,label=str(year))
ax.legend(loc=1,fontsize=10,numpoints=1,frameon=False)
plt.xlabel('Disruption'+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.yscale('log')
#plt.xlim(-0.1,0.1)
plt.ylim(10**-6,1)
ax.set_xticklabels([-1,-0.5,0,0.5,1])
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(222)
n=0
for year in [1954,1964,1974,1984,1994,2004,2014]:
    n+=1
    x,y=np.array(sorted(K2[year].items())).T
    y=y/float(y.sum())
    #y1=ra(y,10)
    plt.plot(x,y,color=cmap(n),marker='',alpha=n/7.0,label=str(year))
#ax.legend(loc=1,numpoints=1,fontsize=10)
plt.xlabel('Disruption'+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.005,-0.002,0,0.002,0.005])
ax.set_xticklabels([-0.005,-0.002,0,0.002,0.005])
#ax.axvspan(-0.002, 0.005, alpha=0.2, color='SteelBlue')
plt.yscale('log')
plt.xlim(-0.005,0.005)
plt.ylim(10**-4,1)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(223)
plt.plot(xd,yd,color='SteelBlue',marker='o')
plt.fill_between(xd,yd-zd/2,yd+zd/2,color='gray',alpha=0.1)
plt.plot([1954,2015],[0,0],color='gray',linestyle='--')
plt.xlim(1954,2014)
plt.ylim(-0.01,0.04)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Time',fontsize=20)
plt.ylabel('$<D>$',fontsize=20)
plt.xlim(1954,2014)
plt.xticks(np.arange(1954, 2014+1, 10),rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(224)
cmap = cm.get_cmap('rainbow_r',6)
n=0
for year in [1964,1964,1974,1984,1994,2004]:
    js=[j for v in disPaper[year].values() for j in v]
    if len(js)>10000:
        js=random.sample(js,10000)
    x,y=zip(*sorted([(k,np.mean(v)) for k,v in disPaper[year].items()]))
    ys=[stats.percentileofscore(js,q) for q in y]
    plt.plot(x,y,color=cmap(n),label=str(year))
    n+=1
plt.xlim(1,10)
#plt.ylim(8,14)
plt.ylim(-0.01,0.03)
plt.plot([1,10],[0,0],'k--')
plt.legend(loc=1,ncol=2,fontsize=10,frameon=False)
plt.xlabel('Team size',fontsize=20)
plt.ylabel('$D$',fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=14)
plt.xticks([2,4,6,8,10])
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S9.pdf')


# In[8]:

n=0
m=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and 1954<=int(year)<=2014:
            m+=1


# In[10]:

m,n


# In[ ]:




# In[36]:

#aggregate data by team size
dP=defaultdict(lambda:[])
cP=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=10 and int(impact)>0 and int(year)>=1954:
            dP[int(teamsize)].append(float(disruptive))
            cP[int(teamsize)].append(int(impact))


# In[73]:

Dp={}
Dp1={}
for m in dP:
    ds=dP[m]
    x,y= np.array(sorted(Counter([np.round(i,4) for i in ds if -0.005<i<0.005]).items())).T
    x1,y1= np.array(sorted(Counter([np.round(i,3) for i in ds]).items())).T
    y=y/float(y.sum())
    y1=y1/float(y1.sum())
    Dp[m]=[x,y]
    Dp1[m]=[x1,y1]


# In[37]:

Cp={}
for m in cP:
    cs=cP[m]
    x,y= np.array(sorted(Counter(cs).items())).T
    y=y/float(y.sum())
    Cp[m]=[x,y]


# In[125]:


fig = plt.figure(figsize=(12, 8),facecolor='white')
cmap = cm.get_cmap('rainbow_r',11)
#
ax = fig.add_subplot(231)
for m in range(1,11):
    x,y=Cp[m]
    plt.plot(x,y,color=cmap(m),marker='.',markersize=2,linestyle='')
plt.yscale('log')
plt.xscale('log')
plt.xlabel('Impact '+r'$C$',fontsize=20)
plt.ylabel(r'$P(C)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlim(1,10000)
#
ax = fig.add_subplot(232)
for m in range(1,11):
    x,y=Cp[m]
    plt.plot(x,y,color=cmap(m),label='m='+str(m))
plt.yscale('log')
plt.xscale('log')
plt.xlim(1,100)
plt.ylim(10**-3,0.15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Impact '+r'$C$',fontsize=20)
plt.ylabel(r'$P(C)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
ax.legend(loc=3,fontsize=10,numpoints=1,frameon=False,ncol=2)
#
#
ax = fig.add_subplot(234)
for m in range(1,11):
    x1,y1=Dp1[m]
    plt.plot(x1,y1,color=cmap(m),marker='.',markersize=2,linestyle='')
plt.yscale('log')
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Disruption '+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(235)
for m in range(1,11):
    x,y=Dp[m]
    plt.plot(x,y,color=cmap(m))
plt.yscale('log')
plt.xlim(-0.005,0.005)
plt.xticks([-0.005,-0.0025,0,0.0025,0.005],['-0.005','-0.0025','0','0.0025','0.005'],rotation=45)
plt.ylim(5*10**-4,0.2)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xlabel('Disruption '+r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=14)

#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S14_a.pdf')


# In[120]:

import scipy.stats as stats
from scipy.stats import ks_2samp
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches


# In[77]:

index=list(itertools.combinations(range(1,11), 2))


# In[78]:

ps={}
for i,j in index:
    ts,pvts=stats.ttest_ind(dP[i], dP[j], equal_var=False)
    ks,pvks=ks_2samp(cP[i], cP[j])
    ps[(i,j)]=[ts,pvts,ks,pvks]


# In[129]:

ps1={}
for i,j in index:
    ts,pvts=ks_2samp(dP[i], dP[j])
    ps1[(i,j)]=[ts,pvts]


# In[ ]:




# In[126]:

fig = plt.figure(figsize=(5,5))
gs = gridspec.GridSpec(10, 10)
for i,j in index:
    ax = plt.subplot(gs[i-1,j-1])
    ts,pvts,ks,pvks=ps[(i,j)]
    plt.xlim(0,1)
    plt.ylim(0,1)
    label=str(int(np.round(ts,0)))
    plt.text(0.5,0.5,label,fontsize=10,color='k',
             horizontalalignment='center')
    if pvts<=0.001:
        starst='***'
    if 0.001<pvts<=0.01:
        starst='**'
    if 0.01<pvts<=0.05:
        starst='*'
    plt.text(0.5,0,starst,fontsize=12,color='k',
             horizontalalignment='center') 
    plt.axvspan(0, 1, edgecolor='none',facecolor='#AA4466', alpha=ts/160.0)
    #plt.tick_params(axis='x', which='both',bottom='off',top='off', labelbottom='off')
    #plt.tick_params(axis='y', which='both',left='off', right='off')
    #plt.yticks([-30,0,30])
    plt.axis('off')
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S14_b.pdf')


# In[128]:

fig = plt.figure(figsize=(5,5))
gs = gridspec.GridSpec(10, 10)
for i,j in index:
    ax = plt.subplot(gs[i-1,j-1])
    ts,pvts,ks,pvks=ps[(i,j)]
    plt.xlim(0,1)
    plt.ylim(0,1)
    label=str(np.round(ks,2))
    plt.text(0.5,0.5,label,fontsize=10,color='k',
             horizontalalignment='center')
    if pvks<=0.001:
        starst='***'
    if 0.001<pvks<=0.01:
        starst='**'
    if 0.01<pvks<=0.05:
        starst='*'
    plt.text(0.5,0,starst,fontsize=12,color='k',
             horizontalalignment='center') 
    plt.axvspan(0, 1, edgecolor='none',facecolor='ForestGreen', alpha=ks/0.15)
    #plt.tick_params(axis='x', which='both',bottom='off',top='off', labelbottom='off')
    #plt.tick_params(axis='y', which='both',left='off', right='off')
    #plt.yticks([-30,0,30])
    plt.axis('off')
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S14_c.pdf')


# # althernative measures for disruption 

# In[4]:

n=0
W1={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=10 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(teamsize),int(impact)]


# In[3]:

n=0
D1={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/teamPerformance1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,n1,n2,n3=map(int,line.strip().split('\t'))
        D1[Id]=[n1,n2,n3]


# In[5]:

'''
f = open('/Users/lingfeiw/Documents/research/teamscience/team/novelPercentage.txt', "wb")
for i in D1:
    n1,n2,n3=D1[i]
    if n1+n2>0:
        f1=n1/(n1+n2+0.0)
        f.write(str(i)+'\t'+str(n1+n2)+'\t'+str(f1) + '\n')
f.close()
'''


# In[ ]:




# In[6]:

F1=defaultdict(lambda:[])
F2=defaultdict(lambda:[])
F3=defaultdict(lambda:[])
F4=defaultdict(lambda:[])
for i in W1:
    year,ts,imp=W1[i]
    if i in D1:
        n1,n2,n3=D1[i]
        if imp>=2 and n1+n2==imp and 1<=ts<=10 and n3>0:
            f1=n1/(n1+n2+0.0)
            f2=(n1-n2)/(n1+n2+0.0)
            f3=(n1-n2)/n3
            f4=(n1-n2)/(n1+n2+n3+0.0)
            F1[ts].append(f1) 
            F2[ts].append(f2) 
            F3[ts].append(f3) 
            F4[ts].append(f4) 


# In[8]:

f1=[np.mean(F1[ts]) for ts in range(1,11)]
f2=[np.mean(F2[ts]) for ts in range(1,11)]
f3=[np.mean(F3[ts]) for ts in range(1,11)]
f4=[np.mean(F4[ts]) for ts in range(1,11)]


# In[13]:

def CDD(ct):
    D={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearDisruptiveness.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            ndoi,n1,n2,n3=map(int,line.strip().split('\t'))
            if n1+n2+n3>0:
                #dis=(n1-n2)/(n1+n2+n3+0.0)
                D[int(ndoi)]=n1,n2,n3
    C={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearImpact.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            Id,imp=map(int,line.strip().split('\t'))
            C[Id]=imp
    return C,D


# In[14]:

C5,D5=CDD(5)
C50,D50=CDD(50)


# In[58]:

seeds={}
n=0
for i in D50:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in D5:
        n51,n52,n53=D5[i]
        n501,n502,n503=D50[i]
        if n51+n52>0 and n53>0 and n501+n502>0 and n503>0:
            f51=n51/(n51+n52+0.0)
            f52=(n51-n52)/(n51+n52+0.0)
            f53=(n51-n52)/n53
            f54=(n51-n52)/(n51+n52+n53+0.0) 
            f501=n501/(n501+n502+0.0)
            f502=(n501-n502)/(n501+n502+0.0)
            f503=(n501-n502)/n503
            f504=(n501-n502)/(n501+n502+n503+0.0) 
            seeds[i]=[f51,f52,f53,f54,f501,f502,f503,f504]


# In[158]:

f51,f52,f53,f54,f501,f502,f503,f504=zip(*seeds.values()[:10000])


# In[46]:

from scipy.stats.stats import pearsonr


# In[141]:

pearsonr(f51,f501),pearsonr(f52,f502),pearsonr(f53,f503),pearsonr(f54,f504)


# In[160]:

import statsmodels.api as sm
def OLSRegressFit(x,y):
    xx = sm.add_constant(x, prepend=True)
    res = sm.OLS(y,xx).fit()
    constant, beta = res.params
    return constant, beta


# In[162]:

constantf1, betaf1=OLSRegressFit(f51,f501)
constantf2, betaf2=OLSRegressFit(f52,f502)
constantf3, betaf3=OLSRegressFit(f53,f503)
constantf4, betaf4=OLSRegressFit(f54,f504)


# In[ ]:




# In[50]:

S1=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperSleepBeauty.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,bi=line.strip().split('\t')
        S1[int(Id)]=float(bi)


# In[131]:

sb1=defaultdict(lambda:[])
sb2=defaultdict(lambda:[])
sb3=defaultdict(lambda:[])
sb4=defaultdict(lambda:[])
for i in seeds:
    if i in S1:
        sb=S1[i]
        f51,f52,f53,f54,f501,f502,f503,f504=[(np.round(j,1)) for j in seeds[i]]
        sb1[f51].append(sb)
        sb2[f52].append(sb)
        sb3[f53].append(sb)
        sb4[f54].append(sb)


# In[132]:

xsb1,ysb1=np.array(sorted([(k,np.mean(v)) for k,v in sb1.items()])).T
xsb2,ysb2=np.array(sorted([(k,np.mean(v)) for k,v in sb2.items()])).T
xsb3,ysb3=np.array(sorted([(k,np.mean(v)) for k,v in sb3.items()])).T
xsb4,ysb4=np.array(sorted([(k,np.mean(v)) for k,v in sb4.items()])).T


# In[157]:

pearsonr(xsb1,ysb1),pearsonr(xsb2,ysb2),pearsonr(xsb3,ysb3),pearsonr(xsb4,ysb4)


# In[163]:

constantf4s, betaf4s=OLSRegressFit(xsb4,ysb4)


# In[ ]:




# In[172]:

fig = plt.figure(figsize=(12, 4),facecolor='white')
ax1 = plt.subplot2grid((2,6), (0,0), colspan=2,rowspan=2)
cmap = cm.get_cmap('Accent',4)
plt.plot(range(1,11),f1,color=cmap(0),marker='^',label='f1')
plt.plot(range(1,11),f2,color=cmap(1),marker='o',label='f2')
plt.plot(range(1,11),f3,color=cmap(2),marker='s',label='f3')
plt.xlabel('Team size',fontsize=20)
plt.ylabel('Alternative Disruption',fontsize=20)
plt.xticks(np.arange(2, 10+1, 2))
ax1.tick_params(axis='both', which='major', labelsize=14)
ax1.legend(loc=[0.6,0.4],fontsize=14,numpoints=1,frameon=False)
#
ax2 = plt.subplot2grid((2,6), (0,2))
plt.plot(f51,f501,marker='.',markersize=3,color='SteelBlue',alpha=0.3,linestyle='')
plt.xlabel('f1 5 years',fontsize=14)
plt.ylabel('f1 50 years',fontsize=14)
plt.xticks([0,0.5,1])
plt.yticks([0,0.5,1],rotation=45)
xs=np.linspace(0,1,10)
plt.plot(xs,constantf1+betaf1*xs,'r-')
ax2.tick_params(axis='both', which='major', labelsize=12)
#
ax3 = plt.subplot2grid((2,6), (0,3))
plt.plot(f52,f502,marker='.',markersize=3,color='SteelBlue',alpha=0.3,linestyle='')
plt.xlabel('f2 5 years',fontsize=14)
plt.ylabel('f2 50 years',fontsize=14)
plt.xticks([-1,0,1])
plt.yticks([-1,0,1],rotation=45)
xs=np.linspace(-1,1,10)
plt.plot(xs,constantf2+betaf2*xs,'r-')
ax3.tick_params(axis='both', which='major', labelsize=12)
#
ax4 = plt.subplot2grid((2,6), (1,2))
plt.plot(f53,f503,marker='.',markersize=3,color='SteelBlue',alpha=0.7,linestyle='')
plt.xlim(-5,15)
plt.ylim(-5,15)
plt.xlabel('f3 5 years',fontsize=14)
plt.ylabel('f3 50 years',fontsize=14)
plt.xticks([-5,5,15])
plt.yticks([-5,5,15],rotation=45)
xs=np.linspace(-5,15,10)
plt.plot(xs,constantf3+betaf3*xs,'r-')
ax4.tick_params(axis='both', which='major', labelsize=12)
#
#
ax5 = plt.subplot2grid((2,6), (1,3))
plt.plot(f54,f504,marker='.',markersize=3,color='SteelBlue',alpha=0.3,linestyle='')
plt.xlabel('D 5 years',fontsize=14)
plt.ylabel('D 50 years',fontsize=14)
plt.xticks([-1,0,1])
plt.yticks([-1,0,1],rotation=45)
xs=np.linspace(-1,1,10)
plt.plot(xs,constantf4+betaf4*xs,'r-')
ax5.tick_params(axis='both', which='major', labelsize=12)
#
ax2 = plt.subplot2grid((2,6), (0,4))
plt.plot(xsb1,ysb1,marker='.',color='Chocolate',linestyle='')
plt.xticks([0,0.5,1])
plt.yticks([0,20,40])
plt.ylim(0,40)
plt.xlabel('f1 5 years',fontsize=14)
plt.ylabel('SB index',fontsize=14)
ax3 = plt.subplot2grid((2,6), (0,5))
plt.plot(xsb2,ysb2,marker='.',color='Chocolate',linestyle='')
plt.xticks([-1,0,1])
plt.yticks([0,20,40])
plt.ylim(0,40)
plt.xlabel('f2 5 years',fontsize=14)
plt.ylabel('SB index',fontsize=14)
ax4 = plt.subplot2grid((2,6), (1,4))
plt.plot(xsb3,ysb3,marker='.',color='Chocolate',linestyle='')
plt.xticks([-30,10,50])
plt.yticks([0,50,100])
plt.ylim(0,100)
plt.xlabel('f3 5 years',fontsize=14)
plt.ylabel('SB index',fontsize=14)
ax5 = plt.subplot2grid((2,6), (1,5))
plt.plot(xsb4,ysb4,marker='.',color='Chocolate',linestyle='')
plt.xticks([-1,0,1])
plt.yticks([0,20,40])
plt.ylim(0,40)
plt.xlabel('D 5 years',fontsize=14)
plt.ylabel('SB index',fontsize=14)
xs=np.linspace(-1,1,10)
plt.plot(xs,constantf4s+betaf4s*xs,'r-')

#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S10.pdf')


# # Nobel prize

# In[2]:

WOS={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        WOS[doi]=int(ndoi)
J={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        nd,name,xx=line.strip().split('\t')
        J[name]=int(nd)
# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[3]:

Disruptive=[v[-2] for v in W.values()]
drss=random.sample(Disruptive,10000)
stats.percentileofscore(drss, 0)


# In[5]:

from openpyxl import load_workbook


# In[7]:

wb1 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physiology or Medicine.xlsx', read_only=True)
wb2 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physics.xlsx', read_only=True)
wb3 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Chemistry.xlsx', read_only=True)

def GetIDs(wb):
    sheet = wb.get_sheet_by_name(wb.get_sheet_names()[0])
    data=[]
    sheet = wb.get_sheet_by_name('Sheet1')
    for row in sheet.iter_rows():
        data_row = []
        for cell in row:
            data_row += [cell.value]
        data += [data_row]
    d={}
    j=set([])
    for i in data[1:]:
        a=str(i[-1])
        if a in WOS and WOS[a] in W:
            year,subject,ts,imp,dis,jour=W[WOS[a]]
            d[WOS[a]] = ts,imp,dis
            if jour not in j:
                j.add(jour)
    return d,j

N=defaultdict(lambda:[])
NJ=defaultdict(lambda:set([]))

d,j=GetIDs(wb1)
N[1]=d.values()
NJ[1]=j
d,j=GetIDs(wb2)
N[2]=d.values()
NJ[2]=j
d,j=GetIDs(wb3)
N[3]=d.values()
NJ[3]=j

#1=生理学或医学，2=物理，3=化学

gt=defaultdict(lambda:[0,0])# n of grants, total size
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if grantSize>=10**5:
            gt[Id][0]+=1
            gt[Id][1]+=grantSize

G=defaultdict(lambda:[])
GJ=defaultdict(lambda:set([]))
for k,v in gt.items():
    if k in W:
        year,subject,teamsize,impact,disruptive,journal=W[k]
        if year>=2008:
            grantsize=v[1]/v[0]
            if grantsize<10**6:
                gs=1
            if 10**6<=grantsize<=5*10**6:
                gs=2
            if 5*10**6<=grantsize:
                gs=3
            G[gs].append([teamsize,impact,disruptive])
            GJ[gs].add(journal)


# In[8]:

t1,i1,d1= np.array(N[1]).T
t2,i2,d2= np.array(N[2]).T
t3,i3,d3= np.array(N[3]).T
t4,i4,d4= np.array(G[1]).T
t5,i5,d5= np.array(G[2]).T
t6,i6,d6= np.array(G[3]).T


# In[9]:

# team size base-line distributions
tMed=Counter([v[2] for v in W.values() if v[-1] in NJ[1]])
tPhy=Counter([v[2] for v in W.values() if v[-1] in NJ[2]])
tChe=Counter([v[2] for v in W.values() if v[-1] in NJ[3]])
tNSF1=Counter([v[2] for v in W.values() if v[-1] in GJ[1] and v[0]>=2008])
tNSF2=Counter([v[2] for v in W.values() if v[-1] in GJ[2] and v[0]>=2008])
tNSF3=Counter([v[2] for v in W.values() if v[-1] in GJ[3] and v[0]>=2008])
#
xtMed,ytMed=np.array(sorted(tMed.items())).T
xtPhy,ytPhy=np.array(sorted(tPhy.items())).T
xtChe,ytChe=np.array(sorted(tChe.items())).T
xtNSF1,ytNSF1=np.array(sorted(tNSF1.items())).T
xtNSF2,ytNSF2=np.array(sorted(tNSF2.items())).T
xtNSF3,ytNSF3=np.array(sorted(tNSF3.items())).T
#
ytMed=ytMed/float(ytMed.sum())
ytPhy=ytPhy/float(ytPhy.sum())
ytChe=ytChe/float(ytChe.sum())
ytNSF1=ytNSF1/float(ytNSF1.sum())
ytNSF2=ytNSF2/float(ytNSF2.sum())
ytNSF3=ytNSF3/float(ytNSF3.sum())

x1,y1=np.array(sorted(Counter(t1).items())).T
x2,y2=np.array(sorted(Counter(t2).items())).T
x3,y3=np.array(sorted(Counter(t3).items())).T
x4,y4=np.array(sorted(Counter(t4).items())).T
x5,y5=np.array(sorted(Counter(t5).items())).T
x6,y6=np.array(sorted(Counter(t6).items())).T
y1=y1/float(sum(y1))
y2=y2/float(sum(y2))
y3=y3/float(sum(y3))
y4=y4/float(sum(y4))
y5=y5/float(sum(y5))
y6=y6/float(sum(y6))


# In[11]:

dn1=np.array([v[4] for v in W.values() if v[-1] in NJ[1]])
dn2=np.array([v[4] for v in W.values() if v[-1] in NJ[2]])
dn3=np.array([v[4] for v in W.values() if v[-1] in NJ[3]])
df1=np.array([v[4] for v in W.values() if v[-1] in GJ[1] and v[0]>=2008])
df2=np.array([v[4] for v in W.values() if v[-1] in GJ[2] and v[0]>=2008])
df3=np.array([v[4] for v in W.values() if v[-1] in GJ[3] and v[0]>=2008])


# In[18]:

def polyfit(x,y):
    order=2
    xs=np.linspace(0,100,100)
    z = np.polyfit(x,y, order)
    p = np.poly1d(z)
    return [p(i) for i in xs]

def groupMean(x,y):
    d=defaultdict(lambda:[])
    x=[np.round(i/10.0,0) for i in x]
    for a,b in zip(x,y):
        d[a].append(b)
    x1,y1=np.array(sorted([(k,np.mean(v)) for k,v in d.items()])).T
    return x1*10,y1

def cG(data):
    return [np.round(i,2) for i in data]

def fre(data):
    x,y=np.array(sorted(Counter(data).items())).T
    y=y/float(y.sum())
    return x,y


# In[19]:

#disruption distrtibution
N1,N2,N3,F1,F2,F3=map(cG,[d1,d2,d3,d4,d5,d6])
xn1,yn1=fre(N1)
xn2,yn2=fre(N2)
xn3,yn3=fre(N3)
xf1,yf1=fre(F1)
xf2,yf2=fre(F2)
xf3,yf3=fre(F3)

xdn1,ydn1=fre(cG(dn1))
xdn2,ydn2=fre(cG(dn2))
xdn3,ydn3=fre(cG(dn3))
xdf1,ydf1=fre(cG(df1))
xdf2,ydf2=fre(cG(df2))
xdf3,ydf3=fre(cG(df3))


# In[ ]:




# In[ ]:




# In[70]:

fig = plt.figure(figsize=(12,9)) 
ax = fig.add_subplot(431)
plt.plot(xtMed,ytMed,'k--')
plt.plot(x1,y1,color='#FFC857',marker='',linestyle='-',linewidth=2,label='Nobel MED')
plt.xlim(1,10)
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.ylim(0,0.4)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xticks([2,4,6,8,10])
plt.yticks([0,0.1,0.2,0.3,0.4],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(432)
plt.plot(xtPhy,ytPhy,'k--')
plt.plot(x2,y2,color='#C74F1B',marker='',linestyle='-',linewidth=2,label='Nobel PHY')
plt.xlim(1,10)
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.ylim(0,0.4)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xticks([2,4,6,8,10])
plt.yticks([0,0.1,0.2,0.3,0.4],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(433)
plt.plot(xtChe,ytChe,'k--')
plt.plot(x3,y3,color='#5A2A27',marker='',linestyle='-',linewidth=2,label='Nobel CHE')
plt.xlim(1,10)
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.ylim(0,0.4)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xticks([2,4,6,8,10])
plt.yticks([0,0.1,0.2,0.3,0.4],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(434)
plt.plot(xtNSF1,ytNSF1,'k--')
plt.plot(x4,y4,color='SteelBlue',alpha=0.3,linestyle='-',linewidth=2,label='NSF<1M')
plt.xlim(1,10)
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.ylim(0,0.4)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xticks([2,4,6,8,10])
plt.yticks([0,0.1,0.2,0.3,0.4],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(435)
plt.plot(xtNSF2,ytNSF2,'k--')
plt.plot(x5,y5,color='SteelBlue',alpha=0.6,linestyle='-',linewidth=2,label='1M<=NSF<5M')
plt.xlim(1,10)
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.ylim(0,0.4)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xticks([2,4,6,8,10])
plt.yticks([0,0.1,0.2,0.3,0.4],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(436)
plt.plot(xtNSF3,ytNSF3,'k--')
plt.plot(x6,y6,color='SteelBlue',alpha=1,linestyle='-',linewidth=2,label='NSF>=5M')
plt.xlim(1,10)
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.ylim(0,0.4)
plt.xlabel(r'$m$',fontsize=20)
plt.ylabel(r'$P(m)$',fontsize=20)
plt.xticks([2,4,6,8,10])
plt.yticks([0,0.1,0.2,0.3,0.4],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(437)
plt.plot(xn1,yn1,color='#FFC857',linewidth=2,label='Nobel MED')
plt.plot(xdn1,ydn1,'k--')
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlim(-0.2,0.2)
plt.xlabel(r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.2,-0.1,0,0.1,0.2])
plt.yticks([0,0.2,0.4,0.6,0.8,1],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(438)
plt.plot(xn2,yn2,color='#AA4466',linewidth=2,label='Nobel PHY')
plt.plot(xdn2,ydn2,'k--')
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlim(-0.2,0.2)
plt.xlabel(r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.2,-0.1,0,0.1,0.2])
plt.yticks([0,0.2,0.4,0.6,0.8,1],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(439)
plt.plot(xn3,yn3,color='#5A2A27',linewidth=2,label='Nobel CHE')
plt.plot(xdn2,ydn2,'k--')
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlim(-0.2,0.2)
plt.xlabel(r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.2,-0.1,0,0.1,0.2])
plt.yticks([0,0.2,0.4,0.6,0.8,1],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(4,3,10)
plt.plot(xf1,yf1,color='SteelBlue',alpha=0.3,linewidth=2,label='NSF<1M')
plt.plot(xdf1,ydf1,'k--')
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlim(-0.2,0.2)
plt.xlabel(r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.2,-0.1,0,0.1,0.2])
plt.yticks([0,0.2,0.4,0.6,0.8,1],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(4,3,11)
plt.plot(xf2,yf2,color='SteelBlue',alpha=0.6,linewidth=2,label='1M<=NSF<5M')
plt.plot(xdf1,ydf1,'k--')
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlim(-0.2,0.2)
plt.xlabel(r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.2,-0.1,0,0.1,0.2])
plt.yticks([0,0.2,0.4,0.6,0.8,1],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(4,3,12)
plt.plot(xf3,yf3,color='SteelBlue',alpha=1,linewidth=2,label='NSF>=5M')
plt.plot(xdf1,ydf1,'k--')
plt.legend(loc=1,fontsize=14,numpoints=1,frameon=False)
plt.xlim(-0.2,0.2)
plt.xlabel(r'$D$',fontsize=20)
plt.ylabel(r'$P(D)$',fontsize=20)
plt.xticks([-0.2,-0.1,0,0.1,0.2])
plt.yticks([0,0.2,0.4,0.6,0.8,1],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
#

#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S11.pdf')


# # Return and risk

# In[2]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[3]:

def CDD(ct):
    D={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearDisruptiveness.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            ndoi,n1,n2,n3=map(int,line.strip().split('\t'))
            if n1+n2+n3>0:
                #dis=(n1-n2)/(n1+n2+n3+0.0)
                D[int(ndoi)]=n1,n2,n3
    C={}
    n=0
    with open('/Users/lingfeiw/Documents/research/teamscience/team/paper'+str(ct)+'yearImpact.txt','r') as f:
        for line in f:
            n+=1
            if n%100000==0:
                flushPrint(n/100000)
            Id,imp=map(int,line.strip().split('\t'))
            C[Id]=imp
    return C,D


# In[4]:

C5,D5=CDD(5)
C10,D10=CDD(10)
C20,D20=CDD(20)
C30,D30=CDD(30)
C40,D40=CDD(40)
C50,D50=CDD(50)


# In[5]:

def TopBottomRatio(C,D):
    K=defaultdict(lambda:defaultdict(lambda:[]))
    n=0
    for i in D:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        if i in C and i in W:
            xx,xx,m,c,d,xx=W[i]
            c=C[i]
            n1,n2,n3=D[i]
            if n1+n2>0:
                d=(n1-n2)/(n1+n2+n3+0.0)
                if d>0:
                    K[m][1].append(c)
                else:
                    K[m][0].append(c)
    data={}
    imps=[]
    for m in K:
        imps+=K[m][0]
        imps+=K[m][1]
    n1, n2=np.percentile(imps,10),np.percentile(imps,99)
    for m in range(1,11):
        dbottom1=len([i for i in K[m][0] if i<=n1])/float(len(K[m][0]))
        dbottom2=len([i for i in K[m][1] if i<=n1])/float(len(K[m][1]))
        dtop1=len([i for i in K[m][0] if i>=n2])/float(len(K[m][0]))
        dtop2=len([i for i in K[m][1] if i>=n2])/float(len(K[m][1]))
        data[m]=[dbottom1,dbottom2,dtop1,dtop2]
    return data


# In[10]:

data5=TopBottomRatio(C5,D5)
data10=TopBottomRatio(C10,D10)
data20=TopBottomRatio(C20,D20)
data30=TopBottomRatio(C30,D30)
data40=TopBottomRatio(C40,D40)
data50=TopBottomRatio(C50,D50)


# In[140]:

def plot(ax1,ax2,ax3,data,nyears):
    for m in range(1,11):
        dbottom1,dbottom2,dtop1,dtop2=data[m]
        ax1.plot([m,m],[dtop1,dtop2],color='ForestGreen',linewidth=2)
        if dtop2>dtop1:
            ax1.plot([m-0.1,m],[dtop2-0.001,dtop2],color='ForestGreen',linewidth=2)
            ax1.plot([m,m+0.1],[dtop2,dtop2-0.001],color='ForestGreen',linewidth=2)
        else:
            ax1.plot([m-0.1,m],[dtop2+0.001,dtop2],color='ForestGreen',linewidth=2)
            ax1.plot([m,m+0.1],[dtop2,dtop2+0.001],color='ForestGreen',linewidth=2)            
    ax1.plot([0,11],[0.01,0.01],'k--')
    ax1.set_xlim(0,11)
    ax1.set_xticks([2,4,6,8,10])
    ax1.set_yticks([0,0.01,0.02,0.03,0.04,0.05])
    ax1.set_yticklabels([0,0.01,0.02,0.03,0.04,0.05],rotation=45)
    ax1.set_xlabel(r'$m$',fontsize=20)
    ax1.set_ylabel(r'$P\,(Top\,1\%)$',fontsize=20)
    ax1.tick_params(axis='both', which='major', labelsize=14)
    ax1.set_title(str(nyears)+'years',fontsize=20)
    #
    for m in range(1,11):
        dbottom1,dbottom2,dtop1,dtop2=data[m]
        ax2.plot([m,m],[dbottom1,dbottom2],color='brown',linewidth=2)
        if dbottom2>dbottom1:
            ax2.plot([m-0.1,m],[dbottom2-0.01,dbottom2],color='brown',linewidth=2)
            ax2.plot([m,m+0.1],[dbottom2,dbottom2-0.01],color='brown',linewidth=2)
        else:
            ax2.plot([m-0.1,m],[dbottom2+0.01,dbottom2],color='brown',linewidth=2)
            ax2.plot([m,m+0.1],[dbottom2,dbottom2+0.01],color='brown',linewidth=2)            
    ax2.plot([0,11],[0.1,0.1],'k--')
    ax2.set_xlim(0,11)
    ax2.set_xticks([2,4,6,8,10])
    ax2.set_yticks([0,0.1,0.2,0.3,0.4])
    ax2.set_yticklabels([0,0.1,0.2,0.3,0.4],rotation=45)
    ax2.set_xlabel(r'$m$',fontsize=20)
    ax2.set_ylabel(r'$P\,(Bottom\,10\%)$',fontsize=20)
    ax2.tick_params(axis='both', which='major', labelsize=14) 
    ax2.set_title(str(nyears)+'years',fontsize=20)
    #
    k1,k2,k3,k4=np.array([data[m] for m in range(1,11)]).T
    ax3.plot(range(1,11),k2/(k1+0.0),marker='^',color='brown',linestyle='')
    cs,bs=OLSRegressFit(range(1,11),k2/(k1+0.0))
    xx=np.linspace(1,10,100)
    ax3.plot(xx,xx*bs+cs,color='brown',label=str(np.round(bs,2)))
    ax3.plot(range(1,11),k4/(k3+0.0),marker='o',color='ForestGreen',linestyle='')
    if nyears<40:
        ct,bt=OLSRegressFit(range(1,11),k4/(k3+0.0))
    else:
        ct,bt=OLSRegressFit(range(1,9),list(k4/(k3+0.0))[:-2])
    ax3.plot(xx,xx*bt+ct,color='ForestGreen',label=str(np.round(bt,2)))
    if nyears<50:
        ax3.legend(loc=2,fontsize=14,frameon=False)
    else:
        ax3.legend(loc=[0.2,0.2],fontsize=14,frameon=False)
    ax3.set_xlim(1,10) 
    ax3.set_xticks([2,4,6,8,10])
    ax3.set_ylim(0,7) 
    #ax3.set_yticks([0,0.1,0.2,0.3,0.4,0.5])
    #ax2.set_yticklabels([0,0.1,0.2,0.3,0.4,0.5],rotation=45)
    ax3.set_xlabel(r'$m$',fontsize=20)
    ax3.set_ylabel(r'$Ratio$',fontsize=20)
    ax3.tick_params(axis='both', which='major', labelsize=14)
    ax3.set_title(str(nyears)+'years',fontsize=20)


# In[142]:

fig = plt.figure(figsize=(18,9),facecolor='white')
#
ax1 = fig.add_subplot(361)
ax2 = fig.add_subplot(367)
ax3 = fig.add_subplot(3,6,13)
plot(ax1,ax2,ax3,data5,5)
#
ax4 = fig.add_subplot(362)
ax5 = fig.add_subplot(368)
ax6 = fig.add_subplot(3,6,14)
plot(ax4,ax5,ax6,data10,10)
#
ax7 = fig.add_subplot(363)
ax8 = fig.add_subplot(369)
ax9 = fig.add_subplot(3,6,15)
plot(ax7,ax8,ax9,data20,20)
#
ax10 = fig.add_subplot(364)
ax11 = fig.add_subplot(3,6,10)
ax12 = fig.add_subplot(3,6,16)
plot(ax10,ax11,ax12,data30,30)
#
ax13 = fig.add_subplot(3,6,5)
ax14 = fig.add_subplot(3,6,11)
ax15 = fig.add_subplot(3,6,17)
plot(ax13,ax14,ax15,data40,40)
#
ax16 = fig.add_subplot(3,6,6)
ax17 = fig.add_subplot(3,6,12)
ax18 = fig.add_subplot(3,6,18)
plot(ax16,ax17,ax18,data50,50)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S12.pdf')


# # Novelty

# In[137]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
Z1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperNovelty1901_2014.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,novelty = line.strip().split('\t')
        Z1[int(paper)]=float(novelty)


# In[139]:

#aggregate data by team size
bre=defaultdict(lambda:[])
bre1=defaultdict(lambda:defaultdict(lambda:[]))
bre2=defaultdict(lambda:[])
for i in W1:
    if i in Z1:
        year, teamsize,impact,disruptiveness,timegap, meanimp=W1[i]
        bre[teamsize].append(Z1[i])
        if teamsize==1 or teamsize==2:
            bre2[teamsize].append(Z1[i])
        if teamsize>=3:
            bre2[3].append(Z1[i])
        if year in [1954,1964,1974,1984,1994,2004,2014]:
            bre1[year][teamsize].append(Z1[i])
            


# In[157]:

# calculate CI of mean using bootstrap
def calculateCI100(dic,method,n):
    ci=[]
    for teamsize in range(1,106):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b


# In[158]:

xbre,ybre=np.array(sorted([(k,np.mean(v)) for k,v in bre.items()])).T


# In[162]:

breCI=calculateCI100(bre,'mean',30)
ybreCI1,ybreCI2=breCI
#


# In[154]:

def cumuS(vs):
    vs=sorted(vs)
    y=np.linspace(0,1,30)
    x=[np.percentile(vs,p*100) for p in y]
    return x,y

cp={}
for m in [1,2,3]:
    vs=bre2[m]
    x,y=cumuS(vs)
    cp[m]=[x,y]


# In[172]:

Bread=np.random.choice(Z1.values(),10000)
np.percentile(Bread,5)


# In[173]:

bd={}
for year in [1954,1964,1974,1984,1994,2004,2014]:
    x,y=np.array(sorted([(k,np.mean(v)) for k,v in bre1[year].items()])).T
    y=[stats.percentileofscore(Bread,i) for i in y]
    bd[year]=[x,y]


# In[174]:

#
ybre_=[stats.percentileofscore(Bread,i) for i in ybre]
ybreCI1_=[stats.percentileofscore(Bread,i) for i in ybreCI1]
ybreCI2_=[stats.percentileofscore(Bread,i) for i in ybreCI2]


# In[146]:

# no time window
F=defaultdict(lambda:[0,0])#all papers, top 5% breadth
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in Z1:
        year,teamsize,impact,disruptiveness,timegap, meanimp=W1[i]
        breadth=Z1[i]
        #if 1<=teamsize<=16:
        F[teamsize][0]+=1
        if breadth<=-23.15:
            F[teamsize][1]+=1
xf1,yf1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in F.items()]).T


# In[147]:

def ra(x,N): return np.convolve(x, np.ones((N,))/N, mode='valid')


# In[240]:

ybre_n=ra(ybre_,5)
yf1n=ra(yf1,5)


# In[195]:

len(ybre_20n[20:maxm])


# In[249]:

def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[322]:

### create figure
fig = plt.figure(figsize=(12, 4),facecolor='white')
#
ax = fig.add_subplot(131)
cmap = cm.get_cmap('rainbow',4)
x,y=cp[1]
plt.plot(x,y,marker='.',linestyle='-',color='#84B663',label='m=1')
x,y=cp[2]
plt.plot(x,y,marker='.',linestyle='-',color='#86AAAF',label='m=2')
x,y=cp[3]
plt.plot(x,y,marker='.',linestyle='-',color='#D27D67',label='m>=3')
plt.legend(loc='center right',fontsize=12,frameon=False)
plt.plot([0,0],[0,1],marker='',linestyle='-',color='gray')
plt.fill_between([-2**9,0],[0,0],[1,1],color='#FDEFEE')
plt.fill_between([0,2**15],[0,0],[1,1],color='#FEF8EF')
plt.xlim(-2**9,2**14)
plt.xscale('symlog',basex=2)
plt.xscale('symlog',basex=2)
plt.ylabel('cumulative distribution',fontsize =20)
plt.xlabel('novelty',fontsize =20)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xticks([-2**9,-2**7,-2**5,-2**3,-2**1,0,2**1,2**3,2**5,2**7,2**9,2**11,2**13],rotation=45)
#
ax = fig.add_subplot(132)
#ax.set_xlim(1, 16)
ax.set_xlabel("Team size",fontsize =20)
ax.set_ylabel("Novelty Percentile",fontsize=20)
#
maxm=100
ax.plot(range(1,maxm+1),100-np.array(ybre_[:maxm]), label="Breadth",color='#4477AA')
ax.fill_between(range(1,maxm+1), 100-np.array(ybreCI1_[:maxm]),100-np.array(ybreCI2_[:maxm]),                  color='gray',alpha=0.3)
#ax.set_ylim(15, 35)
#ax.set_yticks([15,24,35])
ax.tick_params(axis='both', which='major', labelsize=14)

subax = add_subplot_axes(ax,[0.55,0.6,0.4,0.35])
cmap = cm.get_cmap('rainbow',8)
n=0
for year in [1954,1964,1974,1984,1994,2004,2014]:
    n+=1
    x,y=bd[year]
    plt.plot(x,100-np.array(y),color=cmap(n),marker='',alpha=n/7.0,label=str(year))
subax.legend(loc=2,fontsize=7,numpoints=1,frameon=False,ncol=2,handlelength=0.5)
#subax.set_xlabel("Team size",fontsize =10)
#subax.set_ylabel("Novelty Percentile",fontsize=10)
subax.set_xlim(1,16)
subax.tick_params(axis='both', which='major', labelsize=12)
#plt.yscale('log')
#plt.xlim(1,16)
#plt.ylim(10**-6,1)
subax.set_xticks([2,6,10,14])
subax.set_yticks([0,20,40,60,80])
ax.tick_params(axis='both', which='major', labelsize=14)

#
ax = fig.add_subplot(133)
plt.plot(xf1,yf1,color='#4477AA',label='Top 10% Breadth')
plt.plot([1,100],[0.05,0.05],color='gray',linestyle='--')
plt.xlim(1,100)
plt.ylim(0,0.1)
ax.tick_params(axis='both', which='major', labelsize=14)
ax.set_xlabel("Team size",fontsize =20)
ax.set_ylabel("P(Top5% Novelty)",fontsize=20)


###-----------------------------------------------inset---------------




#------------inset 121-------------------
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S16.pdf')


# # fixed effect 

# In[2]:

WOS={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        WOS[doi]=int(ndoi)


# In[3]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[4]:

path='/Users/lingfeiw/Documents/research/teamscience/match_wos_final/'
scholars = [ f for f in listdir(path)]

U={}
n=0
for i in scholars:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    data=[]
    with open (path+i,'r') as f:
        for line in f:
            data.append(line.strip())
    name=i.split('.')[0]
    data=[WOS[j] for j in data if j in WOS and WOS[j] in W]
    if data:
        U[name]=data


# In[6]:

# fixed model data
fd=defaultdict(lambda:defaultdict(lambda:[]))
for i in U:
    for p in U[i]:
        mp,dp=W[p][2],W[p][4]
        #if 1<=mp<=10:
        fd[i][mp].append(dp)


# In[7]:

len(fd)


# In[8]:

n=0
FD={}
for i in fd:
    ls=[(k,np.mean(v)) for k,v in fd[i].items() if 1<=k<=10]
    if len(ls)>0:
        x,y=np.array((sorted(ls))).T
        FD[i]=[x,y]


# In[8]:

def OLSRegressFit(x,y):
    xx = sm.add_constant(x, prepend=True)
    res = sm.OLS(y,xx).fit()
    constant, beta = res.params
    r2 = res.rsquared
    return [constant,beta]


# In[9]:

# fixed and random model data
RData=[]
FData=[]
for i in FD:
    x,y=FD[i]
    RData+=zip(x,y)
    FData+=zip(x-np.mean(x),y-np.mean(y))
xr,yr=np.array(RData).T
xf,yf=np.array(FData).T


# In[11]:

xxr = sm.add_constant(xr, prepend=True)
resr = sm.OLS(yr,xxr).fit()
constant, beta=resr.params
constant, beta,resr.rsquared_adj


# In[12]:

xxf = sm.add_constant(xf, prepend=True)
resf = sm.OLS(yf,xxf).fit()
constant, beta=resf.params
constant, beta,resf.rsquared_adj


# In[13]:

#aggregate data by team size
bre=defaultdict(lambda:[])
bre1=defaultdict(lambda:[])
for i in FD:
    x,y=FD[i]
    for a,b in zip(x,y):
        bre[int(a)].append(b)
    for c,d in zip(x-np.mean(x),y-np.mean(y)):
        c=int(np.round(c))
        if -5<=c<=5:
            bre1[c].append(d)


# In[14]:

xbre,ybre=np.array(sorted([(k,np.mean(v)) for k,v in bre.items()])).T
breCI=calculateCI(bre,'mean',30)
ybreCI1,ybreCI2=breCI
#
xbre1,ybre1=np.array(sorted([(k,np.mean(v)) for k,v in bre1.items()])).T
breCI_=calculateCI(bre1,'mean',30)
ybreCI1_,ybreCI2_=breCI_


# In[17]:

fig = plt.figure(figsize=(12, 3),facecolor='white')
ax = fig.add_subplot(141)
x1,y1=FD.values()[12]
#constant1,beta1=OLSRegressFit(x1,y1)
plt.plot(x1,y1,'ro')
#plt.plot(x1,constant1+beta1*x1,'r-',label=str(np.round(beta1,4)))
#
x2,y2=FD.values()[45]
#constant2,beta2=OLSRegressFit(x2,y2)
plt.plot(x2,y2,'bo')
#plt.plot(x2,constant2+beta2*x2,'b-',label=str(np.round(beta2,4)))
#
x3,y3=FD.values()[226]#45
#constant3,beta3=OLSRegressFit(x3,y3)
plt.plot(x3,y3,'go')

x4=np.array(list(x1)+list(x2)+list(x3))
y4=np.array(list(y1)+list(y2)+list(y3))
constant4,beta4=OLSRegressFit(x4,y4)
xs=np.linspace(0,12,100)
plt.plot(xs,constant4+beta4*xs,'k-',alpha=0.7,label=str(np.round(beta4,4)))

#plt.plot(x3,constant3+beta3*x3,'g-',label=str(np.round(beta3,4)))
plt.legend(loc=1,numpoints=1,fontsize=14,frameon=False,handlelength=1)
#plt.ylim(-0.02,0.01)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.xticks([0,2,4,6,8,10,12],rotation=45)
plt.yticks([-0.02,0,0.02,0.04],rotation=45)
plt.xlabel(r'$m_{ir}$',fontsize=20)
plt.ylabel(r'$D_{ir}$',fontsize=20)
plt.title('Three Scholars',fontsize=18)
#
ax = fig.add_subplot(142)
y11=y1-np.mean(y1)
x11=x1-np.mean(x1)
y22=y2-np.mean(y2)
x22=x2-np.mean(x2)
y33=y3-np.mean(y3)
x33=x3-np.mean(x3)
plt.plot(x11,y11,'ro',alpha=0.3)
plt.plot(x22,y22,'bo',alpha=0.3)
plt.plot(x33,y33,'go',alpha=0.3)
x44=np.array(list(x11)+list(x22)+list(x33))
y44=np.array(list(y11)+list(y22)+list(y33))
constant44,beta44=OLSRegressFit(x44,y44)
xs=np.linspace(-5,5,100)
plt.plot(x44,y44,color='k',linestyle='',marker='o',alpha=0.3)
plt.plot(xs,constant44+beta44*xs,'r-',alpha=0.7,label=str(np.round(beta44,4)))
plt.legend(loc=1,numpoints=1,fontsize=14,frameon=False)
plt.ylim(-0.02,0.05)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.yticks([-0.02,0,0.02,0.04],rotation=45)
plt.xticks([-5,-2.5,0,2.5,5],rotation=45)
plt.xlabel(r'$m_{ir}-\bar{m}_{i}$',fontsize=20)
plt.ylabel(r'$D_{ir}-\bar{D}_{i}$',fontsize=20)
plt.title('Three Scholars',fontsize=18)
#
#
ax = fig.add_subplot(143)
#plt.plot(xbre,ybre,'bo-')
plt.fill_between(range(1,11),ybreCI1,ybreCI2,color='gray',alpha=0.3)
plt.xlim(1,10)
plt.ylim(-0.004,0.004)
xs=np.linspace(1,10,10)
plt.plot(xs,xs*-0.00026956924709524221+0.0002,'k--',label='-0.00027')
#plt.plot(xs,xs*-0.00017879483485551474,'r--',label='-0.00018')
plt.xlabel(r'$m_{ir}$',fontsize=20)
plt.ylabel(r'$D_{ir}$',fontsize=20)
plt.xticks([2,4,6,8,10],rotation=45)
plt.yticks([-0.004,-0.002,0,0.002,0.004],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc=1,numpoints=1,fontsize=14,frameon=False,handlelength=1)
plt.title('All Scholars',fontsize=18)
#
ax = fig.add_subplot(144)
#plt.plot(xbre,ybre,'bo-')
#plt.plot(np.array(xbre1)+5,ybre1,'ro-')
plt.fill_between(sorted(bre1.keys()),ybreCI1_,ybreCI2_,color='gray',alpha=0.3)
plt.xlim(-5,5)
plt.ylim(-0.004,0.004)
xs=np.linspace(-5,5,10)
plt.plot(xs,xs*-0.00017879483485551474,'r--',label='-0.00018')
plt.xlabel(r'$m_{ir}-\bar{m}_{i}$',fontsize=20)
plt.ylabel(r'$D_{ir}-\bar{D}_{i}$',fontsize=20)
plt.xticks([-5,-2.5,0,2.5,5],rotation=45)
plt.yticks([-0.004,-0.002,0,0.002,0.004],rotation=45)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc=1,numpoints=1,fontsize=14,frameon=False,handlelength=1)
plt.title('All Scholars',fontsize=18)
#
plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/SI_figure/S15.pdf')


# In[18]:

papers=[]
for i in U:
    papers+=U[i]
papers=set(papers)
len(papers)


# In[19]:

# papers
Title={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        p=int(line[0])
        if p in papers:
            Title[p]=line[1]


# In[24]:

# papers
Abstract={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/abstract1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if line[0].isdigit():
            p=int(line[0])
            if p in papers:
                Abstract[p]=line[1]


# In[20]:

len(Title)


# In[25]:

len(Abstract)


# In[28]:

len([i for i in Abstract if len(Abstract[i])>50])


# In[29]:

import gensim


# In[78]:

train_corpus=[]
n=0
for i in Abstract.keys()[:10000]:
    ab=Abstract[i]
    if len(ab)>10:
        new=gensim.models.doc2vec.TaggedDocument(gensim.utils.simple_preprocess(ab), [n])
        train_corpus.append(new)
        n+=1
n


# In[79]:

model = gensim.models.doc2vec.Doc2Vec(size=50, min_count=2, iter=10)


# In[80]:

model.build_vocab(train_corpus)


# In[81]:

get_ipython().magic(u'time model.train(train_corpus, total_examples=model.corpus_count, epochs=model.iter)')


# In[83]:

ranks = []
second_ranks = []
for doc_id in range(len(train_corpus)):
    if doc_id%100==0:
        flushPrint(doc_id/100)
    inferred_vector = model.infer_vector(train_corpus[doc_id].words)
    sims = model.docvecs.most_similar([inferred_vector], topn=len(model.docvecs))
    rank = [docid for docid, sim in sims].index(doc_id)
    ranks.append(rank)
    second_ranks.append(sims[1])


# In[86]:

print('Document ({}): «{}»\n'.format(doc_id, ' '.join(train_corpus[doc_id].words)))
print(u'SIMILAR/DISSIMILAR DOCS PER MODEL %s:\n' % model)
for label, index in [('MOST', 0), ('MEDIAN', len(sims)//2), ('LEAST', len(sims) - 1)]:
    print(u'%s %s: «%s»\n' % (label, sims[index], ' '.join(train_corpus[sims[index][0]].words)))


# In[88]:

# Pick a random document from the test corpus and infer a vector from the model
doc_id = random.randint(0, len(train_corpus))

# Compare and print the most/median/least similar documents from the train corpus
print('Train Document ({}): «{}»\n'.format(doc_id, ' '.join(train_corpus[doc_id].words)))
sim_id = second_ranks[doc_id]
print('Similar Document {}: «{}»\n'.format(sim_id, ' '.join(train_corpus[sim_id[0]].words)))


# In[93]:

# fitting all papers
vectors={}
n=0
for i in Abstract:
    n+=1
    if n%10000==0:
        flushPrint(n/10000)
    vc=model.infer_vector(gensim.utils.simple_preprocess(ab))
    vectors[i]=vc


# In[94]:

len(vectors)


# In[95]:

f = open('/Users/lingfeiw/Documents/research/teamscience/team/abstractVector2million.txt', "wb")
for i in vectors:
    f.write(str(i)+'\t'+'\t'.join(map(str,vectors[i])) + '\n')
f.close()


# In[101]:

# fixed model data
fdv=defaultdict(lambda:defaultdict(lambda:[]))
for i in U:
    for p in U[i]:
        if p in vectors:
            mp,dp=W[p][2],W[p][4]
            #if 1<=mp<=10:
            fdv[i][mp].append(vectors[p])


# In[109]:

n=0
FDV={}
for i in fdv:
    ls=[(k,np.mean(v,axis=0)) for k,v in fdv[i].items() if 1<=k<=10]
    if len(ls)>0:
        x,y=zip(*sorted(ls))
        FDV[i]=[x,y]


# In[239]:

# fixed and random model data
RDatanewX=[]
RDatanewY=[]
#RDatanewX_=[]
FDatanewX=[]
FDatanewY=[]
for i in FD:
    x,y=FD[i]
    mx=x-np.mean(x)
    my=y-np.mean(y)
    x_,zs=FDV[i]
    for a,b,c in zip(x,zs,y):
        RDatanewX.append([a]+list(b))
        #RDatanewX_.append([a]+[0.1]*len(b))
        RDatanewY.append(c)
    for a,b,c in zip(mx,zs,my):
        FDatanewX.append([a]+list(b))
        #RDatanewX_.append([a]+[0.1]*len(b))
        FDatanewY.append(c)
    #FDatanew+=zip(x-np.mean(x),y-np.mean(y))
RDatanewX=np.array(RDatanewX).T
FDatanewX=np.array(FDatanewX).T
#RDatanewX_=np.array(RDatanewX_).T
#xr,yr=np.array(RDatanew).T
#xf,yf=np.array(FDatanew).T


# In[ ]:




# In[234]:

len(FD)


# In[227]:

1+1


# In[211]:

y = [1,2,3,4,3,4,5,4,5,5,4,5,4,5,4,5,6,5,4,5,4,3,4]

x = [
     [4,2,3,4,5,4,5,6,7,4,8,9,8,8,6,6,5,5,5,5,5,5,5],
     [4,1,2,3,4,5,6,7,5,8,7,8,7,8,7,8,7,7,7,7,7,6,5],
     [4,1,2,5,6,7,8,9,7,8,7,8,7,7,7,7,7,7,6,6,4,4,4]
     ]

def reg_m(y, x):
    ones = np.ones(len(x[0]))
    X = sm.add_constant(np.column_stack((x[0], ones)))
    for ele in x[1:]:
        X = sm.add_constant(np.column_stack((ele, X)))
    results = sm.OLS(y, X).fit()
    return results


# In[ ]:




# In[ ]:




# In[ ]:




# In[236]:

len(RDatanewX),len(RDatanewX_),len(RDatanewY),len(RDatanewX[0])


# In[237]:

reg_m(RDatanewY, RDatanewX).summary()


# In[240]:

reg_m(FDatanewY, FDatanewX).summary()


# In[ ]:



