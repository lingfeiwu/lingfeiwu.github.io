
# coding: utf-8

# In[3]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
from openpyxl import load_workbook
from mpl_toolkits.axes_grid1 import host_subplot
from scipy import stats
#WOS:A19641683C00003	2720466

def flushPrint(www):
    sys.stdout.write('\r')
    sys.stdout.write('%s' % www)
    sys.stdout.flush()
    
# calculate CI of mean using bootstrap
def calculateCI(dic,method,n):
    ci=[]
    for teamsize in range(1,11):
        flushPrint (teamsize)
        ms=[]
        data=dic[teamsize]
        m=int(len(data)/10)
        if m<30000:
            m=int(len(data)/2)
        if m<10000:
            m=int(len(data)*3/4)
        if m<5000:
            m=int(len(data)*4/5)
        if method=='mean':
            for j in range(n):
                ms.append(np.mean(np.random.choice(data,m,replace=False)))
        if method=='median':
            for j in range(n):
                ms.append(np.median(np.random.choice(data,m,replace=False)))
        a,b=[np.percentile(ms,2.5),np.percentile(ms,97.5)]
        ci.append([a,b])
    a,b=np.array(ci).T
    return a,b

def log2linearBin(x,y):
    x=[np.round(i,0) for i in np.log2(x)]
    q=sorted(zip(x,y))
    xvalues = set(x)
    newlist = [(np.round(np.exp2(i),0),np.mean([b for a,b in q if a==i])) for i in xvalues]
    nx,ny = np.array(sorted(newlist)).T
    return nx,ny

def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax


# In[2]:

reviewJournals={}
noreviewJournals={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if 'REVIEW' in line[1] and 'ANNUAL' in line[1]:
        #if 'review' in line[1]:
            reviewJournals[int(line[0])]=line[1]
        if 'REVIEW' not in line[1]:
            noreviewJournals[int(line[0])]=line[1]


# In[19]:

reviewing=[]
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperJournal.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        p,j=map(int,line.strip().split('\t'))
        if j in reviewJournals:
            reviewing.append(p)
reviewingSet=set(reviewing)


# In[29]:

len(reviewing),len(reviewingSet)


# In[3]:

#W1={}# nonreview  articles
W2={}# review articles
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            if int(journal) in reviewJournals:
                W2[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)]
            #if int(journal) in noreviewJournals:
            #    W1[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)] 


# In[5]:

len(W2)


# In[11]:

line[1:]


# In[ ]:




# In[31]:

n=0
reviewed=[]
with open('/Users/lingfeiw/Documents/research/teamscience/team/reference1900_2015.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#314
        line=map(int,line.strip().split('\t'))
        p=line[0]
        if p in reviewingSet:
            reviewed+=[i for i in line[1:] if i not in reviewingSet]
reviewedSet=set(reviewed)
len(reviewed),len(reviewedSet)


# In[24]:




# In[15]:

# all paper disruption 
n=0
R={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/teamPerformance1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,n1,n2,n3=map(int,line.strip().split('\t'))
        if n1+n2>0:
            R[Id]=n1/(n1+n2+0.0)


# In[ ]:




# In[8]:

W3={}# reviewed articles
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            Id=int(Id)
            if Id in w3set:
                W3[int(Id)]=[int(teamsize),int(impact),float(disruptive),float(timegap),float(meanimp)] 


# In[9]:

len(W2),len(R2),len(W3)


# In[10]:

np.mean([W3[i][2] for i in W3])0.00077


# In[ ]:




# In[ ]:




# In[120]:

#aggregate data by team size
disPaper2=defaultdict(lambda:[])
for i in W2:
    teamsize,impact,disruption,timegap, meanimp1=W2[i]
    disPaper2[teamsize].append(disruption)
#aggregate data by team size
disPaper3=defaultdict(lambda:[])
for i in W3:
    teamsize,impact,disruption,timegap, meanimp1=W3[i]
    disPaper3[teamsize].append(disruption)


# In[115]:

dp=random.sample(DP.values(),100000)


# In[117]:

stats.percentileofscore(DP.values(),0),stats.percentileofscore(dp,0)


# In[118]:

len(disPaper1)


# In[125]:

# mean
xdisPaper2,ydisPaper2=np.array(sorted([(k,np.mean(disPaper2[k])) for k in range(1,11)])).T
ydisPaper2=[stats.percentileofscore(dp,i) for i in ydisPaper2]
# mean
xdisPaper3,ydisPaper3=np.array(sorted([(k,np.mean(disPaper3[k])) for k in range(1,11)])).T
ydisPaper3=[stats.percentileofscore(dp,i) for i in ydisPaper3]


# In[128]:

def add_subplot_axes(ax,rect,axisbg='w'):
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)    
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  # <= Typo was here
    subax = fig.add_axes([x,y,width,height],axisbg=axisbg)
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax


# In[170]:

fig = plt.figure(figsize=(5, 5),facecolor='white')
#
ax = fig.add_subplot(111)
plt.plot(xdisPaper3,ydisPaper3, label="Reviewed articles",linewidth=1.5,color='#117733')
plt.plot(xdisPaper2,ydisPaper2, label="Reviewing articles",linewidth=1.5,color='#117733',linestyle='--')
ax.set_ylim(20,100)
ax.set_xlim(1,10)
#ax.set_yticks([10,50,90])
ax.legend(loc=1,numpoints=1,fontsize=12,frameon=False)
plt.xlabel('Team size',fontsize=16)
plt.ylabel('Disruption Percentile',fontsize=16)
ax.tick_params(axis='both', which='major', labelsize=12)
subax = add_subplot_axes(ax,[0.54,0.50,0.45,0.3])
#
xs = np.linspace(-0.05,0.05,200)
density = gaussian_kde(x)
density.covariance_factor = lambda : .05
density._compute_covariance()
subax.plot(xs,density(xs)/sum(density(xs)),color='#117733',linestyle='--')
density = gaussian_kde(y)
density.covariance_factor = lambda : .05
density._compute_covariance()
subax.plot(xs,density(xs)/sum(density(xs)),color='#117733')
plt.xlim(-0.04,0.04)
plt.ylim(0,0.055)
plt.plot([0.0128,0.0128],[0,0.008],'r-')
plt.plot([-0.0008,-0.0008],[0,0.05],'r--')
subax.set_xticks([-0.04,-0.02,0,0.02,0.04])
plt.xticks(rotation=30)
plt.xlabel('Disruption',fontsize=14)
plt.ylabel('Probability',fontsize=14)
subax.tick_params(axis='both', which='major', labelsize=10)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/reviwing_reviewed.pdf')
#


# In[13]:

np.median([W3[i][2] for i in W3]),np.mean([W3[i][2] for i in W3])


# In[17]:

np.median([W2[i][2] for i in W2]),np.mean([W2[i][2] for i in W2])


# In[27]:

reviewedD=[R[i] for i in reviewed if i in R]
reviewingD=[R[i] for i in reviewing if i in R]


# In[28]:

np.mean(reviewed),np.mean(reviewing)


# In[1]:

len(DP)


# In[43]:

stats.percentileofscore(DP.values(),-0.0018932043567500001)# reviewing median


# In[19]:

stats.percentileofscore(DP.values(),-0.00265957446809) #reviewed median


# In[18]:

stats.percentileofscore(DP.values(),-0.00089926585017262208)#reviewing mean


# In[20]:

stats.percentileofscore(DP.values(),0.00076550281737558122)# reviewed mean


# In[172]:

np.median(DP.values())


# In[173]:

x=[DD[i] for i in W2]
y=[DD[i] for i in W3]


# In[51]:

from scipy.stats import gaussian_kde


# In[174]:

fig = plt.figure(figsize=(3, 2),facecolor='white')
ax = fig.add_subplot(111)
#plt.hist(x,500,alpha=0.5,edgecolor='white',label='reviewing',normed=True)
#plt.hist(y,500,alpha=0.5,edgecolor='white',label='reviewed',normed=True)
xs = np.linspace(-0.05,0.05,200)
density = gaussian_kde(x)
density.covariance_factor = lambda : .05
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='RoyalBlue')
density = gaussian_kde(y)
density.covariance_factor = lambda : .05
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='ForestGreen')
plt.xlim(-0.05,0.05)
plt.xlabel('Disruption',fontsize=14)
plt.ylabel('Probability',fontsize=14)
ax.tick_params(axis='both', which='major', labelsize=12)

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/reviwing_reviewed.pdf')
plt.show()


# In[ ]:




# In[104]:

fig = plt.figure(figsize=(3, 2),facecolor='white')
ax = fig.add_subplot(111)
#plt.hist(x,500,alpha=0.5,edgecolor='white',label='reviewing',normed=True)
#plt.hist(y,500,alpha=0.5,edgecolor='white',label='reviewed',normed=True)
xs = np.linspace(-0.05,0.05,200)
density = gaussian_kde(x)
density.covariance_factor = lambda : .05
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='RoyalBlue')
density = gaussian_kde(y)
density.covariance_factor = lambda : .05
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='ForestGreen')
plt.xlim(-0.05,0.05)
plt.xlabel('Disruption',fontsize=14)
plt.ylabel('Probability',fontsize=14)
ax.tick_params(axis='both', which='major', labelsize=12)

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/reviwing_reviewed.pdf')
plt.show()


# In[7]:

len(R2)


# In[ ]:




# In[4]:

len(W1),len(W2)


# In[6]:

np.median([i[2] for i in W2.values()]),np.mean([i[2] for i in W2.values()])


# In[7]:

np.median([i[2] for i in W1.values()]),np.mean([i[2] for i in W1.values()])


# In[17]:

stats.percentileofscore(DisruptionPaper,-0.0018932043567500001)


# In[16]:

stats.percentileofscore(DisruptionPaper,-0.00080906148867299999)


# In[15]:

stats.percentileofscore(DisruptionPaper,-0.00089926585017262208)


# In[18]:

stats.percentileofscore(DisruptionPaper,0.00045864204691212668)


# In[21]:

len(A),len(B)


# In[29]:

len([i for i in W1 if i in A]),len([i for i in W2 if i in A])


# In[30]:

len([i for i in W1 if i in B]),len([i for i in W2 if i in B])


# In[32]:

5313/6397815.0,16762/16266398.0#review in disrupt and non disrupt papers


# In[37]:

24174022-22672,


# In[33]:

0.0010304678392843948/0.0008304397673268139


# In[34]:

6285600/6397815.0,15666650/16266398.0#non-review in disrupt and non disrupt papers


# In[36]:

0.9631296369362166/0.9824604181271263


# In[28]:

A=set([])
B=set([])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(impact)>0 and int(year)>=1954:
            d=float(disruptive)
            if d>0:
                A.add(int(Id))
            if d<0:
                B.add(int(Id))


# In[14]:

DD={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        DD[int(Id)]=float(disruptive)


# In[ ]:




# In[4]:

DP={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if 1<=int(teamsize)<=100 and int(impact)>0 and int(year)>=1954:
            DP[int(Id)]=float(disruptive)
DS=random.sample(DP.values(),10000)
stats.percentileofscore(DS,0)


# In[10]:

Wmp={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperImpactMedian.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,medianImp=line.strip().split('\t')
        Wmp[int(paper)]=float(medianImp)


# In[71]:

#match arxiv
# papers
import re 

TT={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/title1900_2015.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#436
        line=line.strip().split('\t')
        p=int(line[0])
        TT[re.sub('[^A-Za-z0-9]+', ' ', line[1]).strip().lower()]=p


# In[72]:

PS={}
ap='/Users/lingfeiw/Documents/bigdata/arxiv2003/hep-th-abs/'
for year in range(1992,2004):
    flushPrint(year)
    path=ap+str(year)+'/'
    ps = [ f for f in listdir(path)]
    for i in ps:
        d=[]
        with open (path+i,'r') as f:
            for line in f:
                try:
                    if 'Title' in line:
                        title=line.strip().split(":")[1].strip()
                        title=re.sub('[^A-Za-z0-9]+', ' ', title).strip().lower()
                        if title in TT:
                            d.append(TT[title])
                    #if 'Authors' in line:
                    #    au=line.strip().split(":")[1].strip()
                    #    nau=len(au.split(','))+1
                    #    d.append(nau)
                    if 'Comments' in line:
                        if 'figure' in line:
                            d.append(line.strip().split(":")[1].strip())
                except:
                    pass
        if len(d)==2:
            PS[d[0]]=d[1]


# In[73]:

PS3={}
for n in PS:
    s=PS[n]
    lst=[re.sub('[^A-Za-z0-9]+', ' ', i).strip().lower() for i in s.split(' ')]
    nf=''
    if 'figure' in lst and lst[lst.index('figure')-1]=='no':
        PS3[n]=0
    else:
        if 'figures' in lst and lst[lst.index('figures')-1]=='no':
            PS3[n]=0
        if 'figure' in lst:
            if lst[lst.index('figure')-1].isdigit():
                nf=lst[lst.index('figure')-1]
            else:
                if lst[lst.index('figure')-2].isdigit():
                    nf=lst[lst.index('figure')-2]
        else:
            if 'figures' in lst:
                if lst[lst.index('figures')-1].isdigit():
                    nf=lst[lst.index('figures')-1]
                else:
                    if lst[lst.index('figures')-2].isdigit():
                        nf=lst[lst.index('figures')-2]
        if nf.isdigit():
            PS3[n]=int(nf)


# In[88]:

dis0=[DD[i] for i in PS3 if PS3[i]==0 and i in DD]
dis1=[DD[i] for i in PS3 if PS3[i]>1 and i in DD]
len(dis0),len(dis1)


# In[80]:

plt.hist(dis0,300,alpha=0.5,edgecolor='white',label='Theoretical',normed=True)
plt.hist(dis1,300,alpha=0.5,edgecolor='white',label='Empirical',normed=True)
plt.xlim(-0.05,0.05)
plt.legend(loc=1,frameon=False)
plt.show()


# In[87]:

#plt.hist(dis0,300,alpha=0.5,edgecolor='white',label='Theoretical',normed=True)
#plt.hist(dis1,300,alpha=0.5,edgecolor='white',label='Empirical',normed=True)
xs = np.linspace(-0.05,0.05,200)
density = gaussian_kde(dis0)
density.covariance_factor = lambda : .3
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='RoyalBlue',label='Theoretical')
density = gaussian_kde(dis1)
density.covariance_factor = lambda : .3
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='ForestGreen',label='Empirical')
plt.xlim(-0.04,0.04)
plt.legend(loc=1,frameon=False)
plt.show()


# In[90]:

#plt.hist(dis0,300,alpha=0.5,edgecolor='white',label='Theoretical',normed=True)
#plt.hist(dis1,300,alpha=0.5,edgecolor='white',label='Empirical',normed=True)
xs = np.linspace(-0.05,0.05,200)
density = gaussian_kde(dis0)
density.covariance_factor = lambda : .03
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='RoyalBlue',label='Theoretical')
density = gaussian_kde(dis1)
density.covariance_factor = lambda : .03
density._compute_covariance()
plt.plot(xs,density(xs)/sum(density(xs)),color='ForestGreen',label='Empirical')
plt.xlim(-0.04,0.04)
plt.legend(loc=1,frameon=False)
plt.show()


# In[ ]:




# In[ ]:




# In[ ]:




# In[64]:

#aggregate data by team size
disPaper1_=defaultdict(lambda:defaultdict(lambda:[]))
impPaper1_=defaultdict(lambda:defaultdict(lambda:[]))
depPaper1_=defaultdict(lambda:defaultdict(lambda:[]))
popPaper1_=defaultdict(lambda:defaultdict(lambda:[]))
for i in PS3:
    nf=PS3[i]
    if nf==0:
        n=0
    if nf>=1:
        n=1
    if i in Wmp and i in W1 and n in [0,1]:
        teamsize,impact,disruption,timegap, meanimp1=W1[i]
        disPaper1_[n][teamsize].append(disruption)
        impPaper1_[n][teamsize].append(impact) 
        depPaper1_[n][teamsize].append(timegap)
        popPaper1_[n][teamsize].append(Wmp[i])


# In[62]:

[(k,len(v)) for k,v in disPaper1_[0].items()]


# In[91]:

fig = plt.figure(figsize=(10, 4),facecolor='white')
#
ax = fig.add_subplot(121)
plt.plot(xdisPaper1,ydisPaper1, label="Non-review articles",linewidth=1.5,color='#117733')
plt.plot(xdisPaper2,ydisPaper2, label="Review articles",linewidth=1.5,color='#117733',linestyle='--')
ax.set_ylim(20,100)
ax.set_xlim(1,10)
#ax.set_yticks([10,50,90])
ax.legend(loc=1,numpoints=1,fontsize=12,frameon=False)
plt.xlabel('Team size',fontsize=18)
plt.ylabel('Disruption Percentile',fontsize=18)
ax.tick_params(axis='both', which='major', labelsize=12)
#
ax = fig.add_subplot(122)
x,y=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1_[0].items()])).T
y=[stats.percentileofscore(DisruptionPaper,i) for i in y]
plt.plot(x,y,color='SteelBlue',label='Theoretical articles (no figures)',linewidth=1.5)
x,y=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1_[1].items()])).T
y=[stats.percentileofscore(DisruptionPaper,i) for i in y]
plt.plot(x,y,color='SteelBlue',label='Empirical articles (with figures)',linewidth=1.5,linestyle='--')
plt.xlim(1,6)
plt.xlabel('Team size',fontsize=18)
plt.ylabel('Disruption Percentile',fontsize=18)
ax.tick_params(axis='both', which='major', labelsize=12)
ax.legend(loc=1,numpoints=1,fontsize=12,frameon=False)
plt.tight_layout()
#
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/Disrupt_ArticleType.pdf')
plt.show()


# In[ ]:




# In[105]:

len(W1)


# In[13]:

#aggregate data by team size
disPaper1=defaultdict(lambda:[])
impPaper1=defaultdict(lambda:[])
depPaper1=defaultdict(lambda:[])
popPaper1=defaultdict(lambda:[])
for i in W1:
    if i in Wmp:
        teamsize,impact,disruption,timegap, meanimp1=W1[i]
        disPaper1[teamsize].append(disruption)
        impPaper1[teamsize].append(impact)
        depPaper1[teamsize].append(timegap)
        popPaper1[teamsize].append(Wmp[i])
#aggregate data by team size
disPaper2=defaultdict(lambda:[])
impPaper2=defaultdict(lambda:[])
depPaper2=defaultdict(lambda:[])
popPaper2=defaultdict(lambda:[])
for i in W2:
    if i in Wmp:
        teamsize,impact,disruption,timegap, meanimp1=W2[i]
        disPaper2[teamsize].append(disruption)
        impPaper2[teamsize].append(impact)
        depPaper2[teamsize].append(timegap)
        popPaper2[teamsize].append(Wmp[i])


# In[ ]:




# In[ ]:




# In[14]:

# mean
xdisPaper1,ydisPaper1=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1.items()])).T
ydisPaper1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper1]
# mean
xdisPaper2,ydisPaper2=np.array(sorted([(k,np.mean(v)) for k,v in disPaper2.items()])).T
ydisPaper2=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper2]


# In[17]:




# In[ ]:




# In[96]:

len(W2)


# In[57]:

# mean
xdisPaper1,ydisPaper1=np.array(sorted([(k,np.mean(v)) for k,v in disPaper1.items()])).T
ximpPaper1,yimpPaper1=np.array(sorted([(k,np.mean(v)) for k,v in impPaper1.items()])).T
xdepPaper1,ydepPaper1=np.array(sorted([(k,np.mean(v)) for k,v in depPaper1.items()])).T
xpopPaper1,ypopPaper1=np.array(sorted([(k,np.median(v)) for k,v in popPaper1.items()])).T

# CI
ydisPaperCIa1,ydisPaperCIb1=calculateCI(disPaper1,'mean',50)
yimpPaperCIa1,yimpPaperCIb1=calculateCI(impPaper1,'mean',50)
ydepPaperCIa1,ydepPaperCIb1=calculateCI(depPaper1,'mean',50)
ypopPaperCIa1,ypopPaperCIb1=calculateCI(popPaper1,'median',50)

#log
xdisPaperlog1,ydisPaperlog1=log2linearBin(xdisPaper1,ydisPaper1)
ximpPaperlog1,yimpPaperlog1=log2linearBin(ximpPaper1,yimpPaper1)
xdepPaperlog1,ydepPaperlog1=log2linearBin(xdepPaper1,ydepPaper1)
xpopPaperlog1,ypopPaperlog1=log2linearBin(xpopPaper1,ypopPaper1)

#percentile
ydisPaper1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper1]
ydisPaperCIa1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperCIa1]
ydisPaperCIb1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperCIb1]
ydisPaperlog1=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperlog1]


# In[58]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper1,ydisPaper1, label="Disruption",color='#117733')
par1.plot(ximpPaper1,yimpPaper1, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa1,ydisPaperCIb1,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa1,yimpPaperCIb1,color='gray',alpha=0.15)

host.set_xlim(1, 10)
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(20,32)
par1.set_yticks([20,23,26,29,32])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPaperlog1,ydisPaperlog1,linewidth=1,color='#117733')
par1.plot(ximpPaperlog1,yimpPaperlog1,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(20, 100)
par1.set_yticks([20,60,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review1.pdf')


# In[114]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper1,ydisPaper1, label="Disruption",color='#117733')
par1.plot(ximpPaper1,yimpPaper1, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa1,ydisPaperCIb1,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa1,yimpPaperCIb1,color='gray',alpha=0.15)

host.set_xlim(1, 10)
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(20,32)
par1.set_yticks([20,23,26,29,32])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPaperlog1,ydisPaperlog1,linewidth=1,color='#117733')
par1.plot(ximpPaperlog1,yimpPaperlog1,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(20, 100)
par1.set_yticks([20,60,100])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)
subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')



[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review1.pdf')


# In[ ]:




# In[97]:

# mean
xdisPaper2,ydisPaper2=np.array(sorted([(k,np.mean(v)) for k,v in disPaper2.items()])).T
ximpPaper2,yimpPaper2=np.array(sorted([(k,np.mean(v)) for k,v in impPaper2.items()])).T
xdepPaper2,ydepPaper2=np.array(sorted([(k,np.mean(v)) for k,v in depPaper2.items()])).T
xpopPaper2,ypopPaper2=np.array(sorted([(k,np.median(v)) for k,v in popPaper2.items()])).T

# CI
ydisPaperCIa2,ydisPaperCIb2=calculateCI(disPaper2,'mean',50)
yimpPaperCIa2,yimpPaperCIb2=calculateCI(impPaper2,'mean',50)
ydepPaperCIa2,ydepPaperCIb2=calculateCI(depPaper2,'mean',50)
ypopPaperCIa2,ypopPaperCIb2=calculateCI(popPaper2,'median',50)

#log
xdisPaperlog2,ydisPaperlog2=log2linearBin(xdisPaper2,ydisPaper2)
ximpPaperlog2,yimpPaperlog2=log2linearBin(ximpPaper2,yimpPaper2)
xdepPaperlog2,ydepPaperlog2=log2linearBin(xdepPaper2,ydepPaper2)
xpopPaperlog2,ypopPaperlog2=log2linearBin(xpopPaper2,ypopPaper2)

#percentile
ydisPaper2=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaper2]
ydisPaperCIa2=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperCIa2]
ydisPaperCIb2=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperCIb2]
ydisPaperlog2=[stats.percentileofscore(DisruptionPaper,i) for i in ydisPaperlog2]


# In[116]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper2,ydisPaper2, label="Disruption",color='#117733')
par1.plot(ximpPaper2,yimpPaper2, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa2,ydisPaperCIb2,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa2,yimpPaperCIb2,color='gray',alpha=0.15)

host.set_xlim(1, 10)
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(100,400)
par1.set_yticks([100,200,300,400,500])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')



###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdisPaperlog2,ydisPaperlog2,linewidth=1,color='#117733')
par1.plot(ximpPaperlog2,yimpPaperlog2,linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(100, 300)
par1.set_yticks([100,200,300])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)



[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[146]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper2,ydisPaper2, label="Disruption",color='#117733')
par1.plot(ximpPaper2,yimpPaper2, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa2,ydisPaperCIb2,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa2,yimpPaperCIb2,color='gray',alpha=0.15)

host.set_xlim(1, 4)
host.set_xticks([1,2,3,4])
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(100,250)
par1.set_yticks([100,150,200,250])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')



###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 10)
subax.set_xscale('log')
subax.plot(xdisPaperlog2[:-1],ydisPaperlog2[:-1],linewidth=1,color='#117733')
par1.plot(ximpPaperlog2[:-1],yimpPaperlog2[:-1],linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(100, 300)
par1.set_yticks([100,200,300])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)


[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[178]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdisPaper2,ydisPaper2, label="Disruption",color='#117733')
par1.plot(ximpPaper2,yimpPaper2, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydisPaperCIa2,ydisPaperCIb2,color='gray',alpha=0.15)
par1.fill_between(range(1,11), yimpPaperCIa2,yimpPaperCIb2,color='gray',alpha=0.15)

host.set_xlim(1, 4)
host.set_xticks([1,2,3,4])
host.set_ylim(20,100)
host.set_yticks([20,40,60,80,100])
par1.set_ylim(100,250)
par1.set_yticks([100,150,200,250])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 10)
subax.set_xscale('log')
subax.plot(xdisPaperlog2[:-1],ydisPaperlog2[:-1],linewidth=1,color='#117733')
par1.plot(ximpPaperlog2[:-1],yimpPaperlog2[:-1],linewidth=1,color='#882255')
subax.set_ylim(10,90)
subax.set_yticks([10,50,90])
par1.set_ylim(100, 300)
par1.set_yticks([100,200,300])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review2.pdf')





# In[ ]:




# In[ ]:




# In[ ]:




# In[119]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPaper1,ydepPaper1, label="Disruption",color='#117733')
par1.plot(xpopPaper1,ypopPaper1, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydepPaperCIa1,ydepPaperCIb1,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPaperCIa1,ypopPaperCIb1,color='gray',alpha=0.15)


host.set_xlim(1, 10)
host.set_ylim(7.5, 9.5)
#host.set_yticks([7,9,12])
par1.set_ylim(40,80)
par1.set_yticks([40,50,60,70,80])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepPaperlog1,ydepPaperlog1,linewidth=1,color='#117733')
par1.plot(xpopPaperlog1,ypopPaperlog1,linewidth=1,color='#882255')
subax.set_ylim(6, 10)
subax.set_yticks([6,8,10])
par1.set_ylim(40,80)
par1.set_yticks([40,60,80])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()


# In[147]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPaper1,ydepPaper1, label="Disruption",linestyle='--',color='#117733')
par1.plot(xpopPaper1,ypopPaper1, label="Impact",linestyle='--',color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydepPaperCIa1,ydepPaperCIb1,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPaperCIa1,ypopPaperCIb1,color='gray',alpha=0.15)


host.set_xlim(1, 10)
host.set_ylim(7.5, 9.5)
#host.set_yticks([7,9,12])
par1.set_ylim(40,80)
par1.set_yticks([40,50,60,70,80])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')


host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 100)
subax.set_xscale('log')
subax.plot(xdepPaperlog1,ydepPaperlog1,linewidth=1,linestyle='--',color='#117733')
par1.plot(xpopPaperlog1,ypopPaperlog1,linewidth=1,linestyle='--',color='#882255')
subax.set_ylim(6, 10)
subax.set_yticks([6,8,10])
par1.set_ylim(40,80)
par1.set_yticks([40,60,80])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)


subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review3.pdf')


# In[170]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPaper2,ydepPaper2, label="Disruption",color='#117733')
par1.plot(xpopPaper2,ypopPaper2, label="Impact",color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydepPaperCIa2,ydepPaperCIb2,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPaperCIa2,ypopPaperCIb2,color='gray',alpha=0.15)


host.set_xlim(1, 4)
host.set_xticks([1,2,3,4])
host.set_ylim(6, 9)
host.set_yticks([6,7,8,9])
par1.set_ylim(50,100)
par1.set_yticks([50,60,70,80,90,100])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 10)
subax.set_xscale('log')
subax.plot(xdepPaperlog2[:-1],ydepPaperlog2[:-1],linewidth=1,color='#117733')
par1.plot(xpopPaperlog2[:-1],ypopPaperlog2[:-1],linewidth=1,color='#882255')
subax.set_ylim(6, 8)
subax.set_yticks([6,7,8])
par1.set_ylim(50,90)
par1.set_yticks([50,70,90])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.1.pdf')


# In[137]:

zip(xdepPaperlog2,ydepPaperlog2)


# In[ ]:




# In[ ]:




# In[179]:

fig = plt.figure(figsize=(5,5),facecolor='white')
#------------main figure 122-------------------

host = host_subplot(111)
plt.subplots_adjust(right=1)
host.tick_params(axis='x', which='both',bottom='on',top='off')
par1 = host.twinx()

host.plot(xdepPaper2,ydepPaper2, label="Disruption",linestyle='--',color='#117733')
par1.plot(xpopPaper2,ypopPaper2, label="Impact",linestyle='--',color='#882255')
host.plot([1,16],[70,70],color='#117733',linestyle='--')
host.fill_between(range(1,11), ydepPaperCIa2,ydepPaperCIb2,color='gray',alpha=0.15)
par1.fill_between(range(1,11), ypopPaperCIa2,ypopPaperCIb2,color='gray',alpha=0.15)


host.set_xlim(1, 4)
host.set_xticks([1,2,3,4])
host.set_ylim(6, 9)
host.set_yticks([6,7,8,9])
par1.set_ylim(50,100)
par1.set_yticks([50,60,70,80,90,100])
host.tick_params(axis='both', which='major', labelsize=12)
par1.tick_params(axis='both', which='major', labelsize=12)

[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
host.tick_params('both', length=4, which='major')
par1.tick_params('both', length=4, which='major')

host.set_xticklabels('')
host.set_yticklabels('')
par1.set_xticklabels('')
par1.set_yticklabels('')

###-----------------------------------------------inset---------------

subax = add_subplot_axes(host,[0.4,0.72,0.3,0.3])
par1 = subax.twinx()
subax.set_xlim(1, 10)
subax.set_xscale('log')
subax.plot(xdepPaperlog2[:-1],ydepPaperlog2[:-1],linestyle='--',linewidth=1,color='#117733')
par1.plot(xpopPaperlog2[:-1],ypopPaperlog2[:-1],linestyle='--',linewidth=1,color='#882255')
subax.set_ylim(6, 8)
subax.set_yticks([6,7,8])
par1.set_ylim(50,90)
par1.set_yticks([50,70,90])
subax.tick_params(axis='both', which='major', labelsize=10)
par1.tick_params(axis='both', which='major', labelsize=10)

[i.set_linewidth(0.4) for i in subax.spines.itervalues()]
[i.set_linewidth(0.4) for i in par1.spines.itervalues()]
subax.tick_params('both', length=2, which='major')
par1.tick_params('both', length=2, which='major')



subax.set_xticklabels('')
subax.set_yticklabels('')
par1.set_yticklabels('')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review4.pdf')




# In[ ]:




# In[ ]:




# In[90]:

# top 5%
DisruptionPaper1=[]
ImpactPaper1=[]
TimegapPaper1=[]
MeanpopPaper1=[]
for ts in range(1,11):
    DisruptionPaper1+=disPaper1[ts]
    ImpactPaper1+=impPaper1[ts]
    TimegapPaper1+=depPaper1[ts]
    MeanpopPaper1+=popPaper1[ts]
    
rr=95
a1,a2,a3,a4=np.percentile(ImpactPaper1,rr),np.percentile(DisruptionPaper1,rr),np.percentile(TimegapPaper1,rr),np.percentile(MeanpopPaper1,rr)
[a1,a2,a3,a4]

top5Paper1=[]
for ts in range(1,11):
    ratio11=len([i for i in impPaper1[ts] if i>=a1])/float(len(impPaper1[ts]))
    ratio21=len([i for i in disPaper1[ts] if i>=a2])/float(len(disPaper1[ts]))
    ratio31=len([i for i in depPaper1[ts] if i>=a3])/float(len(depPaper1[ts]))
    ratio41=len([i for i in popPaper1[ts] if i>=a4])/float(len(popPaper1[ts]))
    top5Paper1.append([ts,ratio11,ratio21,ratio31,ratio41])


# In[161]:

# top 5%
DisruptionPaper2=[]
ImpactPaper2=[]
TimegapPaper2=[]
MeanpopPaper2=[]
for ts in range(1,11):
    DisruptionPaper2+=disPaper2[ts]
    ImpactPaper2+=impPaper2[ts]
    TimegapPaper2+=depPaper2[ts]
    MeanpopPaper2+=popPaper2[ts]
    
rr=95
a1,a2,a3,a4=np.percentile(ImpactPaper2,rr),np.percentile(DisruptionPaper2,rr),np.percentile(TimegapPaper2,rr),np.percentile(MeanpopPaper2,rr)
[a1,a2,a3,a4]

top5Paper2=[]
for ts in range(1,11):
    ratio12=len([i for i in impPaper2[ts] if i>=a1])/float(len(impPaper2[ts]))
    ratio22=len([i for i in disPaper2[ts] if i>=a2])/float(len(disPaper2[ts]))
    ratio32=len([i for i in depPaper2[ts] if i>=a3])/float(len(depPaper2[ts]))
    ratio42=len([i for i in popPaper2[ts] if i>=a4])/float(len(popPaper2[ts]))
    top5Paper2.append([ts,ratio12,ratio22,ratio32,ratio42])


# In[135]:

tss,r1,r2,r3,r4=np.array(top5Paper1).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
#plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()


#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.a.pdf')


# In[140]:

tss,r1,r2,r3,r4=np.array(top5Paper1).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
#plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)


host.set_xticklabels('')
host.set_yticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=2, which='major')
host.tick_params('both', length=2, which='major')


plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review5.pdf')


# In[ ]:




# In[173]:

tss,r1,r2,r3,r4=np.array(top5Paper2).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
#plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,4)
plt.ylim(0,2)
plt.xticks([1,2,3,4])
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()


#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.a.pdf')


# In[180]:


tss,r1,r2,r3,r4=np.array(top5Paper2).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
#plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
#plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,4)
plt.ylim(0,2)
plt.xticks([1,2,3,4])
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)



host.set_xticklabels('')
host.set_yticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=2, which='major')
host.tick_params('both', length=2, which='major')


plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review6.pdf')




# In[ ]:




# In[95]:

tss,r1,r2,r3,r4=np.array(top5Paper1).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
#plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
#plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()



#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.b.pdf')


# In[142]:

tss,r1,r2,r3,r4=np.array(top5Paper1).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
#plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
#plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,10)
plt.ylim(0,2)
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)



host.set_xticklabels('')
host.set_yticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=2, which='major')
host.tick_params('both', length=2, which='major')


plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review7.pdf')


# In[175]:

tss,r1,r2,r3,r4=np.array(top5Paper2).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
#plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
#plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,4)
plt.ylim(0,2)
plt.xticks([1,2,3,4])
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)

plt.legend(loc='upper center',numpoints=1,fontsize=10,frameon=False)
plt.tight_layout()



#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig2.3.b.pdf')




# In[181]:

tss,r1,r2,r3,r4=np.array(top5Paper2).T
fig = plt.figure(figsize=(5, 5),facecolor='white')

#------------main figure 121-------------------
ratio=1-rr/100.0

host = host_subplot(111)
#plt.plot(tss,r2/ratio,color='#117733',label='Top 5% Disruption')
plt.plot(tss,r3/ratio,color='#117733',linestyle='--',label='Top 5% Depth')
#plt.plot(tss,r1/ratio,color='#882255',label='Top 5% Impact')
plt.plot(tss,r4/ratio,color='#882255',linestyle='--',label='Top 5% Popularity')
#plt.xlabel('team size',fontsize=14)
#plt.ylabel('Probability',fontsize=14)
plt.plot([1,100],[1,1],color='gray',linestyle='-',alpha=0.5)
plt.xlim(1,4)
plt.ylim(0,2)
plt.xticks([1,2,3,4])
#plt.legend(loc=1,numpoints=1,fontsize=10,frameon=False)
host.tick_params(axis='both', which='major', labelsize=12)


host.set_xticklabels('')
host.set_yticklabels('')
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
[i.set_linewidth(0.4) for i in host.spines.itervalues()]
host.tick_params('both', length=2, which='major')
host.tick_params('both', length=2, which='major')


plt.tight_layout()

plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/review8.pdf')




# In[ ]:



