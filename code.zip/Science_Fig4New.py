
# coding: utf-8

# In[1]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
from openpyxl import load_workbook
from scipy import stats
import matplotlib.patches as patches


# In[2]:

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# In[3]:

WOS={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        WOS[doi]=int(ndoi)
J={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/journals.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        nd,name,xx=line.strip().split('\t')
        J[name]=int(nd)

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[4]:

# papers
W={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)#288
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0:
            W[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[ ]:




# In[53]:

wb1 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physiology or Medicine.xlsx', read_only=True)
wb2 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physics.xlsx', read_only=True)
wb3 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Chemistry.xlsx', read_only=True)

def GetIDs(wb):
    sheet = wb.get_sheet_by_name(wb.get_sheet_names()[0])
    data=[]
    sheet = wb.get_sheet_by_name('Sheet1')
    for row in sheet.iter_rows():
        data_row = []
        for cell in row:
            data_row += [cell.value]
        data += [data_row]
    d={}
    j=set([])
    for i in data[1:]:
        a=str(i[-1])
        if a in WOS and WOS[a] in W:
            year,subject,ts,imp,dis,jour=W[WOS[a]]
            d[WOS[a]] = year,ts,imp,dis
            if jour not in j:
                j.add(jour)
    return d,j


# In[54]:

N=defaultdict(lambda:[])
NJ=defaultdict(lambda:set([]))

d,j=GetIDs(wb1)
N[1]=d.values()
NJ[1]=j
d,j=GetIDs(wb2)
N[2]=d.values()
NJ[2]=j
d,j=GetIDs(wb3)
N[3]=d.values()
NJ[3]=j

#1=生理学或医学，2=物理，3=化学


# In[8]:

gt=defaultdict(lambda:[0,0])# n of grants, total size
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if grantSize>=10**5:
            gt[Id][0]+=1
            gt[Id][1]+=grantSize

G=defaultdict(lambda:[])
GJ=defaultdict(lambda:set([]))
for k,v in gt.items():
    if k in W:
        year,subject,teamsize,impact,disruptive,journal=W[k]
        if year>=2008:
            grantsize=v[1]/v[0]
            if grantsize<10**6:
                gs=1
            if 10**6<=grantsize<=5*10**6:
                gs=2
            if 5*10**6<=grantsize:
                gs=3
            G[gs].append([teamsize,impact,disruptive])
            GJ[gs].add(journal)


# In[9]:

len(G[1]),len(G[2]),len(G[3])


# In[10]:

len(G[1])+len(G[2])+len(G[3])


# In[11]:

140972/191645.0,24298/191645.0,26375/191645.0


# In[10]:

t1,i1,d1= np.array(N[1]).T
t2,i2,d2= np.array(N[2]).T
t3,i3,d3= np.array(N[3]).T
t4,i4,d4= np.array(G[1]).T
t5,i5,d5= np.array(G[2]).T
t6,i6,d6= np.array(G[3]).T


# In[13]:




# In[22]:

# get their mirrors
Z={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/mostRelevantPaperSameAuthor.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        a,b,w=map(int,line.strip().split('\t'))
        Z[a]=[b,w]


# In[23]:

NP=set([])#nobel prize paper
#NP1=set([])#nobel prize paper mirror
for wb in [wb1,wb2,wb3]:
    sheet = wb.get_sheet_by_name(wb.get_sheet_names()[0])
    data=[]
    sheet = wb.get_sheet_by_name('Sheet1')
    for row in sheet.iter_rows():
        data_row = []
        for cell in row:
            data_row += [cell.value]
        data += [data_row]
    d={}
    j=set([])
    for i in data[1:]:
        a=str(i[-1])
        if a in WOS and WOS[a] in W:
            p=WOS[a]
            NP.add(p)
#for p in NP:
#    if p in Z:
#        NP1.add(Z[p][0])



# In[11]:

NSF=set([])#NSF paper
#NSF1=set([])#NSF paper mirror
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        p=int(Id)
        NSF.add(p)
#for p in NSF:
#    if p in Z:
#        NSF1.add(Z[p][0])
            
#t7,d7=np.array([(W[i][2],W[i][4]) for i in NP1 if i in W and i not in NP]).T
#t8,d8=np.array([(W[i][2],W[i][4]) for i in NSF1 if i in W and i not in NSF]).T


# In[68]:

Disruptive=[v[-2] for v in W1.values()]
drss=random.sample(Disruptive,10000)
stats.percentileofscore(drss, 0)


# In[71]:

Disruptive=[v[-2] for v in W.values()]


# In[72]:

stats.percentileofscore(Disruptive, 0)


# In[73]:

stats.percentileofscore(Disruptive, 0.10)


# In[ ]:




# In[14]:

def ave(ts,ds):
    A=defaultdict(lambda:[])
    for m,d in zip(ts,ds):
        if 1<=m<=10:
            A[m].append(d)
    x,y,z=np.array(sorted([(k,np.mean(v),len(v)/float(len(ts))) for k,v in A.items()])).T
    return x,y,z


# In[15]:

x0_,y0_,z0_=ave([W1[k][2] for k in W1],[W1[k][-2] for k in W1])
ny0_=[stats.percentileofscore(drss, i) for i in y0_]


# In[44]:

#x7_,y7_,z7_=ave(t7,d7)
#x8_,y8_,z8_=ave(t8,d8)
#ny7_=[stats.percentileofscore(drss, i) for i in y7_]
#ny8_=[stats.percentileofscore(drss, i) for i in y8_]


# In[19]:

len(t4)


# In[16]:

x1_,y1_,z1_=ave(t1,d1)
x2_,y2_,z2_=ave(t2,d2)
x3_,y3_,z3_=ave(t3,d3)
x4_,y4_,z4_=ave(t4,d4)
x5_,y5_,z5_=ave(t5,d5)
x6_,y6_,z6_=ave(t6,d6)
ny1_=[stats.percentileofscore(drss, i) for i in y1_]
ny2_=[stats.percentileofscore(drss, i) for i in y2_]
ny3_=[stats.percentileofscore(drss, i) for i in y3_]
ny4_=[stats.percentileofscore(drss, i) for i in y4_]
ny5_=[stats.percentileofscore(drss, i) for i in y5_]
ny6_=[stats.percentileofscore(drss, i) for i in y6_]


# In[24]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
plt.plot(x0_,ny0_,'k--')
plt.scatter(x0_,ny0_,edgecolor='gray',facecolor='none',s=z0_*3000,label='Population')
plt.scatter(x1_,ny1_,color='#FFC857',s=z1_*3000,label='Nobel MED')
plt.scatter(x2_,ny2_,color='#C74F1B',s=z2_*3000,label='Nobel PHY')
plt.scatter(x3_,ny3_,color='#5A2A27',s=z2_*3000,label='Nobel CHE')
#
plt.scatter(x4_,ny4_,color='SteelBlue',s=z4_*3000,alpha=0.3,label='NSF < 1M')
plt.scatter(x5_,ny5_,color='SteelBlue',s=z5_*3000,alpha=0.6,label='1M <= NSF < 5M')
plt.scatter(x6_,ny6_,color='SteelBlue',s=z6_*3000,label='NSF >= 5M')
#
#plt.plot([0,11],[70,70],color='gray',alpha=0.5)
#plt.plot([3,3],[0,110],color='gray',alpha=0.5)
plt.xlim(0.3,10.5)
plt.xticks(range(2,12,2))
plt.ylim(0,110)
ax.add_patch(patches.Rectangle((0, 70),  3, 40,facecolor='green',edgecolor="none",alpha=0.05))
ax.add_patch(patches.Rectangle((3, 0),  8.5, 70,facecolor='r',edgecolor="none",alpha=0.05))

#plt.scatter(x7_,ny7_,color='r',s=z7_*3000)
#plt.scatter(x8_,ny8_,color='b',s=z8_*3000)



plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[48]:

np.mean(d7),np.median(d7),np.mean(d8),np.median(d8)


# In[169]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
w = 1/8.0
r=3
plt.bar(np.array([1]), [3.28-1],         w,label='Nobel Physics',color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+w, [3.14-1],        w,label='Nobel Medicine',color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1])+2*w, [2.83-1],        w,label='Nobel Chemistry',color='#FFC857',edgecolor = "none")
plt.bar(np.array([1])+3*w, [0.67-1],        w,label='NSF < 1M',color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w, [0.65-1],        w,label='1M <= NSF < 5M',color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w, [0.51-1],        w,label='NSF >= 5M',edgecolor = "none",facecolor='SteelBlue',alpha=1)
#
xd=9*w
plt.bar(np.array([1])+xd, [0.45-1],         w,color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+w+xd, [0.37-1],        w,color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1])+2*w+xd, [0.43-1],        w,color='#FFC857',edgecolor = "none")
plt.bar(np.array([1])+3*w+xd, [0.95-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w+xd, [1.1-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w+xd, [1.18-1],        w,edgecolor = "none",facecolor='SteelBlue',alpha=1)


plt.legend(loc=1,fontsize=10,ncol=1,frameon=False)
ax.set_xlim(0.9,3)
ax.set_ylim(-1,3)
ax.set_yticks([-1,0,1,2,3])
ax.set_yticklabels([0,1,2,3,4])
#ax.set_xticks([1.35,2.3])
#plt.ylabel('Ratio of Percentages',fontsize=14)
ax.plot([0,10],[0,0],'k--')

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')
#ax.set_xticklabels('')
#ax.set_yticklabels('')

ax.axvspan(0.9, 2, facecolor='green',edgecolor="none",alpha=0.05)
ax.axvspan(2, 4, facecolor='r',edgecolor="none",alpha=0.05)

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.3.pdf')


# In[108]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
w = 1/8.0
r=3
plt.bar(np.array([1])+3*w, [0.67-1],        w,label='NSF < 1M',color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w, [0.65-1],        w,label='1M <= NSF < 5M',color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w, [0.51-1],        w,label='NSF >= 5M',edgecolor = "none",facecolor='SteelBlue',alpha=1)
#
xd=9*w

plt.bar(np.array([1])+3*w+xd, [0.95-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w+xd, [1.1-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w+xd, [1.18-1],        w,edgecolor = "none",facecolor='SteelBlue',alpha=1)

#plt.legend(loc=1,fontsize=10,ncol=1,frameon=False)
ax.set_xlim(0.9,3)
ax.set_ylim(-1,0.5)
ax.set_yticks([-1,-0.5,0,0.5])
ax.set_yticklabels([0,.5,1,1.5])
#ax.set_xticks([1.35,2.3])
#plt.ylabel('Ratio of Percentages',fontsize=14)
ax.plot([0,10],[0,0],'k--')


plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.3.pdf')
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/nsf1.pdf')


# In[ ]:




# In[ ]:




# In[49]:




# In[59]:

sdrss=random.sample(Disruptive,1000)
stats.percentileofscore(sdrss, 0)


# In[16]:




# In[135]:




# In[10]:

len(N[1]),len(N[2]),len(N[3])


# In[3]:




# In[215]:

len(G[1]),len(G[2]),len(G[3])


# In[34]:




# In[136]:

# team size base-line distributions
tMed=Counter([v[2] for v in W.values() if v[-1] in NJ[1] ])
tPhy=Counter([v[2] for v in W.values() if v[-1] in NJ[2]])
tChe=Counter([v[2] for v in W.values() if v[-1] in NJ[3]])
tNSF1=Counter([v[2] for v in W.values() if v[-1] in GJ[1] and v[0]>=2008])
tNSF2=Counter([v[2] for v in W.values() if v[-1] in GJ[2] and v[0]>=2008])
tNSF3=Counter([v[2] for v in W.values() if v[-1] in GJ[3] and v[0]>=2008])
#
xtMed,ytMed=np.array(sorted(tMed.items())).T
xtPhy,ytPhy=np.array(sorted(tPhy.items())).T
xtChe,ytChe=np.array(sorted(tChe.items())).T
xtNSF1,ytNSF1=np.array(sorted(tNSF1.items())).T
xtNSF2,ytNSF2=np.array(sorted(tNSF2.items())).T
xtNSF3,ytNSF3=np.array(sorted(tNSF3.items())).T
#
ytMed=ytMed/float(ytMed.sum())
ytPhy=ytPhy/float(ytPhy.sum())
ytChe=ytChe/float(ytChe.sum())
ytNSF1=ytNSF1/float(ytNSF1.sum())
ytNSF2=ytNSF2/float(ytNSF2.sum())
ytNSF3=ytNSF3/float(ytNSF3.sum())

x1,y1=np.array(sorted(Counter(t1).items())).T
x2,y2=np.array(sorted(Counter(t2).items())).T
x3,y3=np.array(sorted(Counter(t3).items())).T
x4,y4=np.array(sorted(Counter(t4).items())).T
x5,y5=np.array(sorted(Counter(t5).items())).T
x6,y6=np.array(sorted(Counter(t6).items())).T
y1=y1/float(sum(y1))
y2=y2/float(sum(y2))
y3=y3/float(sum(y3))
y4=y4/float(sum(y4))
y5=y5/float(sum(y5))
y6=y6/float(sum(y6))


# In[269]:




fig = plt.figure(figsize=(9,6)) 
ax = fig.add_subplot(231)
plt.plot(xtMed,ytMed,'k--')
plt.plot(x1,y1,color='#FFC857',marker='.',linestyle='-',label='Nobel MED')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.4)
#
ax = fig.add_subplot(232)
plt.plot(xtPhy,ytPhy,'k--')
plt.plot(x2,y2,color='#C74F1B',marker='.',linestyle='-',label='Nobel PHY')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.4)
#
ax = fig.add_subplot(233)
plt.plot(xtChe,ytChe,'k--')
plt.plot(x3,y3,color='#5A2A27',marker='.',linestyle='-',label='Nobel CHE')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.4)
#
ax = fig.add_subplot(234)
plt.plot(xtNSF1,ytNSF1,'k--')
plt.plot(x4,y4,color='SteelBlue',alpha=0.3,marker='.',linestyle='-',label='NSF < 1M')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.4)
#
ax = fig.add_subplot(235)
plt.plot(xtNSF2,ytNSF2,'k--')
plt.plot(x5,y5,color='SteelBlue',alpha=0.6,marker='.',linestyle='-',label='1M <= NSF < 5M')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.4)
#
ax = fig.add_subplot(236)
plt.plot(xtNSF3,ytNSF3,'k--')
plt.plot(x6,y6,color='SteelBlue',alpha=1,marker='.',linestyle='-',label='NSF >= 5M')
plt.xlim(1,10)
plt.xlabel('team size')
plt.legend(loc=1,fontsize=10,numpoints=1)
plt.ylabel('probability')
plt.ylim(0,0.4)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4Raw.pdf')




# In[245]:

plt.plot(range(1,11),y1[:10]/ytMed[:10],color='#FFC857',marker='.',linestyle='-',label='Nobel MED')
plt.plot(range(1,11),y2[:10]/ytPhy[:10],color='#C74F1B',marker='.',linestyle='-',label='Nobel PHY')
plt.plot(range(1,11),y3[:10]/ytChe[:10],color='#5A2A27',marker='.',linestyle='-',label='Nobel CHE')

plt.plot([1,10],[1,1],'k-',alpha=0.3)
plt.legend(loc=1)


# In[218]:

plt.plot(range(1,11),y4[:10]/ytNSF1[:10],color='SteelBlue',alpha=0.3,marker='.',linestyle='-',label='NSF < 1M')
plt.plot(range(1,11),y5[:10]/ytNSF2[:10],color='SteelBlue',alpha=0.6,marker='.',linestyle='-',label='1M <= NSF < 5M')
plt.plot(range(1,11),y6[:10]/ytNSF3[:10],color='SteelBlue',alpha=1,marker='.',linestyle='-',label='NSF >= 5M')
plt.plot([1,10],[1,1],'k-',alpha=0.3)
plt.legend(loc=1)


# In[ ]:




# In[ ]:




# In[124]:

'''
NB=list(d1[t1>3])+list(d2[t2>3])+list(d3[t3>3])
NS=list(d1[t1<=3])+list(d2[t2<=3])+list(d3[t3<=3])
FB=list(d4[t4>3])+list(d5[t5>3])
FS=list(d4[t4<=3])+list(d5[t5<=3])
#
NB=[np.round(i,2) for i in NB]
NS=[np.round(i,2) for i in NS]
FB=[np.round(i,2) for i in FB]
FS=[np.round(i,2) for i in FS]
'''


# In[50]:




# In[81]:




# In[123]:




# In[120]:




# In[346]:




# In[75]:




# In[ ]:




# In[19]:

fig = plt.figure(figsize=(8,4)) 
ax = fig.add_subplot(121)
plt.plot(xdisNobelBaseLine,ydisNobelBaseLine,'k--')
plt.plot(xn1,yn1,color='#FFC857',label='Nobel Med')
plt.plot(xn2,yn2,color='#AA4466',label='Nobel Phy')
plt.plot(xn3,yn3,color='#5A2A27',label='Nobel Che')
#plt.xticks([-0.02,-0.01,0,0.01,0.02])
plt.xlim(-0.05,0.05)
plt.xlabel('disruptiveness')
plt.ylabel('probability')
plt.legend(loc=2,fontsize=10,numpoints=1)
#
ax = fig.add_subplot(122)
plt.plot(xdisNSFBaseLine,yNSFBaseLine,'k--')
plt.plot(xf1,yf1,color='#119DA4',label='NSF < 0.5M')
plt.plot(xf2,yf2,color='#19647E',label='0.5M< NSF < 1M')
plt.plot(xf3,yf3,color='gray',label='NSF > 1M')
#plt.xticks([-0.02,-0.01,0,0.01,0.02])
plt.xlim(-0.05,0.05)
plt.xlabel('disruptiveness')
plt.ylabel('probability')
plt.legend(loc=2,fontsize=10,numpoints=1)
#
plt.tight_layout()


# In[ ]:




# In[125]:

xns1,yns1=np.array(sorted(Counter(NS).items())).T
yns1=yns1/float(yns1.sum())
xnb1,ynb1=np.array(sorted(Counter(NB).items())).T
ynb1=ynb1/float(ynb1.sum())
xfs1,yfs1=np.array(sorted(Counter(FS).items())).T
yfs1=yfs1/float(yfs1.sum())
xfb1,yfb1=np.array(sorted(Counter(FB).items())).T
yfb1=yfb1/float(yfb1.sum())

disNobelBaseLine=[v[4] for v in W.values() if v[-1]                   in NJ[1] or v[-1] in NJ[2] or v[-1] in NJ[3]]
disNSFBaseLine=[v[4] for v in W.values() if v[-1]                   in GJ[1] or v[-1] in GJ[2] and v[0]>=2008]
disNobelBaseLine=[np.round(i,2) for i in disNobelBaseLine]
disNSFBaseLine=[np.round(i,2) for i in disNSFBaseLine]
xdisNobelBaseLine,ydisNobelBaseLine=np.array(sorted(Counter(disNobelBaseLine).items())).T
xdisNSFBaseLine,yNSFBaseLine=np.array(sorted(Counter(disNSFBaseLine).items())).T
ydisNobelBaseLine=ydisNobelBaseLine/float(ydisNobelBaseLine.sum())
yNSFBaseLine=yNSFBaseLine/float(yNSFBaseLine.sum())


dicNobel=dict((i,j) for i,j in  zip(xdisNobelBaseLine,ydisNobelBaseLine) if -0.5<=i<=0.5)
dicNSF=dict((i,j) for i,j in  zip(xdisNSFBaseLine,yNSFBaseLine) if -0.5<=i<=0.5)
xns2,yns2=np.array([(i,j/dicNobel[i]) for i,j in  zip(xns1,yns1) if i in dicNobel]).T
xnb2,ynb2=np.array([(i,j/dicNobel[i]) for i,j in  zip(xnb1,ynb1) if i in dicNobel]).T
xfs2,yfs2=np.array([(i,j/dicNSF[i]) for i,j in  zip(xfs1,yfs1) if i in dicNSF]).T
xfb2,yfb2=np.array([(i,j/dicNSF[i]) for i,j in  zip(xfb1,yfb1) if i in dicNSF]).T


# In[171]:

NA=list(d1)+list(d2)+list(d3)
FA=list(d4)+list(d5)
NA=[np.round(i,2) for i in NA]
FA=[np.round(i,2) for i in FA]
xna1,yna1=np.array(sorted(Counter(NA).items())).T
yna1=yna1/float(yna1.sum())
xfa1,yfa1=np.array(sorted(Counter(FA).items())).T
yfa1=yfa1/float(yfa1.sum())
xna2,yna2=np.array([(i,j/dicNobel[i]) for i,j in  zip(xna1,yna1) if i in dicNobel]).T
xfa2,yfa2=np.array([(i,j/dicNSF[i]) for i,j in  zip(xfa1,yfa1) if i in dicNSF]).T


# In[ ]:




# In[132]:

fig = plt.figure(figsize=(8,4)) 
ax = fig.add_subplot(121)
plt.plot(xdisNobelBaseLine,ydisNobelBaseLine,'k--')
plt.plot(xns1,yns1,color='#AA4466',marker='',linestyle='-',linewidth=2,label='Nobel small')
plt.plot(xnb1,ynb1,color='#AA4466',marker='',linestyle='-',alpha=0.5,label='Nobel big')
#plt.xticks([-0.02,-0.01,0,0.01,0.02])
plt.xlim(-0.5,0.5)
plt.xlabel('disruptiveness')
plt.ylabel('probability')
plt.legend(loc=2,fontsize=10,numpoints=1)
#
ax = fig.add_subplot(122)
plt.plot(xdisNSFBaseLine,yNSFBaseLine,'k--')
plt.plot(xfs1,yfs1,color='RoyalBlue',marker='',linestyle='-',linewidth=2,label='NSF small')
plt.plot(xfb1,yfb1,color='RoyalBlue',marker='',linestyle='-',alpha=0.5,label='NSF big')
#plt.xticks([-0.02,-0.01,0,0.01,0.02])
plt.xlim(-0.5,0.5)
plt.xlabel('disruptiveness')
plt.ylabel('probability')
plt.legend(loc=2,fontsize=10,numpoints=1)
#
plt.tight_layout()


# In[175]:

fig = plt.figure(figsize=(10,5)) 
ax = fig.add_subplot(121)
#patterns = [ "/" , "\\" , "|" , "-" , "+" , "x", "o", "O", ".", "*" ]
w = 1/8.0
r=3
plt.bar(np.array([1,2]), [sum(y1[:r])/sum(ytMed[:r]),sum(y1[r:])/sum(ytMed[r:])],        w,label='Nobel Medicine',color='#AA4466',alpha=0.9,hatch=".")
plt.bar(np.array([1,2])+w, [sum(y2[:r])/sum(ytChe[:r]),sum(y2[r:])/sum(ytChe[r:])],         w,label='Nobel Chemistry',color='#AA4466',alpha=0.6,hatch=".")
plt.bar(np.array([1,2])+2*w, [sum(y3[:r])/sum(ytPhy[:r]),sum(y3[r:])/sum(ytPhy[r:])],        w,label='Nobel Physics',color='#AA4466',alpha=0.4,hatch=".")
plt.bar(np.array([1,2])+3*w, [sum(y4[:r])/sum(ytNSFs[:r]),sum(y4[r:])/sum(ytNSFs[r:])],        w,label='NSF < 1M',color='RoyalBlue',alpha=0.4,hatch="/" )
plt.bar(np.array([1,2])+4*w, [sum(y5[:r])/sum(ytNSFs[:r]),sum(y5[r:])/sum(ytNSFs[r:])],        w,label='NSF >= 1M',color='RoyalBlue',alpha=0.6,hatch="/" )
plt.legend(loc=1,fontsize=12,ncol=2,frameon=False)
ax.set_xlim(0.8,2.8)
ax.set_ylim(0,2)
ax.set_xticks([1.35,2.3])
ax.set_xticklabels(['Small team (m<=3)','Big team (m>3)'],fontsize=14)
ax.plot([0,10],[1,1],'k--')
ax.set_ylabel('Probability ratio',fontsize=14)
#
ax = fig.add_subplot(122)
plt.plot(xns2,yns2,color='#AA4466',marker='',linestyle='-',linewidth=2,label='Nobel Small')
plt.plot(xnb2,ynb2,color='#AA4466',marker='',linestyle='-',alpha=0.5,label='Nobel Big')
plt.plot(xfs2,yfs2,color='RoyalBlue',marker='',linestyle='-',linewidth=2,label='NSF Small')
plt.plot(xfb2,yfb2,color='RoyalBlue',marker='',linestyle='-',alpha=0.5,label='NSF Big')
plt.xlim(-0.2,0.2)
#ax.set_xticks([-0.02,-0.01,0,0.01,0.02])
plt.plot([0,0],[0,100],color='gray')
plt.plot([-1,1],[1,1],'k--')
plt.ylim(0.01,100)
plt.yscale('log')
#ax.set_yticks([0,1,2,3])
plt.legend(loc='upper center',fontsize=12,frameon=False,numpoints=1,ncol=2)
ax.set_xlabel('Disruption',fontsize=14)
ax.set_ylabel('Probability ratio',fontsize=14)
#
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4raw.pdf')


# In[544]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
w = 1/8.0
r=3
plt.bar(np.array([1])+2*w, [sum(y1[:r])/sum(ytMed[:r])],        w,label='Nobel Medicine',color='#FFC857',edgecolor = "none")
plt.bar(np.array([1])+w, [sum(y2[:r])/sum(ytChe[:r])],         w,label='Nobel Physics',color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1]), [sum(y3[:r])/sum(ytPhy[:r])],        w,label='Nobel Chemistry',color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+6*w, [sum(y4[:r])/sum(ytNSF1[:r])],        w,label='NSF < 0.2M',color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+7*w, [sum(y5[:r])/sum(ytNSF2[:r])],        w,label='0.2M <= NSF < 2M',color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+8*w, [sum(y6[:r])/sum(ytNSF3[:r])],        w,label='NSF >= 2M',edgecolor = "none",facecolor='SteelBlue',alpha=1)
plt.legend(loc='upper center',fontsize=12,ncol=2,frameon=False)
ax.set_xlim(0.8,0.9)
ax.set_ylim(0,2)
ax.set_yticks([0,0.5,1,1.5,2])
ax.set_xticks([1.35,2.3])
ax.plot([0,10],[1,1],'k--')

#

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')
ax.set_xticklabels('')
ax.set_yticklabels('')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.1.pdf')




# In[42]:

plt.plot(xn1,yn1)


# In[ ]:




# In[ ]:




# In[263]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
plt.plot(xn1_,yn1_,color='#FFC857',linewidth=2,label='Nobel Med')
plt.plot(xn2_,yn2_,color='#AA4466',linewidth=2,label='Nobel Phy')
plt.plot(xn3_,yn3_,color='#5A2A27',linewidth=2,label='Nobel Che')
plt.plot(xf1_,yf1_,color='#119DA4',linewidth=2,label='NSF < 0.5M')
plt.plot(xf2_,yf2_,color='#19647E',linewidth=2,label='0.5M < NSF <= 1M')
plt.plot(xf3_,yf3_,color='gray',linewidth=2,label='NSF >= 1M')
plt.xlim(-0.02,0.02)
#ax.set_xticks([-0.02,-0.01,0,0.01,0.02])
plt.plot([0,0],[0,1000],color='gray')
plt.plot([-1,1],[1,1],'k--')
plt.ylim(0.1,10)
plt.yscale('log')
#ax.set_yticks([0,1,2,3])
plt.legend(loc='upper center',fontsize=12,frameon=False,numpoints=1,ncol=2)


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')
#ax.set_xticklabels('')
#ax.set_yticklabels('')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[65]:

dn1=np.array([v[4] for v in W.values() if v[-1] in NJ[1]])
dn2=np.array([v[4] for v in W.values() if v[-1] in NJ[2]])
dn3=np.array([v[4] for v in W.values() if v[-1] in NJ[3]])
df1=np.array([v[4] for v in W.values() if v[-1] in GJ[1] and v[0]>=2008])
df2=np.array([v[4] for v in W.values() if v[-1] in GJ[2] and v[0]>=2008])
df3=np.array([v[4] for v in W.values() if v[-1] in GJ[3] and v[0]>=2008])
#
tn1=np.array([v[2] for v in W.values() if v[-1] in NJ[1]])
tn2=np.array([v[2] for v in W.values() if v[-1] in NJ[2]])
tn3=np.array([v[2] for v in W.values() if v[-1] in NJ[3]])
tf1=np.array([v[2] for v in W.values() if v[-1] in GJ[1] and v[0]>=2008])
tf2=np.array([v[2] for v in W.values() if v[-1] in GJ[2] and v[0]>=2008])
tf3=np.array([v[2] for v in W.values() if v[-1] in GJ[3] and v[0]>=2008])


# In[225]:

len(d1[(d1>0)&(t1<=3)])/float(len(d1))/(len(dn1[(dn1>0)&(tn1<=3)])/float(len(dn1)))


# In[158]:

len(d2[(d2>0)&(t2<=3)])/float(len(d2))/(len(dn2[(dn2>0)&(tn2<=3)])/float(len(dn2)))


# In[159]:

len(d3[(d3>0)&(t3<=3)])/float(len(d3))/(len(dn3[(dn3>0)&(tn3<=3)])/float(len(dn3)))


# In[219]:

len(d4[(d4>0)&(t4<=3)])/float(len(d4))/(len(df1[(df1>0)&(tf1<=3)])/float(len(df1)))


# In[220]:

len(d5[(d5>0)&(t5<=3)])/float(len(d5))/(len(df2[(df2>0)&(tf2<=3)])/float(len(df2)))


# In[221]:

len(d6[(d6>0)&(t6<=3)])/float(len(d6))/(len(df3[(df3>0)&(tf3<=3)])/float(len(df3)))


# In[ ]:




# In[189]:

len(d1[(d1<0)&(t1>3)])/float(len(d1))/(len(dn1[(dn1<0)&(tn1>3)])/float(len(dn1)))


# In[190]:

len(d2[(d2<0)&(t2>3)])/float(len(d2))/(len(dn2[(dn2<0)&(tn2>3)])/float(len(dn2)))


# In[191]:

len(d3[(d3<0)&(t3>3)])/float(len(d3))/(len(dn3[(dn3<0)&(tn3>3)])/float(len(dn3)))


# In[222]:

len(d4[(d4<0)&(t4>3)])/float(len(d4))/(len(df1[(df1<0)&(tf1>3)])/float(len(df1)))


# In[223]:

len(d5[(d5<0)&(t5>3)])/float(len(d5))/(len(df2[(df2<0)&(tf2>3)])/float(len(df2)))


# In[241]:

len(d6[(d6<0)&(t6>3)])/float(len(d6))/(len(df3[(df3<0)&(tf3>3)])/float(len(df3)))


# In[ ]:




# In[ ]:




# In[271]:

fig = plt.figure(figsize=(12,4)) 
ax = fig.add_subplot(133)
w = 1/8.0
r=3
plt.bar(np.array([1]), [3.28-1],         w,label='Nobel Physics',color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+w, [3.14-1],        w,label='Nobel Medicine',color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1])+2*w, [2.83-1],        w,label='Nobel Chemistry',color='#FFC857',edgecolor = "none")
plt.bar(np.array([1])+3*w, [0.67-1],        w,label='NSF < 1M',color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w, [0.65-1],        w,label='1M <= NSF < 5M',color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w, [0.51-1],        w,label='NSF >= 5M',edgecolor = "none",facecolor='SteelBlue',alpha=1)
#
xd=9*w
plt.bar(np.array([1])+xd, [0.45-1],         w,color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+w+xd, [0.37-1],        w,color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1])+2*w+xd, [0.43-1],        w,color='#FFC857',edgecolor = "none")
plt.bar(np.array([1])+3*w+xd, [0.95-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w+xd, [1.1-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w+xd, [1.18-1],        w,edgecolor = "none",facecolor='SteelBlue',alpha=1)



plt.legend(loc=1,fontsize=10,ncol=1,frameon=False)
ax.set_xlim(0.9,3)
ax.set_ylim(-1,3)
ax.set_yticks([-1,0,1,2,3])
ax.set_yticklabels([0,1,2,3,4])
ax.set_xticks([1.35,2.3])
ax.set_xticklabels(['Small Team, Disruptive','Large Team, Non-disruptive'],                   rotation=15,fontsize=14)
plt.ylabel('Ratio of Percentages',fontsize=14)
ax.plot([0,10],[0,0],'k--')
#
ax = fig.add_subplot(131)
plt.plot(range(1,11),y1[:10]/ytMed[:10],color='#FFC857',marker='.',linestyle='-',label='Nobel MED')
plt.plot(range(1,11),y2[:10]/ytPhy[:10],color='#C74F1B',marker='.',linestyle='-',label='Nobel PHY')
plt.plot(range(1,11),y3[:10]/ytChe[:10],color='#5A2A27',marker='.',linestyle='-',label='Nobel CHE')
plt.xlabel('Team size',fontsize=14)
plt.ylabel('Ratio of Percentages',fontsize=14)
plt.legend(loc=1,frameon=False,fontsize=10)
plt.plot([1,10],[1,1],'k-',alpha=0.3)
#
ax = fig.add_subplot(132)
plt.plot(range(1,11),y4[:10]/ytNSF1[:10],color='SteelBlue',alpha=0.3,marker='.',linestyle='-',label='NSF < 1M')
plt.plot(range(1,11),y5[:10]/ytNSF2[:10],color='SteelBlue',alpha=0.6,marker='.',linestyle='-',label='1M <= NSF < 5M')
plt.plot(range(1,11),y6[:10]/ytNSF3[:10],color='SteelBlue',alpha=1,marker='.',linestyle='-',label='NSF >= 5M')
plt.plot([1,10],[1,1],'k-',alpha=0.3)
plt.xlabel('Team size',fontsize=14)
plt.ylabel('Ratio of Percentages',fontsize=14)
plt.legend(loc=1,frameon=False,fontsize=10)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4new.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[ ]:




# In[378]:

#disruption distrtibution
N1,N2,N3,F1,F2,F3=map(cG,[d1,d2,d3,d4,d5,d6])
xn1,yn1=fre(N1)
xn2,yn2=fre(N2)
xn3,yn3=fre(N3)
xf1,yf1=fre(F1)
xf2,yf2=fre(F2)
xf3,yf3=fre(F3)

xdn1,ydn1=fre(cG(dn1))
xdn2,ydn2=fre(cG(dn2))
xdn3,ydn3=fre(cG(dn3))
xdf1,ydf1=fre(cG(df1))
xdf2,ydf2=fre(cG(df2))
xdf3,ydf3=fre(cG(df3))

dcn1=dict((i,j) for i,j in zip(xdn1,ydn1))
dcn2=dict((i,j) for i,j in zip(xdn2,ydn2))
dcn3=dict((i,j) for i,j in zip(xdn3,ydn3))
dcf1=dict((i,j) for i,j in zip(xdf1,ydf1))
dcf2=dict((i,j) for i,j in zip(xdf2,ydf2))
dcf3=dict((i,j) for i,j in zip(xdf3,ydf3))


# In[473]:



#-0.07 - 0.17   -> 1% - 99%
xn1_,yn1_=np.array([(i,j/dcn1[i]) for i,j in  zip(xn1,yn1) if i in dcn1 and -0.04<=i<=0.04]).T
xn2_,yn2_=np.array([(i,j/dcn2[i]) for i,j in  zip(xn2,yn2) if i in dcn2 and -0.04<=i<=0.04]).T
xn3_,yn3_=np.array([(i,j/dcn3[i]) for i,j in  zip(xn3,yn3) if i in dcn3 and -0.04<=i<=0.04]).T
xf1_,yf1_=np.array([(i,j/dcf1[i]) for i,j in  zip(xf1,yf1) if i in dcf1 and -0.04<=i<=0.04]).T
xf2_,yf2_=np.array([(i,j/dcf2[i]) for i,j in  zip(xf2,yf2) if i in dcf2 and -0.04<=i<=0.04]).T
xf3_,yf3_=np.array([(i,j/dcf3[i]) for i,j in  zip(xf3,yf3) if i in dcf3 and -0.04<=i<=0.04]).T


# In[44]:

def polyfit(x,y):
    order=2
    xs=np.linspace(0,100,100)
    z = np.polyfit(x,y, order)
    p = np.poly1d(z)
    return [p(i) for i in xs]

def groupMean(x,y):
    d=defaultdict(lambda:[])
    x=[np.round(i/10.0,0) for i in x]
    for a,b in zip(x,y):
        d[a].append(b)
    x1,y1=np.array(sorted([(k,np.mean(v)) for k,v in d.items()])).T
    return x1*10,y1

def cG(data):
    return [np.round(i,3) for i in data]

def fre(data):
    x,y=np.array(sorted(Counter(data).items())).T
    y=y/float(y.sum())
    return x,y


# In[475]:

xn1_p=[stats.percentileofscore(drss, i) for i in xn1_]
xn2_p=[stats.percentileofscore(drss, i) for i in xn2_]
xn3_p=[stats.percentileofscore(drss, i) for i in xn3_]
xf1_p=[stats.percentileofscore(drss, i) for i in xf1_]
xf2_p=[stats.percentileofscore(drss, i) for i in xf2_]
xf3_p=[stats.percentileofscore(drss, i) for i in xf3_]

xn1_q,yn1_q=groupMean(xn1_p,yn1_)
xn2_q,yn2_q=groupMean(xn2_p,yn2_)
xn3_q,yn3_q=groupMean(xn3_p,yn3_)
xf1_q,yf1_q=groupMean(xf1_p,yf1_)
xf2_q,yf2_q=groupMean(xf2_p,yf2_)
xf3_q,yf3_q=groupMean(xf3_p,yf3_)


#yn1_p=polyfit(xn1_q,np.log(yn1_q))
#yn2_p=polyfit(xn2_q,np.log(yn2_q))
#yn3_p=polyfit(xn3_q,np.log(yn3_q))
#yf1_p=polyfit(xf1_q,yf1_q)
#yf2_p=polyfit(xf2_p,yf2_)
#yf3_p=polyfit(xf3_p,yf3_)


# In[ ]:




# In[ ]:




# In[540]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
xs=np.linspace(0,100,100)
plt.plot(xn1_q,yn1_q,color='#FFC857',marker='',linestyle='-',linewidth=2,label='Med')
plt.plot(xn2_q,yn2_q,color='#C74F1B',marker='',linestyle='-',linewidth=2,label='Phy')
plt.plot(xn3_q,yn3_q,color='#5A2A27',marker='',linestyle='-',linewidth=2,label='Che')
plt.plot(xf1_q,yf1_q,color='SteelBlue',alpha=0.3,marker='',linestyle='-',linewidth=2,label='< ')
plt.plot(xf2_q,yf2_q,color='SteelBlue',alpha=0.6,marker='',linestyle='-',linewidth=2,label='-')
plt.plot(xf3_q,yf3_q,color='SteelBlue',alpha=1,marker='',linestyle='-',linewidth=2,label='>= ')
#plt.plot(xs,np.exp(yn1_p),color='#FFC857',label='Nobel Med')
#plt.plot(xs,np.exp(yn2_p),color='#AA4466',label='Nobel Phy')
#plt.plot(xs,np.exp(yn3_p),color='#5A2A27',label='Nobel Che')
#plt.plot(xs,yf1_p,color='#119DA4',label='NSF < 0.2M')
#plt.plot(xs,yf2_p,color='#19647E',label='0.2M < NSF <= 2M')
#plt.plot(xs,yf3_p,color='gray',label='NSF >= 2M')
#plt.plot(xs,yf3_pp,'r-')
plt.xlim(0,100)
#ax.set_xticks([-0.02,-0.01,0,0.01,0.02])
#plt.plot([70,70],[-1,10],color='gray')
plt.plot([0,100],[1,1],color='gray')
plt.plot([70,70],[0,2],color='gray',linestyle='--')
plt.ylim(0,2)
#plt.yscale('log')
#ax.set_yticks([0,1,2,3])
plt.legend(loc='upper center',fontsize=10,frameon=False,numpoints=1,ncol=2)


[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')
#ax.set_xticklabels('')
#ax.set_yticklabels('')

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[234]:

np.percentile(drss,5),np.percentile(drss,95)


# In[110]:




# # General  founding acknowledgements

# In[167]:

'''
F={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/grant1900_2015.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if len(line)==3:
            ndoi,fname,fnumber=line
            ndoi=int(ndoi)
            if ndoi in W1:
                if ndoi not in F:
                    F[ndoi]=[]
                F[ndoi].append(fname+' ' +fnumber)
F,NF,W1 = (3539814, 20634133, 24173947)
'''


# In[25]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(subject),int(teamsize),int(impact),float(disruptive),int(journal)]


# In[5]:

#1.year
Y={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/allpaperID.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        doi,ndoi,year=line.strip().split('\t')
        #if int(year)>=1954:
        Y[int(ndoi)]=int(year)


# In[31]:

G=defaultdict(lambda:defaultdict(lambda:0))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/grant1900_2015.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if len(line)==3:
            ndoi,fname,fnumber=line
            ndoi=int(ndoi)
            G[Y[ndoi]][ndoi]+=1


# In[39]:

sum(map(len,G.values()))


# In[40]:

len(Y)


# In[41]:

4754769/43661387.0


# In[37]:

x,y=np.array(sorted([(k,len(v)) for k,v in G.items()])).T
plt.plot(x,y,'bo-')
plt.xlim(2006,2014)


# In[18]:

cc=Counter(Y.values())


# In[42]:

x,y=np.array(sorted([(k,100*len(v)/float(cc[k])) for k,v in G.items()])).T


# In[44]:

#x,y=np.array(sorted(N.items())).T
plt.plot(x,y,'bo-')
plt.xlim(2006,2014)


# In[45]:

zip(x,y)


# In[55]:

np.mean(zip(*zip(x,y)[:56])[1])


# In[ ]:




# In[7]:

N


# In[74]:

startYear=2004
endYear=2014
# new articles
F={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/grant1900_2015.txt','r') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        line=line.strip().split('\t')
        if len(line)==3:
            ndoi,fname,fnumber=line
            ndoi=int(ndoi)
            if ndoi in W1 and startYear<=W1[ndoi][0]<=endYear:
            #if ndoi in W1:
                if ndoi not in F:
                    F[ndoi]=[]
                F[ndoi].append(fname+' ' +fnumber)


# In[ ]:




# In[ ]:




# In[ ]:




# In[32]:

W2=set([i for i in W1 if startYear<=W1[i][0]<=endYear])
NF=set([i for i in W2 if i not in F])
len(F),len(NF),len(W2),len(F)/float(len(W2))


# In[33]:

len(F)+len(NF)


# In[153]:

Disruptive=[v[-2] for v in W1.values()]


# In[156]:

drss=random.sample(Disruptive,10000)
stats.percentileofscore(drss, 0)


# In[31]:

nm=np.mean([W1[i][-2] for i in W2])
nm,stats.percentileofscore(drss, nm)


# ## subsets

# In[34]:

US=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'nsf ' in j and 'china' not in j:
            US.add(i)
            break
        if 'national science foundation' in j and 'china' not in j         and 'swiss' not in j and 'dutch' not in j:
            US.add(i)
            break


# In[50]:




# In[35]:

len(US)


# In[75]:

US=set([])
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if Id in W1 and startYear<=W1[Id][0]<=endYear:
            US.add(Id)

CN=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'nsfc' in j:
            CN.add(i)
            break
        if 'national science foundation' in j and 'china' in j:
            CN.add(i)
            break

EU=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'european research council' in j:
            EU.add(i)
            break
        if ' erc' in j:
            EU.add(i)
            break   
        if ' fpa' in j:
            EU.add(i)
            break 
        if 'european commission' in j:
            EU.add(i)
            break  
        if 'european community' in j:
            EU.add(i)
            break   

JP=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'jsps' in j:
            JP.add(i)
            break
        if 'japan society for the promotion of science' in j:
            JP.add(i)
            break

DE=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'dfg' in j:
            DE.add(i)
            break
        if 'german research foundation' in j:
            DE.add(i)
            break


# In[358]:

'''
NIH=set([])
for i in F:
    for j in F[i]:
        j=j.lower()
        if 'nih' in j:
            NIH.add(i)
            break
        if 'national institutes of health' in j:
            NIH.add(i)
            break
'''


# In[56]:

wb1 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physiology or Medicine.xlsx', read_only=True)
wb2 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Physics.xlsx', read_only=True)
wb3 = load_workbook(filename = '/Users/lingfeiw/Documents/research/teamscience/nobel/Chemistry.xlsx', read_only=True)

def GetIDs(wb):
    sheet = wb.get_sheet_by_name(wb.get_sheet_names()[0])
    data=[]
    sheet = wb.get_sheet_by_name('Sheet1')
    for row in sheet.iter_rows():
        data_row = []
        for cell in row:
            data_row += [cell.value]
        data += [data_row]
    d=set([])
    #j=set([])
    for i in data[1:]:
        a=str(i[-1])
        if a in WOS and WOS[a] in W:
            #year,subject,ts,imp,dis,jour=W[WOS[a]]
            #d[WOS[a]] = year,ts,imp,dis
            #if jour not in j:
                #j.add(jour)
            d.add(WOS[a])
    return list(d)


# In[57]:

N1=GetIDs(wb1)
N2=GetIDs(wb2)
N3=GetIDs(wb3)
NP=N1+N2+N3
len(NP),len(N1),len(N2),len(N3)


# In[67]:

np.mean([W[i][-2] for i in NP if i in W])


# In[ ]:




# In[ ]:




# In[150]:

# nobel prize
NY=set(W[i][0] for i in NP if i in W) #nobel years
NYJ=set(W[i][-1] for i in NP if i in W)
NNP=[i for i in W if W[i][0] in NY and W[i][-1] in NYJ]


# In[151]:

len(NP),len(NNP),len(NYJ)


# In[152]:

np.mean([W1[i][-2] for i in NNP if  i in W1])


# In[157]:

stats.percentileofscore(drss, -0.0002787191900539369)


# In[98]:

len([i for i in NNP if W1[i][-2]>-0.00052984782675709785 and W1[i][2]<=3 ])/float(len(NNP)),len([i for i in NNP if W1[i][-2]<-0.00052984782675709785 and W1[i][2]>3 ])/float(len(NNP))


# In[99]:

len([i for i in N1 if W1[i][-2]>-0.00052984782675709785 and W1[i][2]<=3 ])/float(len(N1))/0.248,len([i for i in N1 if W1[i][-2]<-0.00052984782675709785 and W1[i][2]>3 ])/float(len(N1))/0.24296


# In[100]:

len([i for i in N2 if W1[i][-2]>-0.00052984782675709785 and W1[i][2]<=3 ])/float(len(N2))/0.248,len([i for i in N2 if W1[i][-2]<-0.00052984782675709785 and W1[i][2]>3 ])/float(len(N2))/0.24296


# In[101]:

len([i for i in N3 if W1[i][-2]>-0.00052984782675709785 and W1[i][2]<=3 ])/float(len(N3))/0.248,len([i for i in N3 if W1[i][-2]<-0.00052984782675709785 and W1[i][2]>3 ])/float(len(N3))/0.24296


# In[138]:

#1=生理学或医学，2=物理，3=化学
fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
w = 1/8.0
r=3
plt.bar(np.array([1]), [1.56-1],         w,label='Nobel Physics',color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+w, [1.98-1],        w,label='Nobel Medicine',color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1])+2*w, [1.61-1],        w,label='Nobel Chemistry',color='#FFC857',edgecolor = "none")
#
xd=9*w
plt.bar(np.array([1])+xd, [0.78-1],         w,color='#5A2A27',edgecolor = "none")
plt.bar(np.array([1])+w+xd, [0.57-1],        w,color='#C74F1B',edgecolor = "none")
plt.bar(np.array([1])+2*w+xd, [0.57-1],        w,color='#FFC857',edgecolor = "none")


plt.legend(loc=1,fontsize=10,ncol=1,frameon=False)
ax.set_xlim(0.9,3)
ax.set_ylim(-.5,1)
ax.set_yticks([-0.5,0,0.5,1])
ax.set_yticklabels([0.5,1,1.5,2])
#ax.set_xticks([1.35,2.3])
#plt.ylabel('Ratio of Percentages',fontsize=14)
ax.plot([0,10],[0,0],'k--')


plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.3.pdf')


# In[ ]:




# In[ ]:




# In[ ]:




# In[25]:

len(NNP)


# In[160]:

len(NP),len(NNP)


# In[161]:

def tdss(ids):
    a,b=zip(*[(W[k][2],W[k][-2]) for k in ids if k in W])
    x_,y_,z_=ave(a,b)
    ny_=[stats.percentileofscore(drss, i) for i in y_]
    return x_,ny_,z_

a7_,b7_,c7_=tdss(NNP)# not bel 
a8_,b8_,c8_=tdss(NP)# nobel


# In[164]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a7_,b7_,'k--',label='non Nobel')
plt.plot([1,10],[59,59],'k-')
plt.plot(a8_,b8_,color=cmap(0),label='Nobel',linewidth=2)
#
plt.ylim(20,100)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/nobell.pdf')


# In[81]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a7_,b7_,'k--',label='non Nobel')
plt.scatter(a7_,b7_,edgecolor='gray',facecolor='none',s=c7_*3000)
#
plt.xlim(0.3,10.5)
plt.xticks(range(2,12,2))
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/nobel2.pdf')


# In[82]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a1_,b1_,'k--',label='unfunded')
plt.scatter(a1_,b1_,edgecolor='gray',facecolor='none',s=c1_*3000)
#
plt.xlim(0.3,10.5)
plt.xticks(range(2,12,2))
plt.ylim(20,50)
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/nsf.pdf')


# In[92]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
#
plt.scatter(x4_,ny4_,color='SteelBlue',s=z4_*3000,alpha=0.3,label='NSF < 1M')
plt.plot(x4_,ny4_,color='SteelBlue',alpha=0.3)
plt.scatter(x5_,ny5_,color='SteelBlue',s=z5_*3000,alpha=0.6,label='1M <= NSF < 5M')
plt.plot(x5_,ny5_,color='SteelBlue',alpha=0.6)
plt.scatter(x6_,ny6_,color='SteelBlue',s=z6_*3000,label='NSF >= 5M')
plt.plot(x6_,ny6_,color='SteelBlue',alpha=1)
#
plt.plot(a1_,b1_,'k--',label='unfunded')
plt.scatter(a1_,b1_,edgecolor='gray',facecolor='none',s=c1_*3000)
#
plt.xlim(0.3,10.5)
plt.xticks(range(2,12,2))
plt.ylim(25,45)



plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[89]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)

plt.plot(a7_,b7_,'k--',label='non Nobel')
plt.scatter(a7_,b7_,edgecolor='gray',facecolor='none',s=c7_*3000)
plt.scatter(x1_,ny1_,color='#FFC857',s=z1_*3000,label='Nobel MED')
plt.scatter(x2_,ny2_,color='#C74F1B',s=z2_*3000,label='Nobel PHY')
plt.scatter(x3_,ny3_,color='#5A2A27',s=z2_*3000,label='Nobel CHE')
#
#
#plt.plot([0,11],[70,70],color='gray',alpha=0.5)
#plt.plot([3,3],[0,110],color='gray',alpha=0.5)
plt.xlim(0.3,10.5)
plt.xticks(range(2,12,2))
plt.ylim(0,110)


plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[ ]:




# In[ ]:

def ave(ts,ds):
    A=defaultdict(lambda:[])
    for m,d in zip(ts,ds):
        if 1<=m<=10:
            A[m].append(d)
    x,y,z=np.array(sorted([(k,np.mean(v),len(v)/float(len(ts))) for k,v in A.items()])).T
    return x,y,z


# In[27]:

def tds(ids):
    a,b=zip(*[(W1[k][2],W1[k][-2]) for k in ids if k in W1])
    x_,y_,z_=ave(a,b)
    ny_=[stats.percentileofscore(drss, i) for i in y_]
    return x_,ny_,z_


# In[77]:

len(allF)


# In[78]:

Disruptive=[v[-2] for v in W.values() if 2004<=v[0]<=2014]
stats.percentileofscore(Disruptive, 0)


# In[79]:

np.mean([W[i][-2] for i in allF])


# In[81]:

np.mean([W[i][-2] for i in US])


# In[80]:

stats.percentileofscore(Disruptive, -0.0024111207533317526)


# In[82]:

stats.percentileofscore(Disruptive, -0.0026051883399595718)


# In[76]:

allF=set.union(*[US,CN,DE,JP,EU])
F_journals=set(W1[i][-1] for i in allF)
NF_matchF=set([i for i in NF if W1[i][-1] in F_journals and 2004<=W1[i][0]<=2014])
len(US),len(CN),len(EU),len(DE),len(JP),len(allF),len(NF_matchF)


# In[140]:

F_journals1=set(W1[i][-1] for i in G1+G2+G3)
NF_matchF1=set([i for i in NF if W1[i][-1] in F_journals1 and 2008<=W1[i][0]<=2014])
len(F_journals1),len(NF_matchF1)


# In[123]:

np.mean([W1[i][-2] for i in list(NF_matchF)+list(allF) if  i in W1])


# In[141]:

np.mean([W1[i][-2] for i in list(NF_matchF1) if  i in W1])


# In[126]:

gt=defaultdict(lambda:[0,0])# n of grants, total size
with open('/Users/lingfeiw/Documents/research/teamscience/nsf/NSF.txt','r') as f:
    for line in f:
        Id,grantNo,grantSize=map(int,line.strip().split('\t'))
        if grantSize>=10**5:
            gt[Id][0]+=1
            gt[Id][1]+=grantSize

G1=[]
G2=[]
G3=[]
for k,v in gt.items():
    if k in W:
        year,subject,teamsize,impact,disruptive,journal=W[k]
        if year>=2008:
            grantsize=v[1]/v[0]
            if grantsize<10**6:
                gs=1
                G1.append(k)
            if 10**6<=grantsize<=5*10**6:
                gs=2
                G2.append(k)
            if 5*10**6<=grantsize:
                gs=3
                G3.append(k)


# In[142]:

len([i for i in NF_matchF if W1[i][-2]>-0.0021303750034879611 and W1[i][2]<=3 ])/float(len(NF_matchF)),len([i for i in NF_matchF if W1[i][-2]<-0.0021303750034879611 and W1[i][2]>3 ])/float(len(NF_matchF))


# In[130]:

len(G1),len(G2),len(G3),len(G1+G2+G3)


# In[143]:

len([i for i in G1 if W1[i][-2]>-0.0021303750034879611 and W1[i][2]<=3 ])/float(len(G1))/0.284,len([i for i in G1 if W1[i][-2]<-0.0021303750034879611 and W1[i][2]>3 ])/float(len(G1))/0.2072


# In[144]:

len([i for i in G2 if W1[i][-2]>-0.0021303750034879611 and W1[i][2]<=3 ])/float(len(G2))/0.284,len([i for i in G2 if W1[i][-2]<-0.0021303750034879611 and W1[i][2]>3 ])/float(len(G2))/0.2072


# In[145]:

len([i for i in G3 if W1[i][-2]>-0.0021303750034879611 and W1[i][2]<=3 ])/float(len(G3))/0.284,len([i for i in G3 if W1[i][-2]<-0.0021303750034879611 and W1[i][2]>3 ])/float(len(G3))/0.2072


# In[139]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
w = 1/8.0
r=3
plt.bar(np.array([1])+3*w, [0.93-1],        w,label='NSF < 1M',color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w, [0.79-1],        w,label='1M <= NSF < 5M',color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w, [0.72-1],        w,label='NSF >= 5M',edgecolor = "none",facecolor='SteelBlue',alpha=1)
#
xd=9*w

plt.bar(np.array([1])+3*w+xd, [0.86-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.3)
plt.bar(np.array([1])+4*w+xd, [0.98-1],        w,color='SteelBlue',edgecolor = "none",alpha=0.6 )
plt.bar(np.array([1])+5*w+xd, [1.09-1],        w,edgecolor = "none",facecolor='SteelBlue',alpha=1)

#plt.legend(loc=1,fontsize=10,ncol=1,frameon=False)
ax.set_xlim(0.9,3)
ax.set_ylim(-1,0.5)
ax.set_yticks([-1,-0.5,0,0.5])
ax.set_yticklabels([0,.5,1,1.5])
#ax.set_xticks([1.35,2.3])
#plt.ylabel('Ratio of Percentages',fontsize=14)
ax.plot([0,10],[0,0],'k--')


plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.3.pdf')
#plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/nsf1.pdf')


# In[ ]:




# In[120]:

len(F_journals)


# In[117]:

set([W1[i][0] for i in allF])


# In[47]:

a0_,b0_,c0_=tds(W2)#all 
a1_,b1_,c1_=tds(NF_matchF)# not founded
a2_,b2_,c2_=tds(US)
a3_,b3_,c3_=tds(CN)
a4_,b4_,c4_=tds(DE)
a5_,b5_,c5_=tds(JP)
a6_,b6_,c6_=tds(EU)
#
'''
ids=W2
x0_,y0_,z0_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
ids=F
x1_,y1_,z1_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
ids=NF
x2_,y2_,z2_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
ids=NSF
x3_,y3_,z3_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
ids=NIH
x4_,y4_,z4_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
ids=NSFC
x5_,y5_,z5_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
ids=ERC
x6_,y6_,z6_=ave([W1[k][2] for k in ids if k in W1],[W1[k][-3] for k in ids if k in W1])
'''


# In[48]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a1_,b1_,'k--',label='unfunded')
plt.plot([1,10],[37.4,37.4],'k-')
plt.plot(a2_,b2_,color=cmap(0),label='NSF',linewidth=2)
plt.plot(a3_,b3_,color=cmap(4),label='NSFC',linewidth=2)
plt.plot(a4_,b4_,color=cmap(2),label='JSPS',linewidth=2)
plt.plot(a5_,b5_,color=cmap(1),label='GRF',linewidth=2)
plt.plot(a6_,b6_,color=cmap(3),label='ERC & EC',linewidth=2)
plt.xlim(1,10)
plt.xticks(range(2,12,2))
plt.ylim(20,50)
plt.legend(loc=1,fontsize=10)

#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')
#
plt.tight_layout()


# In[23]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a1_,b1_,'k--',label='unfunded')
plt.plot([1,10],[37.4,37.4],'k-')
plt.plot(a2_,b2_,color=cmap(0),label='NSF',linewidth=2)
plt.plot(a3_,b3_,color=cmap(4),label='NSFC',linewidth=2)
plt.plot(a4_,b4_,color=cmap(2),label='JSPS',linewidth=2)
plt.plot(a5_,b5_,color=cmap(1),label='GRF',linewidth=2)
plt.plot(a6_,b6_,color=cmap(3),label='ERC & EC',linewidth=2)
plt.xlim(1,10)
plt.xticks(range(2,12,2))
plt.ylim(20,50)
plt.legend(loc=1,fontsize=10)

#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')
#
plt.tight_layout()


# In[85]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a1_,b1_,'k--',label='unfunded')
plt.plot([1,10],[39.5,39.5],'k-')
plt.plot(a2_,b2_,color=cmap(0),label='NSF',linewidth=2)
plt.plot(a3_,b3_,color=cmap(4),label='NSFC',linewidth=2)
plt.plot(a4_,b4_,color=cmap(2),label='JSPS',linewidth=2)
plt.plot(a5_,b5_,color=cmap(1),label='GRF',linewidth=2)
plt.plot(a6_,b6_,color=cmap(3),label='ERC & EC',linewidth=2)


plt.xlim(1,10)
plt.xticks(range(2,12,2))
plt.ylim(20,50)
plt.legend(loc=1,fontsize=10)

#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')
#
plt.tight_layout()


# In[ ]:




# In[ ]:




# In[121]:

cmap = cm.get_cmap('rainbow',5)
fig = plt.figure(figsize=(10, 5),facecolor='white')

#
ax = fig.add_subplot(121)
plt.plot(a1_,b1_,'k--',label='unfunded')
plt.plot(a2_,b2_,color=cmap(0),label='NSF',linewidth=2)
plt.plot(a3_,b3_,color=cmap(4),label='NSFC',linewidth=2)
plt.plot(a4_,b4_,color=cmap(2),label='JSPS',linewidth=2)
plt.plot(a5_,b5_,color=cmap(1),label='GRF',linewidth=2)
plt.plot(a6_,b6_,color=cmap(3),label='ERC & EC',linewidth=2)
plt.xlim(1,10)
plt.xticks(range(2,12,2))
plt.ylim(20,50)
plt.legend(loc=1,fontsize=12,frameon=False)

[i.set_linewidth(0.4) for i in ax.spines.itervalues()]
ax.tick_params('both', length=4, which='major')
ax.tick_params(axis='x', which='both',bottom='on',top='off')
ax.tick_params(axis='y', which='both',left='on',right='off')
ax.set_xticklabels('')
ax.set_yticklabels('')

plt.tight_layout()
plt.savefig('/Users/lingfeiw/Documents/research/teamscience/figures4/grant.pdf')


# In[ ]:




# In[ ]:




# In[57]:

fig = plt.figure(figsize=(5,5)) 
ax = fig.add_subplot(111)
#plt.plot(x0_,ny0_,'k--')
#plt.scatter(x0_,ny0_,edgecolor='gray',facecolor='none',s=z0_*3000,label='Population')
#
plt.scatter(x4_,ny4_,color='SteelBlue',s=z4_*3000,alpha=0.3,label='NSF < 1M')
plt.plot(x4_,ny4_)
plt.scatter(x5_,ny5_,color='SteelBlue',s=z5_*3000,alpha=0.6,label='1M <= NSF < 5M')
plt.plot(x5_,ny5_)
plt.scatter(x6_,ny6_,color='SteelBlue',s=z6_*3000,label='NSF >= 5M')
plt.plot(x6_,ny6_)
#
plt.xlim(0.3,10.5)
plt.xticks(range(2,12,2))
plt.ylim(20,50)

plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Documents/research/teamscience/finalfinalFigures/Fig4.2.pdf')


# In[ ]:



