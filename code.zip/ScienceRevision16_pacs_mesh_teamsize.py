
# coding: utf-8

# In[2]:

get_ipython().magic(u'matplotlib inline')
import sys
from collections import defaultdict, Counter
from mpl_toolkits.axes_grid1 import host_subplot
import networkx as nx
import numpy as np
import pylab as plt
import math
#import matplotlib.cm as cm
import statsmodels.api as sm
from os import listdir
from scipy.stats.stats import pearsonr
import json
import random
import itertools
from copy import deepcopy
import time
import scipy as sp
from scipy.sparse import csr_matrix
import matplotlib.cm as cm
from numpy.random import choice
import itertools
from sklearn import manifold
import operator
import itertools
from datetime import datetime as dt
import matplotlib.mlab as mlab
from scipy.stats import norm
from scipy import stats

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
from sklearn.manifold import TSNE

import gensim
import os
import collections
import smart_open
import random

# flush print
def flushPrint(d):
    sys.stdout.write('\r')
    sys.stdout.write('%d' % d)
    sys.stdout.flush()


# # 1. PACS vs teamsize

# In[3]:

P=defaultdict(lambda:[])
M={}
n=0
with open('/Users/lingfeiw/Documents/research/cultureContraction/data/meta.txt','rb') as f:
    for line in f:
        n+=1
        try:
            line=line.strip().split('\t')
            year=int(line[0])
            pacs=line[2]
            m=len(line[3].split('$$$'))
            if 1990<=year<2010 and m>0:
                P[year].append([m,pacs.split('__')])
        except:
            pass


# In[5]:

sum(map(len,P.values()))


# In[22]:

#A=defaultdict(lambda:[])
#B=defaultdict(lambda:[])
C=defaultdict(lambda:[])

for y in range(1990,2010):
    flushPrint(y)
    S=[i[1] for i in P[y]]
    N=Counter([j for i in S for j in i])
    E=defaultdict(lambda:0)
    for v in S:
        if len(v)>=2:
            for i,j in itertools.combinations(sorted(v), 2):
                E[(i,j)]+=1
    EP={}
    for k in E:
        wij=E[k]
        i,j=k
        wi=N[i]
        wj=N[j]
        EP[(i,j)]=wij/(wi+wj+0.0)
    for m,v in P[y]:
        if len(v)>=2:
            ps=[EP[(i,j)] for i,j in itertools.combinations(sorted(v), 2)]
            #A[m].append(np.mean(ps))
            #B[m].append(np.median(ps))
            C[m].append(np.min(ps))
#A1=defaultdict(lambda:[])
#B1=defaultdict(lambda:[])
C1=defaultdict(lambda:[])

for y in range(1990,2010):
    flushPrint(y)
    S=[i[1] for i in P[y]]
    N=Counter([j for i in S for j in i])
    E=defaultdict(lambda:0)
    for v in S:
        if len(v)>=3:
            for i,j,l in itertools.combinations(sorted(v), 3):
                E[(i,j,l)]+=1
    EP={}
    for k in E:
        wijl=E[k]
        i,j,l=k
        wi=N[i]
        wj=N[j]
        wl=N[l]
        EP[(i,j,l)]=wijl/(wi+wj+wl+0.0)
    for m,v in P[y]:
        if len(v)>=3:
            ps=[EP[(i,j,l)] for i,j,l in itertools.combinations(sorted(v), 3)]
            #A1[m].append(np.mean(ps))
            #B1[m].append(np.median(ps))
            C1[m].append(np.min(ps))


# In[23]:

x3,y3=np.array(sorted([(k,np.mean(v)) for k,v in C.items()])).T
x6,y6=np.array(sorted([(k,np.mean(v)) for k,v in C1.items()])).T
Y3=np.random.choice([j for k in C for j in C[k]],10000)
y3_=np.array([stats.percentileofscore(Y3,i) for i in y3])
Y6=np.random.choice([j for k in C1 for j in C1[k]],10000)
y6_=np.array([stats.percentileofscore(Y6,i) for i in y6])


# In[25]:

fig = plt.figure(figsize=(10, 4))
#
ax = fig.add_subplot(121)
plt.plot(x3,100-y3_,color='RoyalBlue',label='Min')
#plt.plot(x1,y1,color='r',label='Mean')
#plt.plot(x2,y2,color='Orange',label='Median')
plt.xlim(1,50)
#plt.ylim(0.02,0.15)
plt.xlabel('Team size',size=14)
plt.ylabel('Jaccard Novelty',size=14)
plt.legend(numpoints=1)
plt.title('2-way PACS term combinations',size=16)
#
ax = fig.add_subplot(122)
plt.plot(x6,100-y6_,color='RoyalBlue',label='Min')
#plt.plot(x4,y4,color='r',label='Mean')
#plt.plot(x5,y5,color='Orange',label='Median')
plt.xlim(1,50)
#plt.ylim(0.01,0.04)
plt.xlabel('Team size',size=14)
plt.ylabel('Jaccard Novelty',size=14)
plt.legend(numpoints=1)
plt.title('3-way PACS term combinations',size=16)
#
plt.tight_layout()
#plt.savefig('/Users/lingfeiw/Dropbox/Poetics/pics/socialNetwork.pdf')


# # 2. MESH vs teamsize

# In[194]:

'''
Y={}
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmid2year.txt','rb') as f:
    for line in f:
        idx,year=map(int,line.strip().split(' '))
        Y[idx]=year
I=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmid2chemical.txt','rb') as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        pid,j=map(int,line.strip().split(' '))
        I[pid].append('c'+str(j))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmid2disease.txt','rb') as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        pid,j=map(int,line.strip().split(' '))
        I[pid].append('d'+str(j))
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmid2method.txt','rb') as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        pid,j=map(int,line.strip().split(' '))
        I[pid].append('m'+str(j))
M=defaultdict(lambda:[])
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmid2author.txt','rb') as f:
    for line in f:
        n+=1
        if n%1000000==0:
            flushPrint(n/1000000)
        pid,j=map(int,line.strip().split(' '))
        M[pid].append(j)
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmidMESH.txt','wb') as f:
    for i in I:
        if i in Y and i in M:
            y=str(Y[i])
            m=str(len(M[i]))
            v=I[i]
            s=[str(i)]+[y]+[m]+v
            f.write('\t'.join(s)+'\n')
'''


# In[6]:

Pp=defaultdict(lambda:[])
with open('/Users/lingfeiw/Documents/research/teamscience/team/pubmed/pmidMESH.txt','r') as f:
    for line in f:
        line=line.strip().split('\t')
        idx=line[0]
        year=int(line[1])
        m=int(line[2])
        tags=line[3:]
        if 1990<=year<2010:
            Pp[year].append([m,tags])


# In[7]:

sum(map(len,Pp.values()))


# In[17]:


Ap=defaultdict(lambda:[])
#Bp=defaultdict(lambda:[])
Cp=defaultdict(lambda:[])

for y in range(1990,2010):
    flushPrint(y)
    S=[i[1] for i in Pp[y]]
    N=Counter([j for i in S for j in i])
    E=defaultdict(lambda:0)
    for v in S:
        if len(v)>=2:
            for i,j in itertools.combinations(sorted(v), 2):
                E[(i,j)]+=1
    EP={}
    for k in E:
        wij=E[k]
        i,j=k
        wi=N[i]
        wj=N[j]
        EP[(i,j)]=wij/(wi+wj+0.0)
    for m,v in Pp[y]:
        if len(v)>=2:
            ps=[EP[(i,j)] for i,j in itertools.combinations(sorted(v), 2)]
            Ap[m].append(np.max(ps))
            #Bp[m].append(np.median(ps))
            #Cp[m].append(np.percentile(ps,10))
            Cp[m].append(np.min(ps))
            
A1p=defaultdict(lambda:[])
#B1p=defaultdict(lambda:[])
C1p=defaultdict(lambda:[])

for y in range(1990,2010):
    flushPrint(y)
    S=[i[1] for i in Pp[y]]
    N=Counter([j for i in S for j in i])
    E=defaultdict(lambda:0)
    for v in S:
        if len(v)>=3:
            for i,j,l in itertools.combinations(sorted(v), 3):
                E[(i,j,l)]+=1
    EP={}
    for k in E:
        wijl=E[k]
        i,j,l=k
        wi=N[i]
        wj=N[j]
        wl=N[l]
        EP[(i,j,l)]=wijl/(wi+wj+wl+0.0)
    for m,v in Pp[y]:
        if len(v)>=3:
            ps=[EP[(i,j,l)] for i,j,l in itertools.combinations(sorted(v), 3)]
            A1p[m].append(np.max(ps))
            #B1p[m].append(np.median(ps))
            C1p[m].append(np.min(ps))


# In[18]:

x3p,y3p=np.array(sorted([(k,np.mean(v)) for k,v in Cp.items()])).T
x6p,y6p=np.array(sorted([(k,np.mean(v)) for k,v in C1p.items()])).T
Y3p=np.random.choice([j for k in Cp for j in Cp[k]],10000)
y3p_=np.array([stats.percentileofscore(Y3p,i) for i in y3p])
Y6p=np.random.choice([j for k in C1p for j in C1p[k]],10000)
y6p_=np.array([stats.percentileofscore(Y6p,i) for i in y6p])


# In[33]:

fig = plt.figure(figsize=(10, 4))
#
ax = fig.add_subplot(121)
plt.plot(x3p,100-y3p_,color='RoyalBlue',label='Max')
plt.xlim(1,50)
#plt.ylim(0.,0.04)
plt.xlabel('Team size',size=14)
plt.ylabel('Jaccard index',size=14)
plt.legend(numpoints=1)
plt.title('2-way MESH term combinations',size=16)
#
ax = fig.add_subplot(122)
plt.plot(x6p,100-y6p_,color='RoyalBlue',label='Max')
plt.xlim(1,50)
#plt.ylim(0.,0.04)
plt.xlabel('Team size',size=14)
plt.ylabel('Jaccard index',size=14)
plt.legend(numpoints=1)
plt.title('3-way MESH term combinations',size=16)
#
plt.tight_layout()


# In[34]:

# papers
W1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/WOSPaperAllStatistics.txt','rb') as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        Id,year,journal,subject,teamsize,impact,disruptive,timegap,meanimp,ten,median=line.strip().split('\t')
        if int(teamsize) > 0 and int(impact)>0 and int(year)>=1954:
            W1[int(Id)]=[int(year),int(teamsize)]
Z1={}
n=0
with open('/Users/lingfeiw/Documents/research/teamscience/team/paperNovelty1901_2014.txt', "rb") as f:
    for line in f:
        n+=1
        if n%100000==0:
            flushPrint(n/100000)
        paper,novelty = line.strip().split('\t')
        Z1[int(paper)]=float(novelty)


# In[35]:

Bread=np.random.choice(Z1.values(),10000)
bre=defaultdict(lambda:[])
for i in W1:
    if i in Z1:
        year, teamsize=W1[i]
        bre[teamsize].append(Z1[i])
xbre,ybre=np.array(sorted([(k,np.mean(v)) for k,v in bre.items()])).T
ybre_=[stats.percentileofscore(Bread,i) for i in ybre]


# In[36]:

# no time window
F=defaultdict(lambda:[0,0])#all papers, top 5% breadth
n=0
for i in W1:
    n+=1
    if n%100000==0:
        flushPrint(n/100000)
    if i in Z1:
        year,teamsize=W1[i]
        breadth=Z1[i]
        #if 1<=teamsize<=16:
        F[teamsize][0]+=1
        if breadth<=-23.15:
            F[teamsize][1]+=1
xf1,yf1=np.array([(k,v[1]/(v[0]+v[1]+0.0)) for k,v in F.items()]).T


# In[61]:

### create figure
fig = plt.figure(figsize=(12, 8),facecolor='white')
#
ax = fig.add_subplot(231)
ax.set_xlim(1, 50)
ax.set_xlabel("Team size",fontsize =16)
ax.set_ylabel("Uzzi novelty",fontsize=16)
plt.title('2-way Journal',size=18)
#
maxm=100
ax.plot(range(1,maxm+1),100-np.array(ybre_[:maxm]), linewidth=1.5,color='#4477AA')
ax.set_ylim(5, 30)
#ax.set_yticks([15,24,35])
ax.tick_params(axis='both', which='major', labelsize=14)
#
#
ax = fig.add_subplot(233)
plt.plot(x3p,100-y3p_,color='Orange',linewidth=1.5)
plt.xlim(1,50)
plt.ylim(0,40)
plt.xlabel('Team size',size=16)
plt.ylabel('Jaccard novelty',size=16)
plt.title('2-way MeSH',size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(232)
plt.plot(x3,100-y3_,color='ForestGreen',linewidth=1.5)
plt.xlim(1,50)
plt.ylim(0,40)
plt.xlabel('Team size',size=16)
plt.ylabel('Jaccard novelty',size=16)
plt.title('2-way PACS',size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(234)
plt.plot(xf1,yf1,color='#4477AA',linewidth=1.5)
plt.plot([1,100],[0.05,0.05],color='gray',linestyle='--')
plt.xlim(1,50)
plt.ylim(0,0.1)
ax.tick_params(axis='both', which='major', labelsize=14)
ax.set_xlabel("Team size",fontsize =16)
ax.set_ylabel("P(Top5% Uzzi novelty)",fontsize=16)
plt.title('2-way Journal',size=18)
#
ax = fig.add_subplot(236)
plt.plot(x6p,100-y6p_,color='Orange',linewidth=1.5)
plt.xlim(1,50)
plt.ylim(0,40)
plt.xlabel('Team size',size=16)
plt.ylabel('Jaccard novelty',size=16)
plt.title('3-way MeSH',size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
#
ax = fig.add_subplot(235)
plt.plot(x6,100-y6_,color='ForestGreen',linewidth=1.5)
plt.xlim(1,50)
plt.ylim(0,40)
plt.xlabel('Team size',size=16)
plt.ylabel('Jaccard novelty',size=16)
plt.title('3-way PACS',size=18)
ax.tick_params(axis='both', which='major', labelsize=14)
#
plt.tight_layout()
plt.savefig('/Users/lingfeiw/Dropbox/teams/1 submit Nature/figures_for_revision/novelty.pdf')


# In[ ]:



